# 403_bypasser_main.py

from burp import IBurpExtender, IScanIssue, IScannerCheck, IContextMenuFactory, IContextMenuInvocation, ITab
from javax.swing import JMenuItem # Keep only necessary Swing imports if UI moved
# Removed other UI imports if uiTab is in ui.py
import java.awt.BorderLayout # Keep if uiTab is still here
import java.util.ArrayList as ArrayList # <--- ADD THIS IMPORT
import java.lang.String as String
from java.lang import Short

import sys
import os
import thread
import cgi

# Import local modules using absolute paths
import config
import utils
# Import the new UI class
from ui import uiTab
from bypass_modules import (
    query_payloads,
    header_injection,
    method_change,
    http_downgrade,
    homoglyph,
    segment_mods,
    encoding_mods,
    trim_chars
)

# --- Burp Extender Class ---
class BurpExtender(IBurpExtender, IScannerCheck, IContextMenuFactory, ITab):

    # --- registerExtenderCallbacks ---
    def registerExtenderCallbacks(self, callbacks):
        self.callbacks = callbacks
        self.helpers = self.callbacks.getHelpers()
        self.callbacks.registerScannerCheck(self)
        self.callbacks.registerContextMenuFactory(self)
        self.callbacks.setExtensionName(config.extentionName)
        sys.stdout = self.callbacks.getStdout()
        sys.stderr = self.callbacks.getStderr()

        # Initialize UI (pass callbacks for saving settings)
        self.frm = uiTab(self.callbacks)
        self.callbacks.addSuiteTab(self)

        # --- Load Settings and Populate UI ---
        try:
             print("Loading extension settings...")
             saved_order_str = self.callbacks.loadExtensionSetting(config.SETTINGS_KEY_ORDER)
             saved_enabled_str = self.callbacks.loadExtensionSetting(config.SETTINGS_KEY_ENABLED)

             enabled_map = {}
             if saved_enabled_str:
                  for item in saved_enabled_str.split(','):
                       parts = item.split(':', 1)
                       if len(parts) == 2:
                            enabled_map[parts[0]] = parts[1] == "true"

             final_check_config = []
             default_keys = set(item[1] for item in config.DEFAULT_CHECKS_CONFIG)

             # Process saved order first
             processed_keys = set()
             if saved_order_str:
                  saved_order_keys = saved_order_str.split(',')
                  for key in saved_order_keys:
                       # Find the default config tuple for this key
                       default_tuple = next((item for item in config.DEFAULT_CHECKS_CONFIG if item[1] == key), None)
                       if default_tuple:
                            display_name = default_tuple[0]
                            # Get saved enabled state, fallback to default if not found
                            is_enabled = enabled_map.get(key, default_tuple[2])
                            final_check_config.append((display_name, key, is_enabled))
                            processed_keys.add(key)

             # Add any new checks from default config that weren't in saved order
             for default_tuple in config.DEFAULT_CHECKS_CONFIG:
                  key = default_tuple[1]
                  if key not in processed_keys:
                       display_name = default_tuple[0]
                       # Get saved state or use default
                       is_enabled = enabled_map.get(key, default_tuple[2])
                       print("Adding new/missing check to config: {}".format(display_name))
                       final_check_config.append((display_name, key, is_enabled))

             # Populate the UI list
             self.frm.populate_check_list(final_check_config)
             print("Check list populated from saved settings (or defaults).")

        except Exception as e:
             print("(!) Error loading settings or populating UI, using defaults: {}".format(e))
             # Fallback to default config if loading fails
             self.frm.populate_check_list(config.DEFAULT_CHECKS_CONFIG)


        print("{} extension loaded.".format(config.extentionName))
        return None

    # --- getTabCaption, getUiComponent, createMenuItems, testFromMenu ---
    # (These methods remain largely the same as the last correct version)
    def getTabCaption(self):
        return config.extentionName

    def getUiComponent(self):
        return self.frm.panel # Return the main panel from the uiTab instance

    def createMenuItems(self, invocation):
        messages = invocation.getSelectedMessages()
        if messages is None or len(messages) == 0:
            return None

        self.context = invocation
        menuList = ArrayList()
        menu_text = "Send to {} (Active Scan)".format(config.extentionName)
        menuItem = JMenuItem(menu_text, actionPerformed=self.testFromMenu)
        menuList.add(menuItem)
        return menuList

    def testFromMenu(self, event):
        selectedMessages = self.context.getSelectedMessages()
        if not selectedMessages:
            print("No messages selected.")
            return None
        print("Sending {} selected message(s) to {} scan...".format(len(selectedMessages), config.extentionName))
        for message in selectedMessages:
            thread.start_new_thread(self.doActiveScan, (message, None, True ))
        return None

    # --- doPassiveScan, doActiveScan ---
    # (Remain the same as the last correct version)
    def doPassiveScan(self, baseRequestResponse):
        return None

    def doActiveScan(self, baseRequestResponse, insertionPoint, isCalledFromMenu=False):
        baseResponseBytes = baseRequestResponse.getResponse()
        is_interesting_target = utils.isInteresting(baseResponseBytes, self.helpers)

        if not isCalledFromMenu and not is_interesting_target:
            return None

        print("\n--- Starting {} Scan ---".format(config.extentionName))
        targetUrl = "[Could not analyze request URL]"
        requestInfo = None
        try:
            requestInfo = self.helpers.analyzeRequest(baseRequestResponse)
            if requestInfo:
                targetUrl = str(requestInfo.getUrl())
        except Exception as e:
             print("(!) Error getting target URL: {}".format(e))

        print("Target: " + targetUrl)

        if is_interesting_target:
            print("Original response status: 403 Forbidden (Scan proceeds)")
        else:
            print("Original response status: Not 403 (Scan proceeds as called from menu)")

        issueResultList = self.testRequest(baseRequestResponse, requestInfo) # Pass requestInfo

        if issueResultList:
            print("Scan complete: Bypass FOUND!")
            if isCalledFromMenu and isinstance(issueResultList, list) and len(issueResultList) > 0:
                try:
                    if targetUrl != "[Could not analyze request URL]":
                        existing_issues = self.callbacks.getScanIssues(targetUrl)
                        is_duplicate = False
                        for existing in existing_issues:
                            if self.consolidateDuplicateIssues(existing, issueResultList[0]) == -1:
                                is_duplicate = True
                                print("Scan issue seems to be a duplicate, not adding again from menu.")
                                break
                        if not is_duplicate:
                            self.callbacks.addScanIssue(issueResultList[0])
                            print("Added scan issue from context menu trigger.")
                    else:
                         print("(!) Cannot check for duplicate issues due to URL analysis error. Adding issue.")
                         if issueResultList[0]: self.callbacks.addScanIssue(issueResultList[0])

                except Exception as e:
                    print("(!) Error checking duplicates/adding issue: {}".format(e))
                    try:
                        if issueResultList[0]: self.callbacks.addScanIssue(issueResultList[0])
                    except Exception as add_err: print("(!) Failed to add issue after error: {}".format(add_err))
                return None
            else:
                return issueResultList
        else:
            print("Scan complete: No bypass found.")
            return None

    # --- Main Test Orchestration (MODIFIED to use UI config) ---
    def testRequest(self, baseRequestResponse, requestInfo):
        httpService = baseRequestResponse.getHttpService()
        originalUrl = requestInfo.getUrl() if requestInfo else None
        baseResponseBytes = baseRequestResponse.getResponse()
        sensitive_indices = None

        # --- Load Payloads/Keywords from UI TextAreas ---
        queryPayloadsFromUI = []
        headerPayloadsFromUI = []
        fullHeaderPayloadsToTest = []
        falsePositiveKeywords = []
        try:
            # Read directly from the UI components stored in self.frm
            queryPayloadsFromUI = [line.strip() for line in self.frm.queryPayloadsTextArea.getText().splitlines() if line.strip()]
            headerPayloadsFromUI = [line.strip() for line in self.frm.headerPayloadsTextArea.getText().splitlines() if line.strip()]
            fullHeaderPayloadsToTest = list(set(headerPayloadsFromUI + config.internalDefaultHeaderPayloads))
            falsePositiveKeywords = [line.strip() for line in self.frm.falsePositivesTextArea.getText().splitlines() if line.strip()]
            # print("Using payloads/keywords from UI.") # Less verbose
        except Exception as e:
            print("(!) Error reading UI text areas: {}. Using defaults.".format(e))
            queryPayloadsFromUI = config.defaultQueryPayloads
            fullHeaderPayloadsToTest = config.internalDefaultHeaderPayloads
            falsePositiveKeywords = config.defaultFalsePositives

        # --- Preliminary Path Check ---
        if utils.isInteresting(baseResponseBytes, self.helpers):
            sensitive_indices = utils.preliminaryPathCheck(baseRequestResponse, httpService, self.helpers, self.callbacks)

        # --- Get Ordered & Enabled Checks from UI ---
        try:
            ordered_check_config = self.frm.get_ordered_checks()
            # print("Using check order and enabled states from UI: {}".format(ordered_check_config))
        except Exception as e:
             print("(!) Error getting check order from UI: {}. Aborting.".format(e))
             return None

        # --- Build Function Map (Map KEY to actual function) ---
        # This maps the internal keys defined in config to the actual functions
        # Need to handle lambda functions correctly if used
        CHECK_FUNCTION_MAP = {
            config.QUERY_PAYLOADS_KEY: query_payloads.check_standard_query,
            config.HEADER_INJECTION_KEY: header_injection.check_headers,
            config.METHOD_CHANGE_KEY: method_change.check_post_cl0,
            config.HTTP_DOWNGRADE_KEY: http_downgrade.check_http10,
            config.HOMOGLYPH_KEY: homoglyph.check_homoglyphs,
            config.EXTRA_SLASH_KEY: segment_mods.check_extra_slash,
            config.APPEND_JSON_KEY: segment_mods.check_append_json,
            config.UPPERCASE_LAST_KEY: segment_mods.check_uppercase_last,
            config.UNICODE_SLASH_KEY: segment_mods.check_unicode_slash,
            config.DOUBLE_ENCODE_KEY: encoding_mods.check_double_encoding,
            config.TRIM_CHARS_KEY: trim_chars.check_trim_chars,
            config.URL_ENCODE_CHAR_KEY: lambda req, svc, fp, idx, h, c: encoding_mods.check_char_encoding(req, svc, fp, idx, h, c, encoding_type="url_encode"),
            config.DOUBLE_URL_ENCODE_CHAR_KEY: lambda req, svc, fp, idx, h, c: encoding_mods.check_char_encoding(req, svc, fp, idx, h, c, encoding_type="double_url_encode"),
            config.UNICODE_ENCODE_CHAR_KEY: lambda req, svc, fp, idx, h, c: encoding_mods.check_char_encoding(req, svc, fp, idx, h, c, encoding_type="unicode_encode"),
        }

        # --- Execute Tests based on UI Order & Enabled Status ---
        for check_config in ordered_check_config:
            check_display_name = check_config.get("name")
            check_key = check_config.get("key")
            is_enabled = check_config.get("enabled")
            check_func = CHECK_FUNCTION_MAP.get(check_key)

            if not is_enabled:
                print("--- Skipping Check: {} (Disabled) ---".format(check_display_name))
                continue

            if not check_func:
                print("--- Skipping Check: {} (Function not found for key: {}) ---".format(check_display_name, check_key))
                continue

            print("--- Testing {} ---".format(check_display_name))
            result_dict = None
            requires_sensitive = check_key in [
                config.EXTRA_SLASH_KEY, config.APPEND_JSON_KEY, config.UPPERCASE_LAST_KEY,
                config.UNICODE_SLASH_KEY, config.DOUBLE_ENCODE_KEY, config.TRIM_CHARS_KEY,
                config.URL_ENCODE_CHAR_KEY, config.DOUBLE_URL_ENCODE_CHAR_KEY, config.UNICODE_ENCODE_CHAR_KEY
            ]

            try:
                # Call function with appropriate arguments
                common_args = [baseRequestResponse, httpService, falsePositiveKeywords]
                full_args = common_args + [self.helpers, self.callbacks] # Add helpers/callbacks for most functions

                if requires_sensitive:
                    if sensitive_indices is not None and len(sensitive_indices) > 0:
                        # Pass sensitive indices as the 4th argument for these specific functions
                        args_for_sensitive = common_args[:3] + [sensitive_indices] + full_args[3:]
                        result_dict = check_func(*args_for_sensitive)
                    else:
                        print("    Skipping (Requires sensitive segments, none found/check failed).")
                        continue
                elif check_key == config.QUERY_PAYLOADS_KEY:
                    if queryPayloadsFromUI:
                        for payload in queryPayloadsFromUI:
                            # Pass sensitive indices (can be None)
                            args_for_query = common_args[:3] + [sensitive_indices] + full_args[3:]
                            result_dict = check_func(baseRequestResponse, payload, *args_for_query[1:]) # Adjust for payload arg
                            if result_dict: break
                    else:
                        print("    Skipping (no query payloads).")
                        continue
                elif check_key == config.HEADER_INJECTION_KEY:
                    if fullHeaderPayloadsToTest:
                        for payload in fullHeaderPayloadsToTest:
                            # --- PROBLEM AREA ---
                            # This line was likely incorrect, relying on args_for_query
                            # result_dict = check_func(baseRequestResponse, payload, *args_for_query[1:]) # Incorrect!

                            # --- CORRECTED CALL ---
                            # Call check_headers directly with the arguments it expects
                            result_dict = check_func(baseRequestResponse, payload, httpService,
                                                     falsePositiveKeywords, # Pass the loaded FP list
                                                     self.helpers, self.callbacks) # Pass helpers/callbacks
                            if result_dict:
                                break # Found one, stop header checks
                    else:
                        print("    Skipping (no header payloads).")
                        continue
                elif check_key == config.METHOD_CHANGE_KEY:
                    if requestInfo and requestInfo.getMethod().upper() == "GET":
                        result_dict = check_func(*full_args)
                    else:
                        print("    Skipping (original method not GET).")
                        continue
                else: # Standard checks (Homoglyph, HTTP Downgrade)
                    result_dict = check_func(*full_args)

            except Exception as call_err:
                 print("    (!) Error calling check function '{}': {}".format(check_display_name, call_err))
                 # import traceback; traceback.print_exc(file=sys.stderr) # For debugging
                 continue # Skip to next check on error

            # --- Process Result ---
            if result_dict:
                try:
                    # ... (rest of result processing and issue creation remains the same) ...
                    issue_type_str = result_dict.get("type", "Unknown Technique")
                    issue_name = "403 Bypass Found ({})".format(issue_type_str)
                    detail_text = "<b>Bypass Technique:</b> {}<br/>".format(cgi.escape(str(issue_type_str)))
                    if "url" in result_dict: detail_text += "<b>URL:</b> {}<br/>".format(cgi.escape(str(result_dict.get("url", "N/A"))))
                    if "original_url" in result_dict: detail_text += "<b>Original URL:</b> {}<br/>".format(cgi.escape(str(result_dict.get("original_url", "N/A"))))
                    bypassed_url_val = result_dict.get("bypassed_url", "N/A")
                    if "<b>" in bypassed_url_val: detail_text += "<b>Bypassed URL:</b> {}<br/>".format(bypassed_url_val)
                    else: detail_text += "<b>Bypassed URL:</b> {}<br/>".format(cgi.escape(str(bypassed_url_val)))
                    if "bypassed_path" in result_dict: detail_text += "<b>Bypassed Path:</b> {}<br/>".format(cgi.escape(str(result_dict.get("bypassed_path", "N/A"))))
                    if "payload_used" in result_dict: detail_text += "<b>Payload Used:</b> {}<br/>".format(cgi.escape(str(result_dict.get("payload_used", "N/A"))))
                    if "header_used" in result_dict: detail_text += "<b>Header Used:</b> {}<br/>".format(cgi.escape(str(result_dict.get("header_used", "N/A"))))
                    if "technique" in result_dict: detail_text += "<b>Technique Info:</b> {}<br/>".format(cgi.escape(str(result_dict.get("technique", "N/A"))))
                    if "original_char" in result_dict: detail_text += "<b>Original Char:</b> {}<br/>".format(cgi.escape(str(result_dict.get("original_char", "N/A"))))
                    if "homoglyph" in result_dict: detail_text += "<b>Homoglyph Used:</b> {}<br/>".format(cgi.escape(str(result_dict.get("homoglyph", "N/A"))))
                    if "index" in result_dict: detail_text += "<b>Index:</b> {}<br/>".format(cgi.escape(str(result_dict.get("index", "N/A"))))
                    detail_text += "<b>Status:</b> {}<br/>".format(cgi.escape(str(result_dict.get("status", "N/A"))))
                    detail_text += "<b>Length:</b> {}".format(cgi.escape(str(result_dict.get("length", "N/A"))))
                    severity = "Medium"
                    if "Query Payload" in issue_type_str or "Header" in issue_type_str or "Double Encode" in issue_type_str: severity = "High"
                    # Use utils.CustomScanIssue
                    finding = utils.CustomScanIssue(httpService, originalUrl, [baseRequestResponse, result_dict.get("http_message")], issue_name, detail_text, severity )
                    return [finding]
                except Exception as report_err:
                    print("(!) Error creating scan issue: {}".format(report_err))
                    return None

        print("--- All checks finished, no bypass found ---")
        return None

    # --- Consolidate Duplicate Issues ---
    def consolidateDuplicateIssues(self, existingIssue, newIssue):
        # This logic remains the same, potentially move to utils if desired
        try:
            existing_url = existingIssue.getUrl()
            new_url = newIssue.getUrl()
            if (existingIssue.getIssueName() == newIssue.getIssueName() and
                existing_url and new_url and
                existing_url.getPath() == new_url.getPath()):
                return -1
            return 0
        except Exception as e:
            print("(!) Error consolidating issues: {}".format(e))
            return 0