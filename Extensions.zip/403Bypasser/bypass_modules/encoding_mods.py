# bypass_modules/encoding_mods.py

import java.util.ArrayList as ArrayList
import java.lang.String as String
import java.util.Arrays
import java.lang.reflect.Array
import java.lang.Byte
from java.net import URLEncoder # For encoding payloads if needed

# Import helpers, config, and potentially other modules
from utils import (isFalsePositive, urlEncodeChar, doubleUrlEncode, 
                     unicodeEncodeCharForUrl, analyze_original_request)
from config import payloadsToDoubleEncode
from query_payloads import check_standard_query # Import query check

# --- Check Double Encoding Payloads ---
def check_double_encoding(baseRequestResponse, httpService, falsePositiveKeywords, sensitive_indices, helpers, callbacks):
    print("  [Segment Mod] Testing Double URL Encoding Payloads")
    # This check relies on query payload logic with modified payloads
    for payload_to_encode in payloadsToDoubleEncode:
        # Get single encoding first
        single_encoded = ""
        if len(payload_to_encode) == 1:
            single_encoded = urlEncodeChar(payload_to_encode)
        else:
            try:
                # Use standard URL encoding for multi-char strings like ".."
                single_encoded = URLEncoder.encode(payload_to_encode, "UTF-8")
            except Exception as e:
                print("    (!) Error single-encoding payload '{}': {}".format(payload_to_encode, e))
                continue
        
        double_encoded_payload = doubleUrlEncode(single_encoded) # Use util

        # Skip if encoding didn't change (e.g., ".." -> "..")
        if single_encoded == double_encoded_payload:
            continue

        print("    Testing double encoded payload: '{}' -> '{}'".format(payload_to_encode, double_encoded_payload))
        
        # Call the standard query payload check with the double encoded payload
        # It will use generatePayloads focused on sensitive indices (or fallback)
        result_dict = check_standard_query(
            baseRequestResponse,
            double_encoded_payload, # Use the generated double-encoded payload
            httpService,
            falsePositiveKeywords,
            sensitive_indices,
            helpers,
            callbacks
        )
        if result_dict:
            # Modify the type description for clarity
            result_dict["type"] = "Double URL Encode"
            result_dict["technique"] = "Double encoding of '{}'".format(payload_to_encode)
            result_dict["payload_used"] = double_encoded_payload # Show the actual payload sent
            print("      ****** SUCCESS (Double Encoding Bypass) ******")
            return result_dict # Return the dictionary from the successful call
    return None

# --- Check First/Last Character Encoding ---
def check_char_encoding(baseRequestResponse, httpService, falsePositiveKeywords, sensitive_indices, helpers, callbacks, encoding_type):
    """
    Handles URL Encode, Double URL Encode, Unicode Encode of First/Last char
    """
    check_name_map = {
        "url_encode": "URL Encode Char",
        "double_url_encode": "Double URL Encode Char",
        "unicode_encode": "Unicode Encode Char"
    }
    check_name = check_name_map.get(encoding_type, "Unknown Encode")
    print("  [Segment Mod] Testing {} First/Last".format(check_name))
    
    if sensitive_indices is None or not sensitive_indices:
        print("    Skipping: No sensitive indices identified for {}.".format(check_name))
        return None

    # Use the analysis helper from utils
    analysis = analyze_original_request(baseRequestResponse, helpers)
    if not analysis:
        print("    (!) Analysis failed for {} check.".format(check_name))
        return None

    originalPath = analysis["path"]
    originalQuery = analysis["query"] # Get query
    originalHeaders = analysis["headers"]
    originalMethod = analysis["method"]
    originalProtocol = analysis["protocol"]
    originalBodyBytes = analysis["bodyBytes"]
    originalUrl = analysis["url"]
    segments = [s for s in originalPath.strip('/').split('/')]
    
    if not segments:
        print("    Skipping: No path segments found.")
        return None

    # --- Prepare Query String ---
    queryString = ""
    if originalQuery is not None and len(originalQuery) > 0:
        queryString = "?" + originalQuery

    for i in sensitive_indices:
        if i >= len(segments) or not segments[i]:
            continue
        
        segment = segments[i]

        # Test First and Last characters
        positions_to_test = []
        if len(segment) > 0:
            positions_to_test.append((0, segment[0], "First"))
            # Only add Last if segment has more than 1 char (different from First)
            if len(segment) > 1:
                 positions_to_test.append((-1, segment[-1], "Last"))

        for pos_idx, char_to_encode, position_label in positions_to_test:
            if not char_to_encode:
                continue

            # Apply the specified encoding
            encoded_char = ""
            try:
                if encoding_type == "url_encode":
                    encoded_char = urlEncodeChar(char_to_encode) # Use util
                elif encoding_type == "double_url_encode":
                    single_encoded = urlEncodeChar(char_to_encode) # Use util
                    encoded_char = doubleUrlEncode(single_encoded) # Use util
                elif encoding_type == "unicode_encode":
                    encoded_char = unicodeEncodeCharForUrl(char_to_encode) # Use util
                else:
                    continue # Should not happen
            except Exception as encode_err:
                 print("      (!) Error encoding char '{}' for {}: {}".format(repr(char_to_encode), encoding_type, encode_err))
                 continue

            # Skip if encoding resulted in the same character or failed
            if not encoded_char or encoded_char == char_to_encode:
                continue

            print("    Testing {} {} char of segment {}: '{}' -> '{}'".format(encoding_type, position_label, i, char_to_encode, encoded_char))

            # Build modified path
            temp_segments = list(segments)
            if position_label == "First":
                temp_segments[i] = encoded_char + segment[1:]
            else: # Last
                temp_segments[i] = segment[:-1] + encoded_char
            
            modifiedPath = "/" + "/".join(temp_segments)
            
            if originalPath.endswith('/'):
                modifiedPath += "/"

            # Send request and check result
            try:
                # --- MODIFICATION: Append Query String ---
                fullPathWithQuery = modifiedPath + queryString
                # --- END MODIFICATION ---

                new_request_line = "{} {} {}".format(originalMethod, fullPathWithQuery, originalProtocol)
                newHeadersList = ArrayList()
                newHeadersList.add(String(new_request_line))
                
                if len(originalHeaders) > 1:
                    for h_idx in range(1, len(originalHeaders)):
                        newHeadersList.add(originalHeaders[h_idx])
                
                newRequestBytes = helpers.buildHttpMessage(newHeadersList, originalBodyBytes)
                newRequestResult = callbacks.makeHttpRequest(httpService, newRequestBytes)
                responseBytes = newRequestResult.getResponse()
                
                if responseBytes is None:
                    continue

                responseInfo = helpers.analyzeResponse(responseBytes)
                if responseInfo is None:
                    continue
                    
                newStatusCode = responseInfo.getStatusCode()
                
                if 200 <= newStatusCode < 300:
                    # Use isFalsePositive from utils
                    is_fp = isFalsePositive(responseBytes, falsePositiveKeywords, helpers)
                    if not is_fp:
                        contentLength = "N/A"
                        try:
                            resp_headers = responseInfo.getHeaders()
                            for idx in range(1, resp_headers.size()):
                                header = resp_headers.get(idx)
                                if header and header.lower().startswith("content-length:"):
                                    contentLength = header.split(":", 1)[1].strip()
                                    break
                        except Exception:
                            pass

                        technique_desc = "{} {} char ('{}' -> '{}') of segment {}".format(check_name, position_label, char_to_encode, encoded_char, i)
                        print("      ****** SUCCESS ({} Bypass) ******".format(check_name))
                        print("      Path: " + fullPathWithQuery)
                        
                        result_data = {
                            "type": check_name,
                            "url": str(originalUrl),
                            "technique": technique_desc,
                            "bypassed_path": fullPathWithQuery, # Report with query
                            "status": newStatusCode,
                            "length": contentLength,
                            "http_message": newRequestResult
                        }
                        return result_data
            except Exception as req_err:
                print("      (!) Error sending request for {} {} char on segment {}: {}".format(encoding_type, position_label, i, req_err))
                continue

    # No success after checking all sensitive indices and positions
    return None