# bypass_modules/header_injection.py

import java.util.ArrayList as ArrayList
import java.lang.String as String
import java.util.Arrays
import java.lang.reflect.Array
import java.lang.Byte

# Import helpers and config
from utils import isFalsePositive
from config import HEADERS_WITH_PATHS_TO_ADAPT

def check_headers(baseRequestResponse, payload, httpService, falsePositiveKeywords, helpers, callbacks):
    print("  [Header] Testing payload: '" + payload + "'")
    originalRequestInfo = None
    originalHeaders = None
    originalUrl = None
    originalPath = "/"
    originalBodyJavaBytes = None
    try:
        originalRequestInfo = helpers.analyzeRequest(baseRequestResponse)
        if originalRequestInfo is None:
            print("    (!) Failed analyze.")
            return None

        originalHeaders = list(originalRequestInfo.getHeaders())
        originalUrl = originalRequestInfo.getUrl()
        tempPath = originalUrl.getPath() if originalUrl else "/"
        if tempPath is None or not tempPath:
            originalPath = "/"
        else:
            originalPath = tempPath

        raw_original_request_bytes = baseRequestResponse.getRequest()
        original_body_offset = originalRequestInfo.getBodyOffset()
        if len(raw_original_request_bytes) > original_body_offset:
            originalBodyJavaBytes = java.util.Arrays.copyOfRange(raw_original_request_bytes, original_body_offset, len(raw_original_request_bytes))
        else:
            originalBodyJavaBytes = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)

    except Exception as analysis_err:
         print("    (!) Error analyzing: {}".format(analysis_err))
         return None

    try:
        header_parts = payload.split(":", 1)
        if len(header_parts) != 2:
            print("    (!) Invalid format: " + payload)
            return None
        header_name = header_parts[0].strip()
        header_value = header_parts[1].strip()
        header_name_lower = header_name.lower()
        if not header_name:
            print("    (!) Empty name.")
            return None

        adapted_header_value = header_value
        # Use HEADERS_WITH_PATHS_TO_ADAPT from config
        if header_name_lower in HEADERS_WITH_PATHS_TO_ADAPT and header_value.startswith('/'):
            print("    Adapting path for '{}'. Original: '{}', Target: '{}'".format(header_name, header_value, originalPath))
            adapted_header_value = originalPath
        payload_normalized = header_name + ": " + adapted_header_value

        newHeadersList = ArrayList()
        replaced = False
        if originalHeaders:
            newHeadersList.add(originalHeaders[0]) # Add request line
        else:
             print("    (!) Original request missing headers.")
             return None

        for i in range(1, len(originalHeaders)):
            header = originalHeaders[i]
            current_name = ""
            try:
                current_name = header.split(":", 1)[0].strip().lower()
            except IndexError:
                pass
            if current_name == header_name_lower:
                newHeadersList.add(String(payload_normalized))
                replaced = True
                print("    Replaced existing: " + header_name)
            else:
                newHeadersList.add(header)
        if not replaced:
            newHeadersList.add(String(payload_normalized))
            print("    Added new: " + header_name)

        newRequestBytes = helpers.buildHttpMessage(newHeadersList, originalBodyJavaBytes)
        newRequestResult = callbacks.makeHttpRequest(httpService, newRequestBytes)
        responseBytes = newRequestResult.getResponse()
        if responseBytes is None:
            return None

        responseInfo = helpers.analyzeResponse(responseBytes)
        if responseInfo is None:
             print("      (!) Failed to analyze response for header bypass.")
             return None

        newStatusCode = responseInfo.getStatusCode()

        if 200 <= newStatusCode < 300:
            # Use isFalsePositive from utils
            is_fp = isFalsePositive(responseBytes, falsePositiveKeywords, helpers)
            if not is_fp:
                originalUrlStr = str(originalUrl)
                contentLength = "N/A"
                try:
                    resp_headers = responseInfo.getHeaders()
                    for idx in range(1, resp_headers.size()):
                        header = resp_headers.get(idx)
                        if header and header.lower().startswith("content-length:"):
                            contentLength = header.split(":", 1)[1].strip()
                            break
                except Exception: pass

                print("      ****** SUCCESS (Header Bypass) ******")
                print("      URL: " + originalUrlStr)
                print("      Header Used: " + payload_normalized)
                result_data = {
                    "type": "Header Injection",
                    "original_url": originalUrlStr,
                    "header_used": payload_normalized,
                    "status": newStatusCode,
                    "length": contentLength,
                    "http_message": newRequestResult
                }
                return result_data

    except Exception as e:
        print("    (!) Error testing header '{}': {}".format(payload, e))

    return None