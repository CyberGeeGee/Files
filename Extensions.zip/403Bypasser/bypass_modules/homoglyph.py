# bypass_modules/homoglyph.py

import java.util.ArrayList as ArrayList
import java.lang.String as String
import java.util.Arrays
import java.lang.reflect.Array
import java.lang.Byte

# Import helpers and config using absolute paths
from utils import isFalsePositive, analyze_original_request
from config import homoglyphMap # Import the map

def check_homoglyphs(baseRequestResponse, httpService, falsePositiveKeywords, helpers, callbacks):
    print("  [Homoglyph] Testing path character replacements...")
    
    originalRequestInfo = None
    originalHeadersJavaList = None
    originalBody = None
    originalUrl = None
    originalPathUnicode = u"/"
    originalQuery = None
    original_method = None
    original_protocol = "HTTP/1.1"

    try:
        # Use the analysis helper from utils
        analysis = analyze_original_request(baseRequestResponse, helpers)
        if not analysis:
            print("    (!) Analysis failed for Homoglyph check.")
            return None

        # Use unicode path and query from analysis
        originalRequestInfo = analysis["requestInfo"]
        originalPathUnicode = analysis["pathUnicode"] # Already unicode
        originalQuery = analysis["query"]
        
        # Convert headers list back to Java ArrayList
        originalHeadersJavaList = ArrayList()
        if analysis["headers"]:
            for h in analysis["headers"]:
                originalHeadersJavaList.add(h)
        else:
            print("    (!) No headers found in analysis.")
            return None
            
        originalBody = analysis["bodyBytes"]
        original_method = analysis["method"]
        original_protocol = analysis["protocol"]
        originalUrl = analysis["url"] # For reporting

    except Exception as analysis_err:
         print("    (!) Error analyzing request in homoglyph: {}".format(analysis_err))
         return None

    # --- Prepare Query String ---
    queryString = u"" # Use unicode string
    if originalQuery is not None and len(originalQuery) > 0:
        try:
            # Try to decode query to unicode as well
            queryString = u"?" + (originalQuery.decode('utf-8') if isinstance(originalQuery, str) else originalQuery)
        except UnicodeDecodeError:
            queryString = u"?" + originalQuery.decode('latin-1', 'ignore') # Fallback

    try:
        # --- Find Alpha Chars ---
        first_alpha_idx = -1
        first_alpha_char = None
        last_alpha_idx = -1
        last_alpha_char = None
        
        for i, char in enumerate(originalPathUnicode):
            if char.isalpha():
                if first_alpha_idx == -1:
                    first_alpha_idx = i
                    first_alpha_char = char
                # Keep updating last seen alpha char
                last_alpha_idx = i
                last_alpha_char = char
                
        # Exit if no alpha chars found
        if first_alpha_idx == -1:
            print("    No alpha chars in path.")
            return None

        # --- Test First Alpha ---
        if first_alpha_char:
            char_lower = first_alpha_char.lower()
            # Use homoglyphMap from config
            if char_lower in homoglyphMap:
                for homoglyph in homoglyphMap[char_lower]:
                    try:
                        # Create new path
                        newPath = originalPathUnicode[:first_alpha_idx] + homoglyph + originalPathUnicode[first_alpha_idx + 1:]
                        
                        # --- MODIFICATION: Append Query String ---
                        fullPathWithQuery = newPath + queryString
                        # --- END MODIFICATION ---

                        # Build request
                        newLine = unicode(original_method) + u" " + fullPathWithQuery + u" " + unicode(original_protocol)
                        newHeaders = ArrayList()
                        newHeaders.add(String(newLine)) # Pass unicode string
                        
                        if originalHeadersJavaList.size() > 1:
                            for idx in range(1, originalHeadersJavaList.size()):
                                newHeaders.add(originalHeadersJavaList.get(idx))
                                
                        newBytes = helpers.buildHttpMessage(newHeaders, originalBody)
                        
                        # Send request
                        newResult = callbacks.makeHttpRequest(httpService, newBytes)
                        respBytes = newResult.getResponse()
                        
                        if respBytes is None:
                            continue
                            
                        # Check response
                        respInfo = helpers.analyzeResponse(respBytes)
                        if respInfo is None:
                            continue
                            
                        status = respInfo.getStatusCode()
                        
                        if 200 <= status < 300:
                            # Use isFalsePositive from utils
                            is_fp = isFalsePositive(respBytes, falsePositiveKeywords, helpers)
                            if not is_fp:
                                pathStr = repr(fullPathWithQuery) # Report path with query
                                length = "N/A"
                                try:
                                    resp_headers = respInfo.getHeaders()
                                    for idx in range(1, resp_headers.size()):
                                        h = resp_headers.get(idx)
                                        if h and h.lower().startswith("content-length:"):
                                            length = h.split(":", 1)[1].strip()
                                            break
                                except Exception:
                                    pass
                                    
                                print("      ****** SUCCESS (Homoglyph Bypass - First) ******")
                                print("      Path: " + pathStr)
                                print("      Original: " + repr(first_alpha_char))
                                print("      Homoglyph: " + repr(homoglyph))
                                
                                # Return values needed for the simple text format
                                result_data = {
                                    "type": "Homoglyph (First)",
                                    "bypassed_path": pathStr,
                                    "original_char": repr(first_alpha_char),
                                    "homoglyph": repr(homoglyph),
                                    "index": first_alpha_idx,
                                    "status": status,
                                    "length": length,
                                    "http_message": newResult
                                }
                                return result_data
                    except Exception as e:
                        print("      (!) Error processing homoglyph '{}' (first): {}".format(repr(homoglyph), e))
                        # import traceback; traceback.print_exc(file=sys.stderr) # For debugging

        # --- Test Last Alpha (if different) ---
        if last_alpha_char and last_alpha_idx != first_alpha_idx:
            char_lower = last_alpha_char.lower()
            # Use homoglyphMap from config
            if char_lower in homoglyphMap:
                for homoglyph in homoglyphMap[char_lower]:
                    try:
                        # Create new path
                        newPath = originalPathUnicode[:last_alpha_idx] + homoglyph + originalPathUnicode[last_alpha_idx + 1:]
                        
                        # --- MODIFICATION: Append Query String ---
                        fullPathWithQuery = newPath + queryString
                        # --- END MODIFICATION ---

                        # Build request
                        newLine = unicode(original_method) + u" " + fullPathWithQuery + u" " + unicode(original_protocol)
                        newHeaders = ArrayList()
                        newHeaders.add(String(newLine)) # Pass unicode string
                        
                        if originalHeadersJavaList.size() > 1:
                             for idx in range(1, originalHeadersJavaList.size()):
                                 newHeaders.add(originalHeadersJavaList.get(idx))
                                 
                        newBytes = helpers.buildHttpMessage(newHeaders, originalBody)
                        
                        # Send request
                        newResult = callbacks.makeHttpRequest(httpService, newBytes)
                        respBytes = newResult.getResponse()
                        
                        if respBytes is None:
                            continue
                            
                        # Check response
                        respInfo = helpers.analyzeResponse(respBytes)
                        if respInfo is None:
                            continue
                            
                        status = respInfo.getStatusCode()
                        
                        if 200 <= status < 300:
                            # Use isFalsePositive from utils
                            is_fp = isFalsePositive(respBytes, falsePositiveKeywords, helpers)
                            if not is_fp:
                                pathStr = repr(fullPathWithQuery) # Report path with query
                                length = "N/A"
                                try:
                                    resp_headers = respInfo.getHeaders()
                                    for idx in range(1, resp_headers.size()):
                                         h = resp_headers.get(idx)
                                         if h and h.lower().startswith("content-length:"):
                                              length = h.split(":", 1)[1].strip()
                                              break
                                except Exception:
                                    pass
                                    
                                print("      ****** SUCCESS (Homoglyph Bypass - Last) ******")
                                print("      Path: " + pathStr)
                                print("      Original: " + repr(last_alpha_char))
                                print("      Homoglyph: " + repr(homoglyph))
                                
                                # Return values needed for the simple text format
                                result_data = {
                                    "type": "Homoglyph (Last)",
                                    "bypassed_path": pathStr,
                                    "original_char": repr(last_alpha_char),
                                    "homoglyph": repr(homoglyph),
                                    "index": last_alpha_idx,
                                    "status": status,
                                    "length": length,
                                    "http_message": newResult
                                }
                                return result_data
                    except Exception as e:
                        print("      (!) Error processing homoglyph '{}' (last): {}".format(repr(homoglyph), e))
                        # import traceback; traceback.print_exc(file=sys.stderr) # For debugging

    except Exception as outer_e:
        print("    (!) Error during homoglyph checks: {}".format(outer_e))
        # import traceback; traceback.print_exc(file=sys.stderr) # For debugging

    return None