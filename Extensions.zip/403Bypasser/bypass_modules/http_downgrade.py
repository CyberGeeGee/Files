# bypass_modules/http_downgrade.py

import java.util.ArrayList as ArrayList
import java.lang.String as String
import java.util.Arrays
import java.lang.reflect.Array
import java.lang.Byte

# Import helpers from utils
from utils import isFalsePositive

def check_http10(baseRequestResponse, httpService, falsePositiveKeywords, helpers, callbacks):
    print("  [Protocol] Testing HTTP/1.0 downgrade")
    requestInfo = None
    originalJavaHeaders = None
    originalBody = None
    try:
        requestInfo = helpers.analyzeRequest(baseRequestResponse)
        if requestInfo is None:
            print("    (!) Failed analyze.")
            return None

        originalJavaHeaders = requestInfo.getHeaders() # Keep as Java List
        raw_bytes = baseRequestResponse.getRequest()
        offset = requestInfo.getBodyOffset()
        if len(raw_bytes) > offset:
            originalBody = java.util.Arrays.copyOfRange(raw_bytes, offset, len(raw_bytes))
        else:
            originalBody = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)

        if not originalJavaHeaders or originalJavaHeaders.isEmpty():
            print("    (!) No headers.")
            return None

    except Exception as analysis_err:
         print("    (!) Error analyzing request for HTTP downgrade: {}".format(analysis_err))
         return None

    try:
        first_line = originalJavaHeaders.get(0)
        newLine = None
        if " HTTP/1.1" in first_line:
            newLine = first_line.replace(" HTTP/1.1", " HTTP/1.0", 1)
        elif " HTTP/2" in first_line:
            newLine = first_line.replace(" HTTP/2", " HTTP/1.0", 1)
        elif " HTTP/1.0" in first_line:
            print("    Skipping: Already HTTP/1.0.")
            return None
        else:
            print("    (!) Cannot determine HTTP version.")
            return None

        headers = ArrayList()
        headers.add(String(newLine))
        host_header = None
        for i in range(1, originalJavaHeaders.size()):
            hdr = originalJavaHeaders.get(i)
            if hdr and hdr.lower().startswith("host:"):
                host_header = hdr
                break
        if host_header:
            headers.add(host_header)
        else:
            host_from_service = httpService.getHost()
            if host_from_service:
                headers.add("Host: " + host_from_service)
                print("    Warn: Host header constructed from service info.")
            else:
                print("    (!) Critical Warning: Could not find or construct Host header.")
        print("    Downgraded to HTTP/1.0, using minimal headers.")

        newRequestBytes = helpers.buildHttpMessage(headers, originalBody)
        newRequestResult = callbacks.makeHttpRequest(httpService, newRequestBytes)
        responseBytes = newRequestResult.getResponse()
        if responseBytes is None:
            return None

        responseInfo = helpers.analyzeResponse(responseBytes)
        if responseInfo is None:
             print("      (!) Failed to analyze response for HTTP downgrade bypass.")
             return None

        newStatusCode = responseInfo.getStatusCode()
        if 200 <= newStatusCode < 300:
            # Use isFalsePositive from utils
            is_fp = isFalsePositive(responseBytes, falsePositiveKeywords, helpers)
            if not is_fp:
                requestUrlStr = str(requestInfo.getUrl())
                contentLength = "N/A"
                try:
                    resp_headers = responseInfo.getHeaders()
                    for idx in range(1, resp_headers.size()):
                        header = resp_headers.get(idx)
                        if header and header.lower().startswith("content-length:"):
                            contentLength = header.split(":", 1)[1].strip()
                            break
                except Exception: pass

                print("      ****** SUCCESS (HTTP Downgrade Bypass) ******")
                print("      URL: " + requestUrlStr)
                result_data = {
                    "type": "HTTP Downgrade",
                    "url": requestUrlStr,
                    "technique": "HTTP/1.0 (minimal headers)",
                    "status": newStatusCode,
                    "length": contentLength,
                    "http_message": newRequestResult
                }
                return result_data

    except Exception as e:
        print("    (!) Error testing HTTP/1.0: {}".format(e))

    return None