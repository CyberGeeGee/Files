# bypass_modules/method_change.py

import java.util.ArrayList as ArrayList
import java.lang.String as String
import java.util.Arrays
import java.lang.reflect.Array
import java.lang.Byte

# Import helpers from utils
from utils import isFalsePositive

def check_post_cl0(baseRequestResponse, httpService, falsePositiveKeywords, helpers, callbacks):
    print("  [Method] Testing POST + Content-Length: 0")
    requestInfo = None
    originalHeaders = None
    try:
        requestInfo = helpers.analyzeRequest(baseRequestResponse)
        if requestInfo is None:
            print("    (!) Failed analyze.")
            return None

        originalHeaders = list(requestInfo.getHeaders())
        if not originalHeaders or not originalHeaders[0].startswith("GET "):
            print("    Skipping: original method not GET.")
            return None

    except Exception as analysis_err:
        print("    (!) Error analyzing request for POST+CL:0: {}".format(analysis_err))
        return None

    try:
        headers = ArrayList()
        headers.add(String(originalHeaders[0].replace("GET ", "POST ", 1))) # Change method
        cl_found = False
        for i in range(1, len(originalHeaders)):
            header_line = originalHeaders[i]
            if header_line.lower().startswith("content-length:"):
                headers.add(String("Content-Length: 0"))
                cl_found=True
                print("    Replaced existing Content-Length.")
            else:
                headers.add(header_line)

        if not cl_found:
            headers.add(String("Content-Length: 0"))
            print("    Added Content-Length: 0.")

        print("    Changed method to POST.")

        emptyBody = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)
        newRequestBytes = helpers.buildHttpMessage(headers, emptyBody)
        newRequestResult = callbacks.makeHttpRequest(httpService, newRequestBytes)
        responseBytes = newRequestResult.getResponse()
        if responseBytes is None:
            return None

        responseInfo = helpers.analyzeResponse(responseBytes)
        if responseInfo is None:
            print("      (!) Failed to analyze response for POST+CL:0 bypass.")
            return None

        newStatusCode = responseInfo.getStatusCode()
        if 200 <= newStatusCode < 300:
            # Use isFalsePositive from utils
            is_fp = isFalsePositive(responseBytes, falsePositiveKeywords, helpers)
            if not is_fp:
                requestUrlStr = str(requestInfo.getUrl())
                contentLength = "N/A"
                try:
                    resp_headers = responseInfo.getHeaders()
                    for idx in range(1, resp_headers.size()):
                        header = resp_headers.get(idx)
                        if header and header.lower().startswith("content-length:"):
                            contentLength = header.split(":", 1)[1].strip()
                            break
                except Exception: pass

                print("      ****** SUCCESS (Method Change Bypass) ******")
                print("      URL: " + requestUrlStr)
                result_data = {
                    "type": "Method Change",
                    "url": requestUrlStr,
                    "technique": "POST + Content-Length: 0",
                    "status": newStatusCode,
                    "length": contentLength,
                    "http_message": newRequestResult
                }
                return result_data

    except Exception as e:
        print("    (!) Error testing POST+CL:0: {}".format(e))

    return None