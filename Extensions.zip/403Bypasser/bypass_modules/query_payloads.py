# bypass_modules/query_payloads.py

import java.util.ArrayList as ArrayList
import java.lang.String as String
import java.util.Arrays
import java.lang.reflect.Array
import java.lang.Byte
import cgi # For escaping

# Import helpers from utils
from utils import generatePayloads, isFalsePositive, analyze_original_request

def check_standard_query(baseRequestResponse, payload, httpService, falsePositiveKeywords, sensitive_indices, helpers, callbacks):
    print("  [Query] Testing payload: '{}' (Sensitive indices: {})".format(payload, sensitive_indices))
    
    originalRequestInfo = None
    originalUrl = None
    originalPath = "/"
    originalQuery = None
    originalHeadersJavaList = None
    originalBodyJavaBytes = None
    original_method = None
    original_protocol = "HTTP/1.1"

    try:
        # Use the analysis helper from utils
        analysis = analyze_original_request(baseRequestResponse, helpers)
        if not analysis:
            print("    (!) Analysis failed for Query Payload check.")
            return None # Analysis failed

        originalRequestInfo = analysis["requestInfo"]
        originalUrl = analysis["url"]
        originalPath = analysis["path"]
        originalQuery = analysis["query"] # Get query
        
        # Convert back to Java List for compatibility
        originalHeadersJavaList = ArrayList()
        if analysis["headers"]:
            for h in analysis["headers"]:
                originalHeadersJavaList.add(h)
        else:
            print("    (!) No headers found in analysis.")
            return None

        originalBodyJavaBytes = analysis["bodyBytes"]
        original_method = analysis["method"]
        original_protocol = analysis["protocol"]

    except Exception as analysis_err:
        print("    (!) Error analyzing request in query_payloads: {}".format(analysis_err))
        return None

    # --- Generate Paths ---
    payloadsToTest = generatePayloads(originalPath, payload, sensitive_indices, helpers) # Use util function
    if not payloadsToTest:
        return None
    print("    Paths to test: {}".format(len(payloadsToTest)))

    # --- Prepare Query String ---
    queryString = ""
    if originalQuery is not None and len(originalQuery) > 0:
        queryString = "?" + originalQuery

    # --- Test Generated Paths ---
    for pathToTest in payloadsToTest:
        try:
            if not pathToTest.startswith("/"):
                pathToTest = "/" + pathToTest

            # --- MODIFICATION: Append Query String ---
            fullPathWithQuery = pathToTest + queryString
            # --- END MODIFICATION ---

            # Build new request
            new_request_line_str = "{} {} {}".format(original_method, fullPathWithQuery, original_protocol)
            newHeadersList = ArrayList()
            newHeadersList.add(String(new_request_line_str))
            
            if originalHeadersJavaList.size() > 1:
                for i in range(1, originalHeadersJavaList.size()):
                    newHeadersList.add(originalHeadersJavaList.get(i))
            
            newRequestBytes = helpers.buildHttpMessage(newHeadersList, originalBodyJavaBytes)
            newRequestResult = callbacks.makeHttpRequest(httpService, newRequestBytes)
            responseBytes = newRequestResult.getResponse()

            # Check response existence
            if responseBytes is None:
                continue

            responseInfo = helpers.analyzeResponse(responseBytes)
            if responseInfo is None:
                print("      (!) Failed to analyze response for path '{}'".format(fullPathWithQuery))
                continue

            newRequestStatusCode = responseInfo.getStatusCode()

            # Check for bypass success (2xx and not FP)
            if 200 <= newRequestStatusCode < 300:
                # Use isFalsePositive from utils
                is_fp = isFalsePositive(responseBytes, falsePositiveKeywords, helpers)
                if not is_fp:
                    # Build details for reporting
                    portStr = ""
                    if originalUrl and originalUrl.getPort() not in [-1, originalUrl.getDefaultPort()]:
                        portStr = ":" + str(originalUrl.getPort())

                    # --- MODIFICATION: Use fullPathWithQuery ---
                    vulnUrlStr = "{}://{}{}{}".format(
                        originalUrl.getProtocol() if originalUrl else "http",
                        originalUrl.getHost() if originalUrl else httpService.getHost(),
                        portStr,
                        fullPathWithQuery # Use the path + query string
                    )
                    
                    contentLength = "N/A"
                    try:
                        # Safely get content length
                        resp_headers = responseInfo.getHeaders()
                        for idx in range(1, resp_headers.size()): # Start from 1 to skip status line
                            header = resp_headers.get(idx)
                            if header and header.lower().startswith("content-length:"):
                                contentLength = header.split(":", 1)[1].strip()
                                break
                    except Exception as cl_err:
                        print("      (!) Error getting Content-Length: {}".format(cl_err))
                        pass # Keep N/A

                    print("      ****** SUCCESS (Query Bypass) ******")
                    print("      URL: " + vulnUrlStr)
                    print("      Payload: " + payload)
                    print("      Path: " + fullPathWithQuery)

                    # Highlight payload in URL for display
                    displayPath = vulnUrlStr
                    try:
                        clean_p = payload.strip('/')
                        # Check against path part only, not the query string
                        if payload in pathToTest: 
                            displayPath = vulnUrlStr.replace(payload, "<b>" + payload + "</b>", 1)
                        elif clean_p and clean_p in pathToTest:
                            displayPath = vulnUrlStr.replace(clean_p, "<b>" + clean_p + "</b>", 1)
                    except Exception as highlight_err:
                        print("      (!) Error highlighting payload: {}".format(highlight_err))
                        pass # Ignore highlighting errors

                    # Return values needed for the simple text format
                    result_data = {
                        "type": "Query Payload",
                        "bypassed_url": displayPath, # Highlighted URL
                        "payload_used": payload,
                        "status": newRequestStatusCode,
                        "length": contentLength,
                        "http_message": newRequestResult
                    }
                    return result_data # Found bypass, return it

        except Exception as e:
            # Log errors for individual path tests
            print("      (!) Error processing path '{}': {}".format(pathToTest, e))
            # import traceback; traceback.print_exc(file=sys.stderr) # For debugging

    # No bypass found for this payload after testing all paths
    return None