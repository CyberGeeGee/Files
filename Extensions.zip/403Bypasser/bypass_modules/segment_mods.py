# bypass_modules/segment_mods.py

import java.util.ArrayList as ArrayList
import java.lang.String as String
import java.util.Arrays
import java.lang.reflect.Array
import java.lang.Byte

# Import helpers from utils
from utils import isFalsePositive, analyze_original_request

# --- Check Extra Slash ---
def check_extra_slash(baseRequestResponse, httpService, falsePositiveKeywords, sensitive_indices, helpers, callbacks):
    print("  [Segment Mod] Testing Extra Slash (//)")
    
    if sensitive_indices is None or not sensitive_indices:
        print("    Skipping: No sensitive indices identified.")
        return None

    # Use the analysis helper from utils
    analysis = analyze_original_request(baseRequestResponse, helpers)
    if not analysis:
        print("    (!) Analysis failed for Extra Slash check.")
        return None

    originalPath = analysis["path"]
    originalQuery = analysis["query"] # Get query
    originalHeaders = analysis["headers"]
    originalMethod = analysis["method"]
    originalProtocol = analysis["protocol"]
    originalBodyBytes = analysis["bodyBytes"]
    originalUrl = analysis["url"]
    
    segments = [s for s in originalPath.strip('/').split('/')]
    if not segments:
        print("    Skipping: No path segments found.")
        return None

    # --- Prepare Query String ---
    queryString = ""
    if originalQuery is not None and len(originalQuery) > 0:
        queryString = "?" + originalQuery

    for i in sensitive_indices:
        if i >= len(segments):
            continue # Index out of bounds

        print("    Testing extra slash before segment {}: '{}'".format(i, segments[i]))
        temp_segments = list(segments)
        
        # Construct path: /part1//sensitive/part3 or //sensitive/part2
        modifiedPath = ""
        for k, seg in enumerate(temp_segments):
            modifiedPath += "/"
            if k == i:
                modifiedPath += "/" # Add extra slash before sensitive segment
            modifiedPath += seg
            
        if originalPath.endswith('/'):
            modifiedPath += "/" # Preserve trailing slash

        try:
            # --- MODIFICATION: Append Query String ---
            fullPathWithQuery = modifiedPath + queryString
            # --- END MODIFICATION ---

            new_request_line = "{} {} {}".format(originalMethod, fullPathWithQuery, originalProtocol)
            newHeadersList = ArrayList()
            newHeadersList.add(String(new_request_line))
            
            if len(originalHeaders) > 1:
                for h_idx in range(1, len(originalHeaders)):
                    newHeadersList.add(originalHeaders[h_idx])
            
            newRequestBytes = helpers.buildHttpMessage(newHeadersList, originalBodyBytes)
            newRequestResult = callbacks.makeHttpRequest(httpService, newRequestBytes)
            responseBytes = newRequestResult.getResponse()
            
            if responseBytes is None:
                continue

            # Check response
            responseInfo = helpers.analyzeResponse(responseBytes)
            if responseInfo is None:
                continue
                
            newStatusCode = responseInfo.getStatusCode()
            
            if 200 <= newStatusCode < 300:
                is_fp = isFalsePositive(responseBytes, falsePositiveKeywords, helpers)
                if not is_fp:
                    contentLength = "N/A"
                    try:
                        resp_headers = responseInfo.getHeaders()
                        for idx in range(1, resp_headers.size()):
                            header = resp_headers.get(idx)
                            if header and header.lower().startswith("content-length:"):
                                contentLength = header.split(":", 1)[1].strip()
                                break
                    except Exception:
                        pass
                        
                    print("      ****** SUCCESS (Extra Slash Bypass) ******")
                    print("      Path: " + fullPathWithQuery)
                    
                    result_data = {
                        "type": "Extra Slash",
                        "url": str(originalUrl),
                        "technique": "Extra slash before segment {}".format(i),
                        "bypassed_path": fullPathWithQuery, # Report with query
                        "status": newStatusCode,
                        "length": contentLength,
                        "http_message": newRequestResult
                    }
                    return result_data
        except Exception as req_err:
            print("      (!) Error sending request for extra slash on segment {}: {}".format(i, req_err))
            continue
            
    # No success after checking all sensitive indices
    return None

# --- Check Append .json ---
def check_append_json(baseRequestResponse, httpService, falsePositiveKeywords, sensitive_indices, helpers, callbacks):
    print("  [Segment Mod] Testing Append .json")
    
    if sensitive_indices is None or not sensitive_indices:
         print("    Skipping: No sensitive indices identified.")
         return None

    # Use the analysis helper from utils
    analysis = analyze_original_request(baseRequestResponse, helpers)
    if not analysis:
        print("    (!) Analysis failed for Append .json check.")
        return None
    
    originalPath = analysis["path"]
    originalQuery = analysis["query"] # Get query
    originalHeaders = analysis["headers"]
    originalMethod = analysis["method"]
    originalProtocol = analysis["protocol"]
    originalBodyBytes = analysis["bodyBytes"]
    originalUrl = analysis["url"]
    
    segments = [s for s in originalPath.strip('/').split('/')]
    if not segments:
        print("    Skipping: No path segments found.")
        return None

    # --- Prepare Query String ---
    queryString = ""
    if originalQuery is not None and len(originalQuery) > 0:
        queryString = "?" + originalQuery

    for i in sensitive_indices:
        if i >= len(segments):
            continue

        print("    Testing append .json to segment {}: '{}'".format(i, segments[i]))
        temp_segments = list(segments)
        temp_segments[i] = segments[i] + ".json" # Append .json
        modifiedPath = "/" + "/".join(temp_segments)
        
        # Handle trailing slash carefully
        if originalPath.endswith('/') and i == len(segments) - 1:
             pass # Don't add trailing slash if .json is appended to last segment
        elif originalPath.endswith('/'):
             modifiedPath += "/"

        try:
            # --- MODIFICATION: Append Query String ---
            fullPathWithQuery = modifiedPath + queryString
            # --- END MODIFICATION ---

            new_request_line = "{} {} {}".format(originalMethod, fullPathWithQuery, originalProtocol)
            newHeadersList = ArrayList()
            newHeadersList.add(String(new_request_line))
            
            if len(originalHeaders) > 1:
                 for h_idx in range(1, len(originalHeaders)):
                     newHeadersList.add(originalHeaders[h_idx])
            
            newRequestBytes = helpers.buildHttpMessage(newHeadersList, originalBodyBytes)
            newRequestResult = callbacks.makeHttpRequest(httpService, newRequestBytes)
            responseBytes = newRequestResult.getResponse()
            
            if responseBytes is None:
                continue

            # Check response
            responseInfo = helpers.analyzeResponse(responseBytes)
            if responseInfo is None:
                continue
                
            newStatusCode = responseInfo.getStatusCode()
            
            if 200 <= newStatusCode < 300:
                is_fp = isFalsePositive(responseBytes, falsePositiveKeywords, helpers)
                if not is_fp:
                    contentLength = "N/A"
                    try:
                        resp_headers = responseInfo.getHeaders()
                        for idx in range(1, resp_headers.size()):
                             header = resp_headers.get(idx)
                             if header and header.lower().startswith("content-length:"):
                                 contentLength = header.split(":", 1)[1].strip()
                                 break
                    except Exception:
                        pass
                        
                    print("      ****** SUCCESS (Append .json Bypass) ******")
                    print("      Path: " + fullPathWithQuery)
                    
                    result_data = {
                        "type": "Append .json",
                        "url": str(originalUrl),
                        "technique": "Append .json to segment {}".format(i),
                        "bypassed_path": fullPathWithQuery, # Report with query
                        "status": newStatusCode,
                        "length": contentLength,
                        "http_message": newRequestResult
                    }
                    return result_data
        except Exception as req_err:
            print("      (!) Error sending request for append .json on segment {}: {}".format(i, req_err))
            continue
            
    return None

# --- Check Uppercase Last ---
def check_uppercase_last(baseRequestResponse, httpService, falsePositiveKeywords, sensitive_indices, helpers, callbacks):
    print("  [Segment Mod] Testing Uppercase Last Letter")
    
    if sensitive_indices is None or not sensitive_indices:
         print("    Skipping: No sensitive indices identified.")
         return None

    # Use the analysis helper from utils
    analysis = analyze_original_request(baseRequestResponse, helpers)
    if not analysis:
        print("    (!) Analysis failed for Uppercase Last check.")
        return None

    originalPath = analysis["path"]
    originalQuery = analysis["query"] # Get query
    originalHeaders = analysis["headers"]
    originalMethod = analysis["method"]
    originalProtocol = analysis["protocol"]
    originalBodyBytes = analysis["bodyBytes"]
    originalUrl = analysis["url"]
    
    segments = [s for s in originalPath.strip('/').split('/')]
    if not segments:
        print("    Skipping: No path segments found.")
        return None

    # --- Prepare Query String ---
    queryString = ""
    if originalQuery is not None and len(originalQuery) > 0:
        queryString = "?" + originalQuery

    for i in sensitive_indices:
        if i >= len(segments) or not segments[i]:
            continue # Skip empty segments

        segment = segments[i]
        
        # Only test if last char is lowercase
        if segment[-1].islower():
            modified_segment = segment[:-1] + segment[-1].upper()
            print("    Testing uppercase last letter for segment {}: '{}' -> '{}'".format(i, segment, modified_segment))

            temp_segments = list(segments)
            temp_segments[i] = modified_segment
            modifiedPath = "/" + "/".join(temp_segments)
            
            if originalPath.endswith('/'):
                modifiedPath += "/"

            try:
                # --- MODIFICATION: Append Query String ---
                fullPathWithQuery = modifiedPath + queryString
                # --- END MODIFICATION ---

                new_request_line = "{} {} {}".format(originalMethod, fullPathWithQuery, originalProtocol)
                newHeadersList = ArrayList()
                newHeadersList.add(String(new_request_line))
                
                if len(originalHeaders) > 1:
                     for h_idx in range(1, len(originalHeaders)):
                         newHeadersList.add(originalHeaders[h_idx])
                
                newRequestBytes = helpers.buildHttpMessage(newHeadersList, originalBodyBytes)
                newRequestResult = callbacks.makeHttpRequest(httpService, newRequestBytes)
                responseBytes = newRequestResult.getResponse()
                
                if responseBytes is None:
                    continue

                # Check response
                responseInfo = helpers.analyzeResponse(responseBytes)
                if responseInfo is None:
                    continue
                    
                newStatusCode = responseInfo.getStatusCode()
                
                if 200 <= newStatusCode < 300:
                    is_fp = isFalsePositive(responseBytes, falsePositiveKeywords, helpers)
                    if not is_fp:
                        contentLength = "N/A"
                        try:
                            resp_headers = responseInfo.getHeaders()
                            for idx in range(1, resp_headers.size()):
                                header = resp_headers.get(idx)
                                if header and header.lower().startswith("content-length:"):
                                    contentLength = header.split(":", 1)[1].strip()
                                    break
                        except Exception:
                            pass
                            
                        print("      ****** SUCCESS (Uppercase Last Bypass) ******")
                        print("      Path: " + fullPathWithQuery)
                        
                        result_data = {
                            "type": "Uppercase Last Letter",
                            "url": str(originalUrl),
                            "technique": "Uppercase last letter of segment {}".format(i),
                            "bypassed_path": fullPathWithQuery, # Report with query
                            "status": newStatusCode,
                            "length": contentLength,
                            "http_message": newRequestResult
                        }
                        return result_data
            except Exception as req_err:
                print("      (!) Error sending request for uppercase last on segment {}: {}".format(i, req_err))
                continue
        else:
            print("    Skipping uppercase for segment {}: last char not lowercase.".format(i))
            
    return None

# --- Check Unicode Slash ---
def check_unicode_slash(baseRequestResponse, httpService, falsePositiveKeywords, sensitive_indices, helpers, callbacks):
    print("  [Segment Mod] Testing Unicode Slash (%ef%bc%8f)")
    unicode_slash_encoded = "%ef%bc%8f" # Fullwidth solidus URL Encoded
    
    if sensitive_indices is None or not sensitive_indices:
         print("    Skipping: No sensitive indices identified.")
         return None

    # Use the analysis helper from utils
    analysis = analyze_original_request(baseRequestResponse, helpers)
    if not analysis:
        print("    (!) Analysis failed for Unicode Slash check.")
        return None

    originalPath = analysis["path"]
    originalQuery = analysis["query"] # Get query
    originalHeaders = analysis["headers"]
    originalMethod = analysis["method"]
    originalProtocol = analysis["protocol"]
    originalBodyBytes = analysis["bodyBytes"]
    originalUrl = analysis["url"]
    
    segments = [s for s in originalPath.strip('/').split('/')]
    if not segments:
        print("    Skipping: No path segments found.")
        return None

    # --- Prepare Query String ---
    queryString = ""
    if originalQuery is not None and len(originalQuery) > 0:
        queryString = "?" + originalQuery

    for i in sensitive_indices:
        if i >= len(segments):
            continue

        print("    Testing unicode slash before segment {}: '{}'".format(i, segments[i]))
        temp_segments = list(segments)
        modifiedPath = ""
        start_index = 0
        
        # Handle leading slash case separately
        if i == 0 and originalPath.startswith('/'):
            # Replace leading slash if first segment is sensitive
            modifiedPath = unicode_slash_encoded + temp_segments[0]
            start_index = 1
        elif originalPath.startswith('/'):
            modifiedPath = "/" + temp_segments[0] # Start with leading slash and first segment
            start_index = 1
        else:
            # Path doesn't start with slash, first segment is index 0
            if i == 0: # Cannot replace a slash that isn't there
                 print("      Skipping unicode slash for first segment (no preceding slash)")
                 continue
            else:
                 modifiedPath = temp_segments[0]
                 start_index = 1

        # Append remaining segments with appropriate slash
        for k in range(start_index, len(temp_segments)):
            if k == i:
                modifiedPath += unicode_slash_encoded # Replace slash before sensitive segment
            else:
                modifiedPath += "/" # Use normal slash
            modifiedPath += temp_segments[k]

        # Preserve trailing slash if present
        if originalPath.endswith('/') and not modifiedPath.endswith('/'):
            modifiedPath += "/"

        try:
            # --- MODIFICATION: Append Query String ---
            fullPathWithQuery = modifiedPath + queryString
            # --- END MODIFICATION ---

            # Path already contains the encoded form, pass directly
            new_request_line = "{} {} {}".format(originalMethod, fullPathWithQuery, originalProtocol)
            newHeadersList = ArrayList()
            newHeadersList.add(String(new_request_line))
            
            if len(originalHeaders) > 1:
                 for h_idx in range(1, len(originalHeaders)):
                     newHeadersList.add(originalHeaders[h_idx])
            
            newRequestBytes = helpers.buildHttpMessage(newHeadersList, originalBodyBytes)
            newRequestResult = callbacks.makeHttpRequest(httpService, newRequestBytes)
            responseBytes = newRequestResult.getResponse()
            
            if responseBytes is None:
                continue

            # Check response
            responseInfo = helpers.analyzeResponse(responseBytes)
            if responseInfo is None:
                continue
                
            newStatusCode = responseInfo.getStatusCode()
            
            if 200 <= newStatusCode < 300:
                is_fp = isFalsePositive(responseBytes, falsePositiveKeywords, helpers)
                if not is_fp:
                    contentLength = "N/A"
                    try:
                        resp_headers = responseInfo.getHeaders()
                        for idx in range(1, resp_headers.size()):
                             header = resp_headers.get(idx)
                             if header and header.lower().startswith("content-length:"):
                                 contentLength = header.split(":", 1)[1].strip()
                                 break
                    except Exception:
                        pass
                        
                    print("      ****** SUCCESS (Unicode Slash Bypass) ******")
                    print("      Path: " + fullPathWithQuery)
                    
                    result_data = {
                        "type": "Unicode Slash",
                        "url": str(originalUrl),
                        "technique": "Replace / with {} before segment {}".format(unicode_slash_encoded, i),
                        "bypassed_path": fullPathWithQuery, # Report with query
                        "status": newStatusCode,
                        "length": contentLength,
                        "http_message": newRequestResult
                    }
                    return result_data
        except Exception as req_err:
            print("      (!) Error sending request for unicode slash on segment {}: {}".format(i, req_err))
            continue
            
    return None