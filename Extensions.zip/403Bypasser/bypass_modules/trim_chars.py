# bypass_modules/trim_chars.py

import java.util.ArrayList as ArrayList
import java.lang.String as String
import java.util.Arrays
import java.lang.reflect.Array
import java.lang.Byte

# Import helpers and config
from utils import isFalsePositive, analyze_original_request
from config import trimCharsToTest # Import the list

def check_trim_chars(baseRequestResponse, httpService, falsePositiveKeywords, sensitive_indices, helpers, callbacks):
    print("  [Segment Mod] Testing Trim Characters")
    
    if sensitive_indices is None or not sensitive_indices:
         print("    Skipping: No sensitive indices identified.")
         return None

    # Use the analysis helper from utils
    analysis = analyze_original_request(baseRequestResponse, helpers)
    if not analysis:
        print("    (!) Analysis failed for Trim Characters check.")
        return None

    # Use unicode path and query from analysis
    originalPathUnicode = analysis["pathUnicode"]
    originalQuery = analysis["query"]
    originalHeaders = analysis["headers"]
    originalMethod = analysis["method"]
    originalProtocol = analysis["protocol"]
    originalBodyBytes = analysis["bodyBytes"]
    originalUrl = analysis["url"]
    
    segmentsUnicode = []
    try:
        # Ensure segments are unicode
        segmentsUnicode = [s.decode('utf-8') if isinstance(s, str) else s for s in originalPathUnicode.strip('/').split('/')]
    except Exception as e:
        print("    (!) Error creating unicode segments: {}".format(e))
        return None

    # --- Prepare Query String ---
    queryString = u"" # Use unicode string
    if originalQuery is not None and len(originalQuery) > 0:
        try:
            # Try to decode query to unicode as well
            queryString = u"?" + (originalQuery.decode('utf-8') if isinstance(originalQuery, str) else originalQuery)
        except UnicodeDecodeError:
            queryString = u"?" + originalQuery.decode('latin-1', 'ignore') # Fallback

    for i in sensitive_indices:
        if i >= len(segmentsUnicode):
            continue

        for trim_char in trimCharsToTest: # Use list from config
            
            # --- Test Prepending ---
            print("    Testing trim char U+{:04X} prepended to segment {}: '{}'".format(ord(trim_char), i, repr(segmentsUnicode[i])))
            temp_segments = list(segmentsUnicode)
            
            # Prepend the Unicode trim character
            temp_segments[i] = trim_char + segmentsUnicode[i]
            
            # Join using unicode segments and slashes
            modifiedPathUnicode = u"/" + u"/".join(temp_segments)
            if originalPathUnicode.endswith('/'):
                modifiedPathUnicode += u"/"

            try:
                # --- MODIFICATION: Append Query String ---
                fullPathWithQuery = modifiedPathUnicode + queryString
                # --- END MODIFICATION ---

                new_request_line = unicode(originalMethod) + u" " + fullPathWithQuery + u" " + unicode(originalProtocol)
                newHeadersList = ArrayList()
                
                # Let Jython handle encoding when creating Java String
                newHeadersList.add(String(new_request_line)) 
                
                if len(originalHeaders) > 1:
                    for h_idx in range(1, len(originalHeaders)):
                        newHeadersList.add(originalHeaders[h_idx])
                
                newRequestBytes = helpers.buildHttpMessage(newHeadersList, originalBodyBytes)
                newRequestResult = callbacks.makeHttpRequest(httpService, newRequestBytes)
                responseBytes = newRequestResult.getResponse()
                
                if responseBytes is None:
                    continue

                # Check response
                responseInfo = helpers.analyzeResponse(responseBytes)
                if responseInfo is None:
                    continue
                    
                newStatusCode = responseInfo.getStatusCode()
                
                if 200 <= newStatusCode < 300:
                    # Use isFalsePositive from utils
                    is_fp = isFalsePositive(responseBytes, falsePositiveKeywords, helpers)
                    if not is_fp:
                        contentLength = "N/A"
                        try:
                            resp_headers = responseInfo.getHeaders()
                            for idx in range(1, resp_headers.size()):
                                header = resp_headers.get(idx)
                                if header and header.lower().startswith("content-length:"):
                                    contentLength = header.split(":", 1)[1].strip()
                                    break
                        except Exception:
                            pass
                            
                        print("      ****** SUCCESS (Trim Char Bypass - Prepend) ******")
                        print("      Path: " + repr(fullPathWithQuery)) # Use repr for clarity
                        print("      Char: U+{:04X}".format(ord(trim_char)))
                        
                        result_data = {
                            "type": "Trim Character (Prepend)",
                            "url": str(originalUrl),
                            "technique": "Prepend U+{:04X} to segment {}".format(ord(trim_char), i),
                            "bypassed_path": repr(fullPathWithQuery),
                            "status": newStatusCode,
                            "length": contentLength,
                            "http_message": newRequestResult
                        }
                        return result_data
            except Exception as req_err:
                print("      (!) Error sending request for prepend trim char U+{:04X} on segment {}: {}".format(ord(trim_char), i, req_err))
                continue

            # --- Test Appending ---
            print("    Testing trim char U+{:04X} appended to segment {}: '{}'".format(ord(trim_char), i, repr(segmentsUnicode[i])))
            temp_segments_append = list(segmentsUnicode)
            
            # Append the Unicode trim character
            temp_segments_append[i] = segmentsUnicode[i] + trim_char
            
            # Join using unicode segments and slashes
            modifiedPathUnicodeAppend = u"/" + u"/".join(temp_segments_append)
            if originalPathUnicode.endswith('/'):
                 modifiedPathUnicodeAppend += u"/"

            try:
                # --- MODIFICATION: Append Query String ---
                fullPathWithQueryAppend = modifiedPathUnicodeAppend + queryString
                # --- END MODIFICATION ---

                new_request_line_append = unicode(originalMethod) + u" " + fullPathWithQueryAppend + u" " + unicode(originalProtocol)
                newHeadersListAppend = ArrayList()
                
                # Let Jython handle encoding
                newHeadersListAppend.add(String(new_request_line_append)) 
                
                if len(originalHeaders) > 1:
                    for h_idx in range(1, len(originalHeaders)):
                        newHeadersListAppend.add(originalHeaders[h_idx])
                
                newRequestBytesAppend = helpers.buildHttpMessage(newHeadersListAppend, originalBodyBytes)
                newRequestResultAppend = callbacks.makeHttpRequest(httpService, newRequestBytesAppend)
                responseBytesAppend = newRequestResultAppend.getResponse()
                
                if responseBytesAppend is None:
                    continue

                # Check response
                responseInfoAppend = helpers.analyzeResponse(responseBytesAppend)
                if responseInfoAppend is None:
                    continue
                    
                newStatusCodeAppend = responseInfoAppend.getStatusCode()
                
                if 200 <= newStatusCodeAppend < 300:
                    # Use isFalsePositive from utils
                    is_fp_append = isFalsePositive(responseBytesAppend, falsePositiveKeywords, helpers)
                    if not is_fp_append:
                        contentLengthAppend = "N/A"
                        try:
                            resp_headers = responseInfoAppend.getHeaders()
                            for idx in range(1, resp_headers.size()):
                                header = resp_headers.get(idx)
                                if header and header.lower().startswith("content-length:"):
                                    contentLengthAppend = header.split(":", 1)[1].strip()
                                    break
                        except Exception:
                            pass
                            
                        print("      ****** SUCCESS (Trim Char Bypass - Append) ******")
                        print("      Path: " + repr(fullPathWithQueryAppend)) # Use repr for clarity
                        print("      Char: U+{:04X}".format(ord(trim_char)))
                        
                        result_data = {
                            "type": "Trim Character (Append)",
                            "url": str(originalUrl),
                            "technique": "Append U+{:04X} to segment {}".format(ord(trim_char), i),
                            "bypassed_path": repr(fullPathWithQueryAppend),
                            "status": newStatusCodeAppend,
                            "length": contentLengthAppend,
                            "http_message": newRequestResultAppend
                        }
                        return result_data
            except Exception as req_err_append:
                print("      (!) Error sending request for append trim char U+{:04X} on segment {}: {}".format(ord(trim_char), i, req_err_append))
                continue
                
    # No success after checking all sensitive indices and trim chars
    return None