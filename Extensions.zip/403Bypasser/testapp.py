# test_app_v3.py
from flask import Flask, request, make_response
import sys
# Use try/except for Python 2/3 compatibility regarding unquote_plus
try:
    # Python 3
    from urllib.parse import unquote_plus
except ImportError:
    # Python 2 Fallback
    from urllib import unquote_plus


# --- Payloads and Homoglyphs from the Burp Extension ---
# (Keep these definitions as they are needed for the check functions)

defaultQueryPayloads = [
    "%09", "%20", "%23", "%2e", "%2f", ".", ";", "..;", "%2e%2e;", ";%09",
    ";%09..", ";%09..;", ";%2f..", "*", "xpto/%2e%2e", "xpto/..", "xpto/..;"
]
decodedQueryPayloads = {
    "%09": "\t", "%20": " ", "%23": "#", "%2e": ".", "%2f": "/", ".": ".",
    ";": ";", "..;": "..;", "%2e%2e;": "..;", ";%09": ";\t", ";%09..": ";\t..",
    ";%09..;": ";\t..;", ";%2f..": ";/..", "*": "*", "xpto/%2e%2e": "xpto/.",
    "xpto/..": "xpto/..", "xpto/..;": "xpto/..;"
}
rawQueryPayloadsForCheck = set(defaultQueryPayloads) | set(decodedQueryPayloads.values()) | \
                           {payload + '/' for payload in decodedQueryPayloads.values()} | \
                           {'/' + payload for payload in decodedQueryPayloads.values()}

# (Header and Homoglyph definitions remain the same as v2 - omitted for brevity, but should be included in a runnable file)
# --- Headers ---
HEADERS_WITH_PATHS_TO_ADAPT = {"x-original-url", "x-override-url", "x-rewrite-url"}
defaultHeaderPayloadsForUI = [
    "Base-Url: 127.0.0.1", "CF-Connecting_IP: 127.0.0.1", "CF-Connecting-IP: 127.0.0.1", # ... (rest of UI headers) ...
    "X-True-IP: 127.0.0.1", "X-WAP-Profile: 127.0.0.1",
]
internalDefaultHeaderPayloads = defaultHeaderPayloadsForUI + [
    "X-Original-Url: /admin", "X-Original-URL: /admin", "X-Override-Url: /admin",
    "X-Rewrite-Url: /admin", "X-Rewrite-URL: /admin"
]
headerChecks = {}
for header_line in internalDefaultHeaderPayloads: # Use internal list for checks
    try:
        name, value = header_line.split(":", 1)
        headerChecks[name.strip().lower()] = value.strip()
    except ValueError: pass # Ignore errors

# --- Homoglyphs ---
homoglyphMap = { # ... (full map definition) ...
    "a": [ u"\u0430", u"\u00e0", u"\u00e1", u"\u1ea1", u"\u0105" ], "c": [ u"\u0441", u"\u0188", u"\u010b" ],
    "d": [ u"\u0501", u"\u0257" ], "e": [ u"\u0435", u"\u1eb9", u"\u0117", u"\u00e9", u"\u00e8" ],
    "g": [ u"\u0121" ], "h": [ u"\u04bb" ], "i": [ u"\u0456", u"\u00ed", u"\u00ec", u"\u00ef" ],
    "j": [ u"\u0458", u"\u029d" ], "k": [ u"\u03ba" ], "l": [ u"\u04cf", u"\u1e37" ], "n": [ u"\u0578" ],
    "o": [ u"\u043e", u"\u03bf", u"\u0585", u"\u022f", u"\u1ecd", u"\u1ecf", u"\u01a1", u"\u00f6", u"\u00f3", u"\u00f2" ],
    "p": [ u"\u0440" ], "q": [ u"\u0566" ], "s": [ u"\u0282" ], "u": [ u"\u03c5", u"\u057d", u"\u00fc", u"\u00fa", u"\u00f9" ],
    "v": [ u"\u03bd", u"\u0475" ], "x": [ u"\u0445", u"\u04b3" ], "y": [ u"\u0443", u"\u00fd" ],
    "z": [ u"\u0290", u"\u017c" ]
}
allHomoglyphs = set(glyph for char_list in homoglyphMap.values() for glyph in char_list)


# --- Flask App ---
app = Flask(__name__)

# --- Response Messages ---
SUCCESS_MESSAGE_GENERIC = b"<html><body><h1>200 OK (Bypass Successful for this category)</h1></body></html>"
# Modified success message for query path to include detected payload
SUCCESS_MESSAGE_QUERY = b"<html><body><h1>200 OK (Bypass Successful - Payload: {payload})</h1></body></html>"
FORBIDDEN_MESSAGE = b"<html><body><h1>403 Forbidden (Bypass condition not met)</h1></body></html>"
NOT_FOUND_MESSAGE = b"<html><body><h1>404 Not Found</h1></body></html>"
WELCOME_MESSAGE = b"""
<html><body>
<h1>403 Bypasser Test Server Running (V3 - Updated Logic)</h1>
<p>Target the following endpoints to test specific bypass categories:</p>
<ul>
    <li><b>/test/query_path/...</b> - Tests path manipulation. Returns 200 OK with detected payload if successful.</li>
    <li><b>/test/header_injection</b> - Tests header injection.</li>
    <li><b>/test/method_change</b> - Tests changing GET to POST with Content-Length: 0.</li>
    <li><b>/test/http_downgrade</b> - Tests downgrading to HTTP/1.0.</li>
    <li><b>/test/homoglyph/...</b> - Tests using homoglyph characters in the path.</li>
    <li><b>/test/path_sensitivity/base/sensitive/final/</b> - Tests preliminary check & actual bypasses:
        <ul>
            <li>Requesting the exact path returns 403 + 'Proxy Block Body'.</li>
            <li>Modifying 'base' or 'final' (e.g., /basX/...) returns 403 + 'Proxy Block Body'.</li>
            <li>Modifying 'sensitive' (e.g., /base/sensitivX/...) returns <b>404 Not Found</b> (signaling sensitivity).</li>
            <li>Adding a query bypass payload (e.g., /base/sensitive/final/%09/) returns <b>200 OK</b> (simulating successful bypass).</li>
        </ul>
    </li>
</ul>
<p>Each endpoint returns 403 Forbidden by default unless the specific bypass condition is met.</p>
</body></html>
"""

# Specific body for path sensitivity testing
PROXY_BLOCK_BODY = b"<html><body><h1>403 Forbidden - Blocked by Proxy Rule</h1></body></html>"
APP_BLOCK_BODY = b"<html><body><h1>403 Forbidden - Blocked by Application</h1></body></html>" # Example different body


# --- Bypass Check Functions ---

# MODIFIED: Returns the detected payload string or None
def check_query_bypass(path, target_prefix):
    """Checks if the path contains indicators of query payload bypasses relative to a target prefix. Returns detected payload or None."""
    decoded_path = unquote_plus(path)
    print("  [Check Query] Path: {}, Decoded: {}".format(repr(path), repr(decoded_path)))

    # Check 1: Direct match or containment of raw/decoded payloads *within the path structure*
    # Check longer/more specific payloads first
    sorted_payloads = sorted(list(rawQueryPayloadsForCheck), key=len, reverse=True)

    for payload in sorted_payloads:
        # More specific checks to avoid overly broad matches
        if payload in ['.', '/'] and len(payload) == 1:
            if "/./" in path or "/../" in path or path.endswith("/.") or path.endswith("/.."):
                 print("  !!! Query Bypass Detected (Path Traversal Pattern): {}".format(repr(path)))
                 return payload # Return the pattern indicator (e.g., '.')
            if path.endswith("/..;") or "/..;/" in path:
                 print("  !!! Query Bypass Detected (..; Pattern): {}".format(repr(path)))
                 return "..;" # Return the pattern indicator
            continue

        # Check if payload appears after the base test path prefix
        # Use original 'payload' string for returning, as it's the one from the list
        original_payload_form = payload # Store the form we are checking against
        # Check if payload exists in the part of the path *after* the prefix
        # This handles cases like /prefix/payload or /prefix/something/payload
        if target_prefix in path and payload in path[len(target_prefix):]:
             print("  !!! Query Bypass Detected: Payload '{}' found after prefix in path '{}'".format(original_payload_form, repr(path)))
             return original_payload_form
        # Also check decoded path, but return the original payload form
        if target_prefix in decoded_path and payload in decoded_path[len(target_prefix):] and payload != path:
             print("  !!! Query Bypass Detected: Payload '{}' found after prefix in decoded path '{}'".format(original_payload_form, repr(decoded_path)))
             return original_payload_form

    # Check 2: Specific patterns (simplified) - Payload used as a whole segment
    relative_path = path[len(target_prefix):] if path.startswith(target_prefix) else path
    parts = [p for p in relative_path.split('/') if p]
    for payload in sorted_payloads: # Check longer payloads first
        if payload in ['.', '/']: continue # Skip single dot/slash here

        original_payload_form = payload
        if payload in parts:
            print("  !!! Query Bypass Detected: Payload '{}' used as path segment in '{}'".format(original_payload_form, repr(path)))
            return original_payload_form
        # Check 3: Prefix/Suffix (less common for these payloads but check anyway)
        for part in parts:
             if (part.startswith(payload) and len(part) > len(payload)) or \
                (part.endswith(payload) and len(part) > len(payload)):
                 print("  !!! Query Bypass Detected: Payload '{}' prefix/suffix in segment '{}' of path '{}'".format(original_payload_form, part, repr(path)))
                 return original_payload_form

    # Check 4: Specific known patterns
    if "xpto/.." in path:
        print("  !!! Query Bypass Detected (xpto/..): {}".format(repr(path)))
        return "xpto/.."

    return None # No bypass detected

# (Other check functions: check_header_bypass, check_method_bypass, check_http_downgrade, check_homoglyph_bypass remain the same as v2)
def check_header_bypass(headers):
    """Checks if specific bypass headers are present with correct values."""
    print("  [Check Headers] Headers: {}".format(headers))
    for header_name_lower, expected_value in headerChecks.items():
        if header_name_lower in headers:
            actual_value = headers.get(header_name_lower)
            if actual_value == expected_value:
                print("  !!! Header Bypass Detected: Header '{}: {}'".format(header_name_lower, actual_value))
                return True
    return False

def check_method_bypass(method, headers):
    """Checks for POST method with Content-Length: 0."""
    print("  [Check Method] Method: {}, Headers: {}".format(method, headers))
    if method == 'POST' and headers.get('content-length') == '0':
        print("  !!! Method Bypass Detected: POST with Content-Length: 0")
        return True
    return False

def check_http_downgrade(request_environ):
    """Checks if the protocol is HTTP/1.0."""
    protocol = request_environ.get('SERVER_PROTOCOL')
    print("  [Check HTTP Downgrade] Protocol: {}".format(protocol))
    if protocol == 'HTTP/1.0':
        print("  !!! HTTP Downgrade Detected: Protocol {}".format(protocol))
        return True
    return False

def check_homoglyph_bypass(path, target_prefix):
    """Checks if the path contains any known homoglyph characters after the target prefix."""
    print("  [Check Homoglyph] Path: {}".format(repr(path)))
    if sys.version_info[0] < 3 and isinstance(path, str):
       try: path_unicode = path.decode('utf-8')
       except UnicodeDecodeError: return False
    else: path_unicode = path
    relative_path = path_unicode[len(target_prefix):] if path_unicode.startswith(target_prefix) else path_unicode
    first_rel_char = relative_path[0] if relative_path else None
    last_rel_char = relative_path[-1] if relative_path else None
    if first_rel_char and first_rel_char in allHomoglyphs:
         print("  !!! Homoglyph Bypass Detected: First char '{}' (U+{:04X}) in relative path '{}'".format(first_rel_char, ord(first_rel_char), repr(relative_path)))
         return True
    if last_rel_char and last_rel_char != first_rel_char and last_rel_char in allHomoglyphs:
         print("  !!! Homoglyph Bypass Detected: Last char '{}' (U+{:04X}) in relative path '{}'".format(last_rel_char, ord(last_rel_char), repr(relative_path)))
         return True
    for char in relative_path:
        if char in allHomoglyphs:
            print("  !!! Homoglyph Bypass Detected: Char '{}' (U+{:04X}) found in relative path '{}'".format(char, ord(char), repr(relative_path)))
            return True
    return False

# --- Route Handlers ---

@app.route('/')
def handle_root():
    """Handles requests to the root path."""
    print("\nRequest to /")
    return make_response(WELCOME_MESSAGE, 200)

# 1. Query Path Bypass Endpoint (Modified Response)
@app.route('/test/query_path', defaults={'subpath': ''}, methods=['GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'OPTIONS'])
@app.route('/test/query_path/<path:subpath>', methods=['GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'OPTIONS'])
def handle_query_path_test(subpath):
    """Tests for query path manipulation bypasses."""
    endpoint_prefix = '/test/query_path'
    full_path = request.path
    print("\n--- Request to {} ---".format(endpoint_prefix))
    detected_payload = check_query_bypass(full_path, endpoint_prefix) # Get detected payload
    if detected_payload is not None:
        # Include detected payload in the response body
        try:
            # Ensure payload is bytes for replacement
            payload_bytes = detected_payload.encode('utf-8', 'ignore')
            success_body = SUCCESS_MESSAGE_QUERY.replace(b'{payload}', payload_bytes)
        except Exception:
             # Fallback if encoding/replacement fails
             success_body = SUCCESS_MESSAGE_GENERIC
        return make_response(success_body, 200)
    else:
        print("  --- No Query Path Bypass Detected ---")
        return make_response(FORBIDDEN_MESSAGE, 403)

# 2. Header Injection Bypass Endpoint
@app.route('/test/header_injection', methods=['GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'OPTIONS'])
def handle_header_test():
    """Tests for header injection bypasses."""
    endpoint_prefix = '/test/header_injection'
    headers = request.headers
    print("\n--- Request to {} ---".format(endpoint_prefix))
    if check_header_bypass(headers):
        return make_response(SUCCESS_MESSAGE_GENERIC, 200)
    else:
        print("  --- No Header Bypass Detected ---")
        return make_response(FORBIDDEN_MESSAGE, 403)

# 3. Method Change Bypass Endpoint
@app.route('/test/method_change', methods=['GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'OPTIONS'])
def handle_method_change_test():
    """Tests for GET -> POST + CL:0 bypass."""
    endpoint_prefix = '/test/method_change'
    method = request.method
    headers = request.headers
    print("\n--- Request to {} ---".format(endpoint_prefix))
    if check_method_bypass(method, headers):
        return make_response(SUCCESS_MESSAGE_GENERIC, 200)
    else:
        print("  --- No Method Bypass Detected (or method not POST w/ CL:0) ---")
        return make_response(FORBIDDEN_MESSAGE, 403)

# 4. HTTP Downgrade Bypass Endpoint
@app.route('/test/http_downgrade', methods=['GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'OPTIONS'])
def handle_http_downgrade_test():
    """Tests for HTTP/1.0 downgrade bypass."""
    endpoint_prefix = '/test/http_downgrade'
    env = request.environ
    print("\n--- Request to {} ---".format(endpoint_prefix))
    if check_http_downgrade(env):
        return make_response(SUCCESS_MESSAGE_GENERIC, 200)
    else:
        print("  --- No HTTP Downgrade Detected ---")
        return make_response(FORBIDDEN_MESSAGE, 403)

# 5. Homoglyph Bypass Endpoint
@app.route('/test/homoglyph', defaults={'subpath': ''}, methods=['GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'OPTIONS'])
@app.route('/test/homoglyph/<path:subpath>', methods=['GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'OPTIONS'])
def handle_homoglyph_test(subpath):
    """Tests for homoglyph character bypasses."""
    endpoint_prefix = '/test/homoglyph'
    full_path = request.path
    print("\n--- Request to {} ---".format(endpoint_prefix))
    if check_homoglyph_bypass(full_path, endpoint_prefix):
        return make_response(SUCCESS_MESSAGE_GENERIC, 200)
    else:
        print("  --- No Homoglyph Bypass Detected ---")
        return make_response(FORBIDDEN_MESSAGE, 403)

# 6. Path Sensitivity Test Endpoint (MODIFIED LOGIC)
PATH_SENS_BASE = '/test/path_sensitivity'
PATH_SENS_FULL = '/test/path_sensitivity/base/sensitive/final' # Note: trailing slash handled below
PATH_SENS_SEGMENTS = ['base', 'sensitive', 'final']
PATH_SENS_SENSITIVE_IDX = 1 # 'sensitive' is the target segment (0-based index)

@app.route(PATH_SENS_BASE + '/<path:subpath>', methods=['GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'OPTIONS'])
def handle_path_sensitivity_test(subpath):
    """
    Simulates path sensitivity for preliminary checks AND handles actual bypasses.
    """
    requested_path = PATH_SENS_BASE + '/' + subpath
    # Normalize trailing slash for comparison
    requested_path_norm = requested_path.rstrip('/')
    target_path_norm = PATH_SENS_FULL # Already without trailing slash

    print("\n--- Request to Path Sensitivity Test ---")
    print("  Requested Path: {}".format(repr(requested_path)))
    print("  Normalized Path: {}".format(repr(requested_path_norm)))
    print("  Target Path: {}".format(repr(target_path_norm)))

    # Case 1: Exact match (or with trailing slash) -> Original 403
    if requested_path_norm == target_path_norm:
        print("  -> Exact path match. Returning original 403.")
        return make_response(PROXY_BLOCK_BODY, 403)

    # Case 2: Check for simple segment modification (for preliminary check simulation)
    is_segment_modification_test = False
    try:
        req_segments = [s for s in subpath.strip('/').split('/')]
        if len(req_segments) == len(PATH_SENS_SEGMENTS):
            modified_index = -1
            diff_count = 0
            for i in range(len(req_segments)):
                if req_segments[i] != PATH_SENS_SEGMENTS[i]:
                    modified_index = i
                    diff_count += 1
            # Check if exactly one segment differs and it's a simple modification (like last char changed)
            if diff_count == 1 and \
               ((len(req_segments[modified_index]) > 1 and req_segments[modified_index][:-1] == PATH_SENS_SEGMENTS[modified_index][:-1]) or \
                (len(req_segments[modified_index]) == len(PATH_SENS_SEGMENTS[modified_index]) + 1 and req_segments[modified_index].startswith(PATH_SENS_SEGMENTS[modified_index]))):
                # This looks like the specific modification test from preliminaryPathCheck
                is_segment_modification_test = True
                print("  -> Detected as segment modification test. Modified index: {}".format(modified_index))
                if modified_index == PATH_SENS_SENSITIVE_IDX:
                    # Sensitive segment modified -> Return 404 Not Found
                    print("  -> SENSITIVE segment modified. Returning 404 Not Found.")
                    return make_response(NOT_FOUND_MESSAGE, 404)
                else:
                    # Non-sensitive segment modified -> Same 403 response
                    print("  -> NON-SENSITIVE segment modified. Returning original 403.")
                    return make_response(PROXY_BLOCK_BODY, 403)

    except Exception as e:
        print("  (!) Error during segment modification check: {}".format(e))
        # Continue to bypass checks if segment analysis fails

    # Case 3: If it wasn't an exact match or a simple segment modification test,
    # check for actual bypass payloads (e.g., query payloads added)
    if not is_segment_modification_test:
        print("  -> Not an exact match or simple segment mod. Checking for bypass payloads...")
        # Check for query bypass payloads
        detected_payload = check_query_bypass(requested_path, PATH_SENS_BASE) # Check against base path
        if detected_payload is not None:
            print("  -> Query bypass payload detected!")
            try:
                payload_bytes = detected_payload.encode('utf-8', 'ignore')
                success_body = SUCCESS_MESSAGE_QUERY.replace(b'{payload}', payload_bytes)
            except Exception:
                 success_body = SUCCESS_MESSAGE_GENERIC
            return make_response(success_body, 200)

        # (Add checks for other bypass types like homoglyphs if needed for this endpoint)
        # detected_homoglyph = check_homoglyph_bypass(requested_path, PATH_SENS_BASE)
        # if detected_homoglyph:
        #     print("  -> Homoglyph bypass detected!")
        #     return make_response(SUCCESS_MESSAGE_GENERIC, 200)

    # Case 4: Fallback - If none of the above conditions met, return default forbidden
    print("  --- No specific condition met. Returning default 403 ---")
    return make_response(FORBIDDEN_MESSAGE, 403)


# Catch-all for other paths (returns 404)
@app.route('/<path:other_path>')
def handle_other(other_path):
    # Avoid matching test paths if they somehow fall through
    if other_path.startswith('test/'):
         return make_response(NOT_FOUND_MESSAGE, 404)
    print("\nRequest to other path: /{}".format(other_path))
    return make_response(NOT_FOUND_MESSAGE, 404)

if __name__ == '__main__':
    print("Starting Flask test server V3 (Path Sensitivity & Query Detail - Updated Logic)...")
    app.run(host='0.0.0.0', port=8888, debug=True)

