# ui.py

from javax.swing import (JPanel, JLabel, JScrollPane, JTextArea, GroupLayout,
                         LayoutStyle, JFrame, JList, DefaultListModel, JCheckBox,
                         ListCellRenderer, BoxLayout, JButton, BorderFactory,
                         ListSelectionModel)
from java.awt import Component, BorderLayout, FlowLayout, Dimension
from java.awt.event import MouseAdapter, ActionListener
import java.lang.Short as Short

# Use config for defaults (needed for UI initialization)
import config

# --- Data structure for list items ---
class CheckListItem:
    def __init__(self, text, key, selected=True):
        self.text = text
        self.key = key # Internal identifier
        self.selected = selected

    def isSelected(self):
        return self.selected

    def setSelected(self, selected):
        self.selected = selected

    def getText(self):
        return self.text

    def getKey(self):
        return self.key

    # Optional: toString for debugging
    # def toString(self):
    #     return "CheckListItem[text={}, key={}, selected={}]".format(self.text, self.key, self.selected)


# --- Custom Renderer for Checkboxes in JList ---
class CheckboxListCellRenderer(JCheckBox, ListCellRenderer):
    def getListCellRendererComponent(self, list, value, index, isSelected, cellHasFocus):
        if isinstance(value, CheckListItem):
            self.setText(value.getText())
            self.setSelected(value.isSelected())
            # Set background/foreground based on selection state
            if isSelected:
                self.setBackground(list.getSelectionBackground())
                self.setForeground(list.getSelectionForeground())
            else:
                self.setBackground(list.getBackground())
                self.setForeground(list.getForeground())
            self.setEnabled(list.isEnabled())
            self.setFont(list.getFont())
            self.setFocusPainted(False)
            # Make checkbox opaque so background color shows
            self.setOpaque(True)
        return self


# --- Main UI Tab Class ---
class uiTab(JFrame):
    # Add callbacks reference if needed for saving settings directly from UI actions
    def __init__(self, callbacks=None):
        self.callbacks = callbacks # Store callbacks if needed for saving
        self.panel = JPanel(BorderLayout(10, 10)) # Use BorderLayout

        # --- Settings Panel (Left Side) ---
        settingsPanel = JPanel()
        boxLayout = BoxLayout(settingsPanel, BoxLayout.Y_AXIS)
        settingsPanel.setLayout(boxLayout)
        settingsPanel.setBorder(BorderFactory.createTitledBorder("Settings"))

        # Query Payloads Area
        self.queryPayloadsLabel = JLabel("Query Payloads (one per line):")
        self.queryPayloadsTextArea = JTextArea(10, 30) # Rows, Columns
        self.queryScrollPane = JScrollPane(self.queryPayloadsTextArea)
        self.queryPayloadsTextArea.setText("\n".join(config.defaultQueryPayloads)) # Load default
        settingsPanel.add(self.queryPayloadsLabel)
        settingsPanel.add(self.queryScrollPane)

        # Header Payloads Area
        self.headerPayloadsLabel = JLabel("Header Payloads (one per line, e.g., Header: Value):")
        self.headerPayloadsTextArea = JTextArea(10, 30)
        self.headerScrollPane = JScrollPane(self.headerPayloadsTextArea)
        self.headerPayloadsTextArea.setText("\n".join(config.defaultHeaderPayloadsForUI)) # Load default
        settingsPanel.add(self.headerPayloadsLabel)
        settingsPanel.add(self.headerScrollPane)

        # False Positives Area
        self.falsePositivesLabel = JLabel("False Positive Keywords (one per line):")
        self.falsePositivesTextArea = JTextArea(5, 30)
        self.falsePositivesScrollPane = JScrollPane(self.falsePositivesTextArea)
        self.falsePositivesTextArea.setText("\n".join(config.defaultFalsePositives)) # Load default
        settingsPanel.add(self.falsePositivesLabel)
        settingsPanel.add(self.falsePositivesScrollPane)

        # --- Check Order Panel (Right Side) ---
        checkOrderPanel = JPanel(BorderLayout(5, 5))
        checkOrderPanel.setBorder(BorderFactory.createTitledBorder("Check Order & Enable/Disable"))

        self.checkListModel = DefaultListModel()
        self.checkList = JList(self.checkListModel)
        self.checkList.setCellRenderer(CheckboxListCellRenderer())
        self.checkList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION)
        self.checkList.setVisibleRowCount(15) # Show more items

        # Add listener to handle checkbox clicks
        self.checkList.addMouseListener(CheckboxMouseListener(self.checkList, self.callbacks)) # Pass callbacks

        checkListScrollPane = JScrollPane(self.checkList)

        # Button Panel for Reordering
        buttonPanel = JPanel(FlowLayout(FlowLayout.CENTER))
        self.moveUpButton = JButton("Move Up")
        self.moveDownButton = JButton("Move Down")
        buttonPanel.add(self.moveUpButton)
        buttonPanel.add(self.moveDownButton)

        # Add Action Listeners for buttons
        self.moveUpButton.addActionListener(MoveButtonListener(self.checkList, self.checkListModel, -1, self.callbacks))
        self.moveDownButton.addActionListener(MoveButtonListener(self.checkList, self.checkListModel, 1, self.callbacks))

        checkOrderPanel.add(checkListScrollPane, BorderLayout.CENTER)
        checkOrderPanel.add(buttonPanel, BorderLayout.SOUTH)


        # --- Add Panels to Main Panel ---
        self.panel.add(settingsPanel, BorderLayout.WEST)
        self.panel.add(checkOrderPanel, BorderLayout.CENTER)


    # Method to populate the check list (called from main)
    def populate_check_list(self, check_items_data):
        self.checkListModel.clear()
        for item_data in check_items_data:
            # Expecting item_data to be like (display_name, key, is_enabled)
            if len(item_data) == 3:
                list_item = CheckListItem(item_data[0], item_data[1], item_data[2])
                self.checkListModel.addElement(list_item)
            else:
                 print("(!) [UI] Invalid check item data format: {}".format(item_data))


    # Method to get the current state of the check list (called from main)
    def get_ordered_checks(self):
        ordered_checks = []
        for i in range(self.checkListModel.getSize()):
            item = self.checkListModel.getElementAt(i)
            if isinstance(item, CheckListItem):
                ordered_checks.append({
                    "name": item.getText(),
                    "key": item.getKey(),
                    "enabled": item.isSelected()
                })
        return ordered_checks

# --- Listener for Checkbox Clicks ---
# Needs reference to JList to get click location and model to update data
class CheckboxMouseListener(MouseAdapter):
    def __init__(self, list_component, callbacks=None):
        self.list = list_component
        self.callbacks = callbacks # To save settings on toggle

    def mouseClicked(self, event):
        index = self.list.locationToIndex(event.getPoint())
        if index < 0:
            return

        item = self.list.getModel().getElementAt(index)
        if isinstance(item, CheckListItem):
            # Toggle selection state
            item.setSelected(not item.isSelected())
            # Repaint the cell to show the change
            # Use repaint(Rectangle) for efficiency
            cell_bounds = self.list.getCellBounds(index, index)
            if cell_bounds != None:
                self.list.repaint(cell_bounds)

            # Save settings after toggle
            if self.callbacks:
                 parentUi = self.list.getTopLevelAncestor() # Get the uiTab instance
                 if isinstance(parentUi, uiTab):
                      parentUi.save_check_settings() # Call save method (needs to be added)
                 elif hasattr(self.list.getModel(), '_owner_ui'): # Alternative if model holds ref
                      self.list.getModel()._owner_ui.save_check_settings()


# --- Listener for Move Buttons ---
class MoveButtonListener(ActionListener):
    def __init__(self, list_component, model, direction, callbacks=None):
        self.list = list_component
        self.model = model
        self.direction = direction # -1 for Up, 1 for Down
        self.callbacks = callbacks # To save settings on move

    def actionPerformed(self, event):
        selectedIndex = self.list.getSelectedIndex()
        if selectedIndex == -1:
            return # Nothing selected

        newIndex = selectedIndex + self.direction

        # Bounds check
        if newIndex < 0 or newIndex >= self.model.getSize():
            return # Cannot move further

        # Swap items
        element = self.model.remove(selectedIndex)
        self.model.add(newIndex, element)

        # Keep the moved item selected
        self.list.setSelectedIndex(newIndex)
        self.list.ensureIndexIsVisible(newIndex) # Scroll if needed

        # Save settings after move
        if self.callbacks:
             parentUi = self.list.getTopLevelAncestor() # Get the uiTab instance
             if isinstance(parentUi, uiTab):
                  parentUi.save_check_settings() # Call save method (needs to be added)
             elif hasattr(self.model, '_owner_ui'): # Alternative if model holds ref
                  self.model._owner_ui.save_check_settings()

# Add save method to uiTab
def save_check_settings(self):
    if not self.callbacks:
        print("(!) [UI] Cannot save settings: Callbacks object not available.")
        return

    ordered_keys = []
    enabled_map = {}
    try:
        for i in range(self.checkListModel.getSize()):
            item = self.checkListModel.getElementAt(i)
            if isinstance(item, CheckListItem):
                key = item.getKey()
                ordered_keys.append(key)
                enabled_map[key] = item.isSelected()

        # Simple JSON-like string storage (Burp uses Strings for settings)
        # Order: comma-separated keys
        # Enabled: key:true,key:false,...
        order_str = ",".join(ordered_keys)
        enabled_items = []
        for key, enabled in enabled_map.items():
            enabled_items.append("{}:{}".format(key, "true" if enabled else "false"))
        enabled_str = ",".join(enabled_items)

        self.callbacks.saveExtensionSetting(config.SETTINGS_KEY_ORDER, order_str)
        self.callbacks.saveExtensionSetting(config.SETTINGS_KEY_ENABLED, enabled_str)
        print("[UI] Saved check order and enabled states.")

    except Exception as e:
        print("(!) [UI] Error saving settings: {}".format(e))

# Add the save method to the class
uiTab.save_check_settings = save_check_settings