# utils.py

from burp import IScanIssue
import java.util.Arrays # For copyOfRange
import java.lang.reflect.Array # For creating empty byte[]
import java.lang.Byte # For empty byte[] type
import java.util.ArrayList as ArrayList # Needed for CustomScanIssue
import java.lang.String as String # Needed for buildHttpMessage call

# For URL encoding
from java.net import URLEncoder

import cgi # For HTML escaping
import sys # For stdout/stderr printing (optional here, could pass explicitly)

# --- Helper: Check if Response is 403 ---
def isInteresting(response, helpers):
    if response is None:
        return False
    try:
        responseInfo = helpers.analyzeResponse(response)
        if responseInfo:
             return responseInfo.getStatusCode() == 403
        else:
             print("(!) [utils.isInteresting] Could not analyze response.")
             return False
    except Exception as e:
        print("(!) [utils.isInteresting] Error analyzing status code: {}".format(e))
        return False

# --- Helper: Find Char Indices ---
def findAllCharIndexesInString(s, ch):
    return [i for i, ltr in enumerate(s) if ltr == ch]

# --- Helper: Compare Response Bodies ---
def compareResponseBodies(response1_bytes, response2_bytes, helpers):
    if response1_bytes is None and response2_bytes is None:
        return True
    if response1_bytes is None or response2_bytes is None:
        return False
    try:
        info1 = helpers.analyzeResponse(response1_bytes)
        info2 = helpers.analyzeResponse(response2_bytes)
        if info1 is None or info2 is None:
             print("     (!) [utils.compareResponseBodies] Error analyzing one or both responses.")
             return False

        body1 = response1_bytes[info1.getBodyOffset():]
        body2 = response2_bytes[info2.getBodyOffset():]
        return body1 == body2
    except Exception as e:
        print("     (!) [utils.compareResponseBodies] Error comparing response bodies: {}".format(e))
        return False

# --- Helper: Double URL Encode ---
def doubleUrlEncode(payload):
    if payload is None:
        return None
    # Assume payload is already single-encoded (e.g., %2e)
    return payload.replace('%', '%25')

# --- Helper: URL Encode Single Char ---
def urlEncodeChar(char_to_encode):
    if not char_to_encode or len(char_to_encode) != 1:
        return char_to_encode
    return '%' + hex(ord(char_to_encode))[2:].zfill(2).upper()

# --- Helper: Unicode Encode Single Char (URL Encoded form) ---
def unicodeEncodeCharForUrl(char_to_encode):
    if not char_to_encode or len(char_to_encode) != 1:
        return char_to_encode
    unicode_repr = '\\u' + hex(ord(char_to_encode))[2:].zfill(4)
    return unicode_repr.replace('\\', '%5C')

# --- Preliminary Path Sensitivity Check ---
def preliminaryPathCheck(baseRequestResponse, httpService, helpers, callbacks):
    print("  [Prelim Check] Performing preliminary path sensitivity check...")
    sensitive_indices = set()
    originalRequestInfo = None
    originalResponseBytes = None
    originalPath = "/"
    originalHeaders = None
    originalMethod = None
    originalProtocol = "HTTP/1.1"
    originalBodyBytes = None
    try:
        originalRequestInfo = helpers.analyzeRequest(baseRequestResponse)
        if originalRequestInfo is None:
            print("    (!) Failed to analyze original request for prelim check.")
            return None

        originalResponseBytes = baseRequestResponse.getResponse()
        if originalResponseBytes is None:
            print("    (!) Original response missing.")
            return None

        tempPath = originalRequestInfo.getUrl().getPath()
        if tempPath is None or not tempPath or tempPath == "/":
            print("    (!) Path empty/root.")
            return None
        originalPath = tempPath

        originalHeaders = list(originalRequestInfo.getHeaders())
        originalMethod = originalRequestInfo.getMethod()
        original_request_line_parts = originalHeaders[0].split(" ", 2)
        if len(original_request_line_parts) == 3:
            originalProtocol = original_request_line_parts[2]

        originalBodyOffset = originalRequestInfo.getBodyOffset()
        raw_req = baseRequestResponse.getRequest()
        if len(raw_req) > originalBodyOffset:
            originalBodyBytes = java.util.Arrays.copyOfRange(raw_req, originalBodyOffset, len(raw_req))
        else:
            originalBodyBytes = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)

    except Exception as analysis_err:
        print("    (!) Error analyzing request/response for prelim check: {}".format(analysis_err))
        return None

    try:
        segments = [s for s in originalPath.strip('/').split('/')]
        print("    Segments: {}".format(segments))

        for i, segment in enumerate(segments):
            if not segment:
                continue

            modified_segment = ""
            if len(segment) > 1:
                modified_segment = segment[:-1] + 'X'
            else:
                modified_segment = segment + 'X'

            temp_segments = list(segments)
            temp_segments[i] = modified_segment
            modifiedPath = "/" + "/".join(temp_segments)
            if originalPath.endswith('/') and originalPath != "/":
                modifiedPath += "/"

            print("    Testing segment {}: '{}' -> '{}' (Path: {})".format(i, segment, modified_segment, modifiedPath))

            try:
                new_request_line = "{} {} {}".format(originalMethod, modifiedPath, originalProtocol)
                newHeadersList = ArrayList()
                newHeadersList.add(String(new_request_line))
                if len(originalHeaders) > 1:
                    for h_idx in range(1, len(originalHeaders)):
                        newHeadersList.add(originalHeaders[h_idx])

                newRequestBytes = helpers.buildHttpMessage(newHeadersList, originalBodyBytes)
                # Use callbacks to make request
                newRequestResult = callbacks.makeHttpRequest(httpService, newRequestBytes)
                newResponseBytes = newRequestResult.getResponse()

                if newResponseBytes is None:
                    print("      -> No response received for modified path. Assuming sensitivity.")
                    sensitive_indices.add(i)
                    continue

                newResponseInfo = helpers.analyzeResponse(newResponseBytes)
                if newResponseInfo is None:
                    print("      -> Failed to analyze response for modified path. Assuming sensitivity.")
                    sensitive_indices.add(i)
                    continue

                newStatusCode = newResponseInfo.getStatusCode()

                if newStatusCode != 403 or not compareResponseBodies(originalResponseBytes, newResponseBytes, helpers):
                    print("      -> Status: {} (Changed/Body differs). Segment {} is SENSITIVE.".format(newStatusCode, i))
                    sensitive_indices.add(i)
                else:
                    print("      -> Status: 403 (Same Body). Segment {} is NOT sensitive.".format(i))

            except Exception as req_err:
                print("      (!) Error sending request for segment {}: {}".format(i, req_err))
                continue

        print("  [Prelim Check] Sensitive segment indices found: {}".format(sensitive_indices if sensitive_indices else "None"))
        return sensitive_indices

    except Exception as e:
        print("    (!) Error during preliminary path check logic: {}".format(e))
        return None

# --- Generate Path Payloads ---
def generatePayloads(path, payload, sensitive_indices=None, helpers=None): # Added helpers
    # Note: This implementation ignores sensitive_indices as per user's last provided code
    print("    [generatePayloads] Generating payloads for path: '{}', payload: '{}'".format(path, payload))
    generated_payloads = set()
    clean_payload = payload.strip('/')
    if not clean_payload:
        return []

    # Root path handling
    if not path or path == "/":
        generated_payloads.add("/" + clean_payload)
        generated_payloads.add("/" + clean_payload + "/")
        if payload != clean_payload:
            generated_payloads.add("/" + payload.strip('/'))
        return list(generated_payloads)

    # Fallback: Generate all standard variations
    slash_indices = findAllCharIndexesInString(path, "/") # Use helper
    indices = slash_indices

    # --- Insertions before ---
    for i in indices:
        if i > 0:
            generated_payloads.add(path[:i] + "/" + clean_payload + path[i:])
    # --- Insertions after ---
    for i in indices:
        if i < len(path) - 1:
            generated_payloads.add(path[:i+1] + clean_payload + path[i+1:])
        else:
            generated_payloads.add(path + clean_payload)
    # --- Replacements ---
    for k in range(len(indices) - 1):
        i = indices[k]
        j = indices[k+1]
        # Skip replacing the only segment via this method
        if k == 0 and i == 0 and len(indices) == 2:
            continue
        # Ensure content exists between slashes
        if j > i + 1:
            generated_payloads.add(path[:i+1] + clean_payload + path[j:])
    # --- Appending ---
    if path.endswith('/'):
        generated_payloads.add(path + clean_payload)
        generated_payloads.add(path + clean_payload + "/")
    else:
        generated_payloads.add(path + "/" + clean_payload)
        generated_payloads.add(path + "/" + clean_payload + "/")
    # Append raw payload too
    generated_payloads.add(path + payload)
    # --- Prefixing last segment ---
    if '/' in path.strip('/'):
        last_slash = path.rfind('/')
        if last_slash >= 0:
            generated_payloads.add(path[:last_slash+1] + clean_payload + path[last_slash+1:])

    print("    [generatePayloads] Generated variations: {}".format(len(generated_payloads)))
    return list(generated_payloads)

# --- False Positive Check ---
def isFalsePositive(responseBytes, falsePositiveKeywords, helpers): # Added helpers
    if not falsePositiveKeywords:
        return False
    if responseBytes is None:
        return False
    try:
        responseInfo = helpers.analyzeResponse(responseBytes)
        if responseInfo is None:
            print("         (!) [FP Check] Failed to analyze response.")
            return False

        bodyOffset = responseInfo.getBodyOffset()
        responseBodyBytes = responseBytes[bodyOffset:]
        responseBodyStr = ""
        try:
            tempStr = helpers.bytesToString(responseBodyBytes)
            if tempStr is not None:
                responseBodyStr = tempStr.lower()
            else:
                responseBodyStr = responseBodyBytes.decode('latin-1', 'ignore').lower()
        except Exception:
            try:
                responseBodyStr = responseBodyBytes.decode('latin-1', 'ignore').lower()
            except Exception as decode_err:
                print("         (!) [FP Check] Error decoding response body: {}".format(decode_err))
                return False

        for keyword in falsePositiveKeywords:
            clean_keyword = None
            kw_type = type(keyword)
            # Use basestring for Jython 2.7 compatibility
            is_string_type = isinstance(keyword, basestring)
            if keyword and is_string_type:
                clean_keyword = keyword.strip().lower()
            elif keyword is not None:
                try:
                    clean_keyword = str(keyword).strip().lower()
                except Exception:
                    pass
            if clean_keyword and clean_keyword in responseBodyStr:
                print("         >>>>> [FP Check] Match FOUND for keyword '{}'".format(clean_keyword))
                return True
    except Exception as e:
        print("         (!) [FP Check] Error: {}".format(e))
        return False
    return False

def analyze_original_request(baseRequestResponse, helpers):
    """
    Analyzes a base request and returns a dictionary of its key components.
    Returns None on failure.
    """
    analysis_result = {
        "requestInfo": None,
        "url": None,
        "path": "/",       # Path only, e.g., /test/admin
        "query": None,     # Query string *without* '?', e.g., id=1&p=2
        "pathUnicode": u"/",
        "headers": None,   # List of header strings
        "method": None,
        "protocol": "HTTP/1.1",
        "bodyBytes": None
    }
    try:
        requestInfo = helpers.analyzeRequest(baseRequestResponse)
        if requestInfo is None:
            print("    (!) [utils.analyze_original_request] Failed to analyze request.")
            return None
        analysis_result["requestInfo"] = requestInfo

        url = requestInfo.getUrl()
        if not url:
             print("    (!) [utils.analyze_original_request] Failed to get URL from request.")
             return None
        analysis_result["url"] = url

        tempPath = url.getPath()
        if tempPath is not None and tempPath:
            analysis_result["path"] = tempPath

        analysis_result["query"] = url.getQuery() # Returns null if no query

        # Ensure path is unicode for modules that need it (homoglyph, trim_chars)
        try:
            analysis_result["pathUnicode"] = analysis_result["path"].decode('utf-8') \
                if isinstance(analysis_result["path"], str) else analysis_result["path"]
        except UnicodeDecodeError:
             print("    (!) [utils.analyze_original_request] Failed to decode path to unicode.")
             # Continue with non-unicode path, some modules might fail
             analysis_result["pathUnicode"] = analysis_result["path"]


        headers = list(requestInfo.getHeaders())
        if not headers:
             print("    (!) [utils.analyze_original_request] No headers found.")
             return None
        analysis_result["headers"] = headers

        analysis_result["method"] = requestInfo.getMethod()
        request_line_parts = headers[0].split(" ", 2)
        if len(request_line_parts) == 3:
            analysis_result["protocol"] = request_line_parts[2]

        bodyOffset = requestInfo.getBodyOffset()
        raw_req = baseRequestResponse.getRequest()
        if len(raw_req) > bodyOffset:
            analysis_result["bodyBytes"] = java.util.Arrays.copyOfRange(raw_req, bodyOffset, len(raw_req))
        else:
            analysis_result["bodyBytes"] = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 0)

        return analysis_result
    except Exception as e:
        print("    (!) [utils.analyze_original_request] Error during request analysis: {}".format(e))
        return None

# --- Custom Scan Issue Class ---
class CustomScanIssue (IScanIssue):
    """Custom class to hold scan issue details."""
    def __init__(self, httpService, url, httpMessages, name, detail, severity):
        self._httpService = httpService
        self._url = url
        self._httpMessages = ArrayList()
        if isinstance(httpMessages, list):
            for msg in httpMessages:
                if msg is not None:
                    self._httpMessages.add(msg)
        elif httpMessages is not None:
            self._httpMessages.add(httpMessages)

        self._name = name
        is_unicode = isinstance(detail, unicode)
        self._detail = detail.encode('utf-8') if is_unicode else str(detail)
        self._severity = severity
        self._confidence = "Firm"

    def getUrl(self): return self._url
    def getIssueName(self): return self._name
    def getIssueType(self): return 0
    def getSeverity(self): return self._severity
    def getConfidence(self): return self._confidence
    def getIssueBackground(self): return None
    def getRemediationBackground(self): return None
    def getIssueDetail(self): return self._detail
    def getRemediationDetail(self): return None
    def getHttpMessages(self): return self._httpMessages
    def getHttpService(self): return self._httpService