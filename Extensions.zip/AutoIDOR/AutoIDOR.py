# -*- coding: utf-8 -*-
# Author: AI based on user prompt
# Version: 1.9.3 (Using SequenceMatcher for body comparison)

from burp import (IBurpExtender, IScannerCheck, IScanIssue,
                  IHttpRequestResponse, IParameter)
from java.io import PrintWriter
from java.net import URL
from java.util import ArrayList, HashSet
import re
import threading
from urlparse import urlparse, urlunparse # Use from urllib.parse import ... in Python 3
from urllib import urlencode
import hashlib # Keep for potential future debugging if needed
from difflib import SequenceMatcher # <-- IMPORT THIS

# --- Configuration ---
MIN_NUMERIC_LENGTH = 3
MIN_RESPONSE_BODY_LENGTH = 100
# Similarity Ratio Threshold (e.g., 0.99 means bodies must be < 99% similar to be considered different)
# Adjust lower (e.g., 0.98 or 0.95) if seeing false positives due to minor dynamic content
# Adjust higher (e.g., 0.999) for stricter matching.
SIMILARITY_THRESHOLD = 0.99
# ... (Rest of configuration unchanged) ...
EXCLUDED_MIME_TYPES = set([ 'script', 'css', 'image', 'font', 'executable', 'video', 'audio', 'octet-stream' ])
EXACT_EXCLUDED_PARAM_NAMES = set([ 'p', 'q', '_', 'ts', 'fmt', 'v', ])
SUBSTRING_EXCLUDED_PARAM_NAMES = set([ 'page', 'pagina', 'size', 'height', 'width', 'limit', 'max', 'perpage', 'offset', 'start', 'sort', 'order', 'filter', 'query', 'search', 'keyword', 'term', 'view', 'layout', 'lang', 'locale', 'format', 'callback', 'jsonp', 'stamp', 'nonce', 'token', 'csrf', 'continue', 'redirect', 'return', 'next', 'cache', 'session', 'debug', 'test', 'mode', 'type', 'duration' ])
PREFIX_EXCLUDED_PARAM_NAMES = set([ 'utm_', 'gclid', 'fbclid', 'msclkid', 'dclid', 'mc_', '_ga', 'pk_', 'ref', ])
UUID_PATTERN = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', re.IGNORECASE)

class BurpExtender(IBurpExtender, IScannerCheck):

    def registerExtenderCallbacks(self, callbacks):
        self._callbacks = callbacks
        self._helpers = callbacks.getHelpers()
        self.stdout = PrintWriter(callbacks.getStdout(), True)
        self.stderr = PrintWriter(callbacks.getStderr(), True)
        callbacks.setExtensionName("AutoIDOR")
        callbacks.registerScannerCheck(self)
        self.scanned_requests = HashSet()
        self.scan_lock = threading.Lock()
        self.stdout.println("AutoIDOR Passive Scanner Loaded (v1.9.3)") # Version updated
        self.stdout.println("--- Configuration ---")
        self.stdout.println("Min Numeric Length: {}".format(MIN_NUMERIC_LENGTH))
        self.stdout.println("Min Response Body Length: {}".format(MIN_RESPONSE_BODY_LENGTH))
        self.stdout.println("Body Similarity Threshold: {}".format(SIMILARITY_THRESHOLD)) # Added threshold info
        self.stdout.println("Excluded MIME types: {}".format(", ".join(EXCLUDED_MIME_TYPES) if EXCLUDED_MIME_TYPES else "None"))
        self.stdout.println("Exact Excluded Param Names: {}".format(", ".join(EXACT_EXCLUDED_PARAM_NAMES)))
        self.stdout.println("Substring Excluded Param Names: {}".format(", ".join(SUBSTRING_EXCLUDED_PARAM_NAMES)))
        self.stdout.println("Prefix Excluded Param Names: {}".format(", ".join(PREFIX_EXCLUDED_PARAM_NAMES)))
        self.stdout.println("UUID Path Segment Skipping: Enabled")
        self.stdout.println("Auth Header Check: Enabled")
        self.stdout.println("---------------------")

    # --- IScannerCheck methods ---
    def doPassiveScan(self, baseRequestResponse):
        request_hash = baseRequestResponse.hashCode()
        with self.scan_lock:
            if request_hash in self.scanned_requests: return None
            self.scanned_requests.add(request_hash)

        issues = []
        try:
            requestInfo = self._helpers.analyzeRequest(baseRequestResponse)
            url = requestInfo.getUrl()

            # --- Pre-Scan Filtering ---
            if requestInfo.getMethod() != "GET": return None
            headers = requestInfo.getHeaders(); has_cookie = False; has_authorization = False
            for header in headers:
                header_lower = header.lower()
                if header_lower.startswith("cookie:"): has_cookie = True
                elif header_lower.startswith("authorization:"): has_authorization = True
                if has_cookie or has_authorization: break
            if not has_cookie and not has_authorization: return None
            if not baseRequestResponse.getResponse(): return None
            responseBytes = baseRequestResponse.getResponse()
            responseInfo = self._helpers.analyzeResponse(responseBytes)
            if responseInfo.getStatusCode() != 200: return None
            mimeType = responseInfo.getInferredMimeType() or responseInfo.getStatedMimeType()
            if mimeType and any(excluded in mimeType.lower() for excluded in EXCLUDED_MIME_TYPES): return None
            numeric_locations = self._find_numeric_locations(url, requestInfo)
            if not numeric_locations: return None
            originalResponseBodyOffset = responseInfo.getBodyOffset()
            originalResponseBodyBytes = responseBytes[originalResponseBodyOffset:] # Keep original extraction
            if len(originalResponseBodyBytes) < MIN_RESPONSE_BODY_LENGTH: return None
            # --- End Pre-Scan Filtering ---

            # Log only once before starting checks for a URL
            # self.stdout.println("[+] Pre-scan checks passed: {}".format(url)) # Make logs less noisy
            originalStatusCode = responseInfo.getStatusCode()
            originalMimeType = mimeType
            httpService = baseRequestResponse.getHttpService()

            # --- Main Scan Loop ---
            for num_str, location_type, context in numeric_locations:
                try: original_numeric_value = int(num_str)
                except ValueError: self.stderr.println("  [!] Bad numeric '{}'. Skip.".format(num_str)); continue

                decrements = [(1, 1), (10, 10 if original_numeric_value != 10 else 5),
                              (100, 100 if original_numeric_value > 100 else None),
                              (1000, 1000 if original_numeric_value > 1000 else None)]

                for dec_val, effective_dec in decrements:
                    if effective_dec is None: continue
                    new_numeric_value = original_numeric_value - effective_dec
                    if new_numeric_value < 0: continue
                    new_numeric_str = str(new_numeric_value)

                    modified_request_bytes = None; scan_req_resp = None
                    try:
                        # --- Build First Modified Request (Path/Query) ---
                        # ... (Build logic unchanged) ...
                        if location_type == 'path':
                            parsed_url = urlparse(url.toString()); url_path = parsed_url.path if parsed_url.path is not None else ""
                            path_parts = url_path.strip('/').split('/') if url_path != '/' and url_path else [""]
                            segment_index = context
                            if segment_index < len(path_parts) and num_str in path_parts[segment_index]:
                                path_parts[segment_index] = path_parts[segment_index].replace(num_str, new_numeric_str, 1)
                                new_path = '/'.join(path_parts)
                                if url_path.startswith('/'):
                                     if not new_path.startswith('/'): new_path = '/' + new_path
                                elif not new_path: new_path = '/'
                                new_url_str = urlunparse((parsed_url.scheme, parsed_url.netloc, new_path, parsed_url.params, parsed_url.query, parsed_url.fragment))
                                original_req_bytes=baseRequestResponse.getRequest(); request_info_orig=self._helpers.analyzeRequest(original_req_bytes); original_headers=request_info_orig.getHeaders()
                                new_parsed_url=urlparse(new_url_str); new_request_path=urlunparse(('', '', new_parsed_url.path or '/', new_parsed_url.params, new_parsed_url.query, ''))
                                if not new_request_path.startswith('/'): new_request_path='/'+new_request_path
                                new_first_line="GET {} HTTP/1.1".format(new_request_path); updated_headers=ArrayList(); updated_headers.add(new_first_line)
                                for i, header in enumerate(original_headers):
                                    if i>0: updated_headers.add(header)
                                body_offset=request_info_orig.getBodyOffset(); body_bytes=original_req_bytes[body_offset:] if len(original_req_bytes)>body_offset else None
                                if body_bytes: modified_request_bytes=self._helpers.buildHttpMessage(updated_headers,body_bytes)
                                else: modified_request_bytes=self._helpers.buildHttpMessage(updated_headers,self._helpers.stringToBytes(""))
                            else: continue # Skip if path mod fails silently now
                        elif location_type == 'query':
                            param_name=context; found_param = False
                            current_params = requestInfo.getParameters() # Get fresh params for update base
                            for p in current_params:
                                if p.getName() == param_name and p.getValue() == num_str and p.getType() == IParameter.PARAM_URL:
                                    new_param=self._helpers.buildParameter(param_name,new_numeric_str,IParameter.PARAM_URL)
                                    # Base request bytes might be needed if multiple params exist
                                    modified_request_bytes=self._helpers.updateParameter(baseRequestResponse.getRequest(),new_param)
                                    found_param = True; break
                            if not found_param: continue # Skip if query param mod fails

                        else: continue

                        # --- Send Request ---
                        if modified_request_bytes: scan_req_resp = self._callbacks.makeHttpRequest(httpService, modified_request_bytes)
                        else: continue

                        # --- Analyze Response ---
                        if not scan_req_resp or not scan_req_resp.getResponse(): continue
                        scanResponseBytes = scan_req_resp.getResponse(); scanResponseInfo = self._helpers.analyzeResponse(scanResponseBytes)
                        if scanResponseInfo.getStatusCode() != originalStatusCode: break # Status changed, stop checks for this number
                        scanMimeType = scanResponseInfo.getInferredMimeType() or scanResponseInfo.getStatedMimeType()
                        originalMimeBase = originalMimeType.split(';')[0].strip().lower() if originalMimeType else ''
                        scanMimeBase = scanMimeType.split(';')[0].strip().lower() if scanMimeType else ''
                        if scanMimeBase != originalMimeBase: break # Mime changed, stop checks

                        # --- Body Comparison using SequenceMatcher ---
                        scanResponseBodyOffset = scanResponseInfo.getBodyOffset()
                        # Use bytearray for SequenceMatcher compatibility if needed, though bytes often work
                        scanResponseBodyBytes = scanResponseBytes[scanResponseBodyOffset:]

                        # Use SequenceMatcher. It handles bytes in Python 2.7/Jython.
                        # None indicates we don't care about junk detection heuristic.
                        # We use .ratio() for similarity percentage.
                        matcher = SequenceMatcher(None, originalResponseBodyBytes, scanResponseBodyBytes)
                        similarity_ratio = matcher.ratio()

                        # Log the ratio for debugging if needed
                        # self.stdout.println("    DEBUG: Body Similarity Ratio: {:.4f}".format(similarity_ratio))

                        # Check if similarity is BELOW the threshold (i.e., bodies are different enough)
                        if similarity_ratio < SIMILARITY_THRESHOLD:
                            # Bodies are considered different enough, proceed to potential secondary check / issue reporting
                             self.stdout.println("    DEBUG: Body similarity {:.4f} < threshold {}. Bodies considered DIFFERENT.".format(similarity_ratio, SIMILARITY_THRESHOLD)) # Log proceed
                             pass # Continue processing
                        else:
                            # Bodies are too similar (or identical), skip this test case
                             self.stdout.println("    DEBUG: Body similarity {:.4f} >= threshold {}. Bodies considered IDENTICAL/TOO SIMILAR. Breaking.".format(similarity_ratio, SIMILARITY_THRESHOLD)) # Log break
                             break # Break inner loop (try next decrement/number)

                        # --- Check 4: Body Length Heuristic + Secondary Check (only if bodies were different enough) ---
                        len1 = len(scanResponseBodyBytes); len_orig = len(originalResponseBodyBytes)
                        if len1 < len_orig * 0.5 and len1 < MIN_RESPONSE_BODY_LENGTH:
                            # ... (Secondary check logic remains the same) ...
                            is_error_pattern = False; secondary_check_done = False
                            try:
                                second_new_numeric_value = new_numeric_value - 1
                                if second_new_numeric_value >= 0:
                                    second_new_numeric_str = str(second_new_numeric_value); second_modified_request_bytes = None
                                    # --- Build second modified request (Path/Query - logic similar to first build) ---
                                    if location_type == 'path':
                                        parsed_url_sec=urlparse(url.toString()); url_path_sec = parsed_url_sec.path if parsed_url_sec.path is not None else ""
                                        path_parts_sec = url_path_sec.strip('/').split('/') if url_path_sec != '/' and url_path_sec else [""]
                                        segment_index_sec=context
                                        if segment_index_sec<len(path_parts_sec) and num_str in path_parts_sec[segment_index_sec]:
                                            path_parts_sec[segment_index_sec]=path_parts_sec[segment_index_sec].replace(num_str,second_new_numeric_str,1); new_path_sec='/'.join(path_parts_sec)
                                            if url_path_sec.startswith('/'):
                                                 if not new_path_sec.startswith('/'): new_path_sec = '/' + new_path_sec
                                            elif not new_path_sec: new_path_sec = '/'
                                            new_url_str_sec=urlunparse((parsed_url_sec.scheme,parsed_url_sec.netloc,new_path_sec,parsed_url_sec.params,parsed_url_sec.query,parsed_url_sec.fragment))
                                            original_req_bytes_sec=baseRequestResponse.getRequest();request_info_orig_sec=self._helpers.analyzeRequest(original_req_bytes_sec);original_headers_sec=request_info_orig_sec.getHeaders()
                                            new_parsed_url_sec=urlparse(new_url_str_sec);new_request_path_sec=urlunparse(('', '', new_parsed_url_sec.path or '/', new_parsed_url_sec.params, new_parsed_url_sec.query, ''))
                                            if not new_request_path_sec.startswith('/'): new_request_path_sec='/'+new_request_path_sec
                                            new_first_line_sec="GET {} HTTP/1.1".format(new_request_path_sec);updated_headers_sec=ArrayList();updated_headers_sec.add(new_first_line_sec)
                                            for i, header in enumerate(original_headers_sec):
                                                if i>0: updated_headers_sec.add(header)
                                            body_offset_sec=request_info_orig_sec.getBodyOffset();body_bytes_sec=original_req_bytes_sec[body_offset_sec:] if len(original_req_bytes_sec)>body_offset_sec else None
                                            if body_bytes_sec: second_modified_request_bytes=self._helpers.buildHttpMessage(updated_headers_sec,body_bytes_sec)
                                            else: second_modified_request_bytes=self._helpers.buildHttpMessage(updated_headers_sec,self._helpers.stringToBytes(""))
                                    elif location_type == 'query':
                                        param_name_sec=context; found_param_sec = False
                                        current_params_sec = requestInfo.getParameters() # Use original request info
                                        for p_sec in current_params_sec:
                                            if p_sec.getName() == param_name_sec and p_sec.getValue() == num_str and p_sec.getType() == IParameter.PARAM_URL:
                                                 second_new_param=self._helpers.buildParameter(param_name_sec,second_new_numeric_str,IParameter.PARAM_URL)
                                                 second_modified_request_bytes=self._helpers.updateParameter(baseRequestResponse.getRequest(),second_new_param)
                                                 found_param_sec = True; break
                                    # --- Send/Analyze Second Request ---
                                    if second_modified_request_bytes:
                                        secondary_check_done = True; second_scan_req_resp=self._callbacks.makeHttpRequest(httpService,second_modified_request_bytes)
                                        if second_scan_req_resp and second_scan_req_resp.getResponse():
                                            second_scanResponseInfo=self._helpers.analyzeResponse(second_scan_req_resp.getResponse())
                                            if second_scanResponseInfo.getStatusCode()==originalStatusCode:
                                                second_mimeType = second_scanResponseInfo.getInferredMimeType() or second_scanResponseInfo.getStatedMimeType()
                                                second_mimeBase = second_mimeType.split(';')[0].strip().lower() if second_mimeType else ''
                                                if second_mimeBase == originalMimeBase:
                                                    second_scanResponseBodyBytes=second_scan_req_resp.getResponse()[second_scanResponseInfo.getBodyOffset():]
                                                    len2=len(second_scanResponseBodyBytes); threshold=max(20.0, float(len1)*0.1) # Compare lengths of the two modified responses
                                                    if abs(len1-len2)<=threshold: is_error_pattern=True
                            except Exception as e_sec: self.stderr.println("      [!] Exception during secondary check: {}".format(e_sec))
                            # --- Decision based on secondary check ---
                            if secondary_check_done and is_error_pattern:
                                self.stdout.println("    DEBUG: Secondary check suggests error pattern. Breaking.")
                                break # Stop if error pattern confirmed by secondary check

                        # --- Issue Reporting (Only reached if bodies were different enough AND secondary check didn't indicate error)---
                        self.stdout.println("    [!] Potential IDOR Found! Context: {}={}, Orig: {}, New: {}, Similarity: {:.4f}".format(
                            location_type, context, num_str, new_numeric_str, similarity_ratio)) # Log similarity
                        issue = AutoIDORIssue(BasePair=baseRequestResponse, ScanPair=scan_req_resp, Url=url,
                            OriginalNumeric=num_str, TestedNumeric=new_numeric_str, LocationType=location_type, Context=context,
                            helpers=self._helpers, stderr_ref=self.stderr, similarity=similarity_ratio ) # Pass similarity
                        issues.append(issue)
                        break # Break INNER loop once issue found

                    except Exception as e: # Exception during single decrement test
                        self.stderr.println("    [!] Exception in main scan loop for '{}', value {}: {}".format(num_str, new_numeric_str, e))
                        import traceback; traceback.print_exc(file=self.stderr)
                        self.stderr.println("    [!] Breaking decrement loop for '{}' due to exception.".format(num_str)); break # Break INNER loop

        except Exception as e: # Outer exception during passive scan
            self.stderr.println("[!] Outer error during passive scan for {}: {}".format(baseRequestResponse.hashCode(), e))
            import traceback; traceback.print_exc(file=self.stderr)
            with self.scan_lock:
                if request_hash not in self.scanned_requests: self.scanned_requests.add(request_hash)

        return issues if issues else None

    # ... (consolidateDuplicateIssues, _find_numeric_locations unchanged) ...
    def consolidateDuplicateIssues(self, existingIssue, newIssue):
        try:
            if (existingIssue.getIssueName() == newIssue.getIssueName() and
                existingIssue.getUrl().toString() == newIssue.getUrl().toString()):
                 if (hasattr(existingIssue, '_originalNumeric') and hasattr(newIssue, '_originalNumeric') and
                     hasattr(existingIssue, '_locationType') and hasattr(newIssue, '_locationType') and
                     hasattr(existingIssue, '_context') and hasattr(newIssue, '_context')):
                     if (existingIssue._originalNumeric == newIssue._originalNumeric and
                         existingIssue._locationType == newIssue._locationType and
                         existingIssue._context == newIssue._context):
                         return -1 # Duplicate
        except AttributeError: pass
        except Exception as e:
            if hasattr(self, 'stderr'): self.stderr.println("[!] Error during consolidateDuplicateIssues: {}".format(e))
            else: print("[!] Error during consolidateDuplicateIssues (stderr not ready): {}".format(e))
        return 0

    def _find_numeric_locations(self, url, requestInfo):
        locations = []
        url_str = url.toString()
        parsed_url = urlparse(url_str)
        found_potential_numeric = False
        url_path = parsed_url.path if parsed_url.path is not None else ""
        path_parts = url_path.strip('/').split('/') if url_path != '/' else [""]
        if url_path and url_path != '/':
             for i, segment in enumerate(path_parts):
                if not segment: continue
                if UUID_PATTERN.match(segment): continue
                numeric_regex = r'\d{' + str(MIN_NUMERIC_LENGTH) + r',}'
                matches = re.findall(numeric_regex, segment)
                if matches:
                    found_potential_numeric = True
                    for match in matches: locations.append((match, 'path', i))
        params = requestInfo.getParameters()
        added_param_keys_for_numerics = set()
        for param in params:
            if param.getType() == IParameter.PARAM_URL:
                param_name = param.getName(); param_value = param.getValue(); param_name_lower = param_name.lower() if param_name else ""
                excluded = False; exclusion_reason = ""
                if param_name_lower in EXACT_EXCLUDED_PARAM_NAMES: excluded = True; exclusion_reason = "exact"
                if not excluded:
                    for substr_excluded in SUBSTRING_EXCLUDED_PARAM_NAMES:
                        if substr_excluded in param_name_lower: excluded = True; exclusion_reason = "substr"; break
                if not excluded:
                    for prefix_excluded in PREFIX_EXCLUDED_PARAM_NAMES:
                        if param_name_lower.startswith(prefix_excluded): excluded = True; exclusion_reason = "prefix"; break
                if excluded: continue
                if param_value:
                     numeric_regex_param = r'\d{' + str(MIN_NUMERIC_LENGTH) + r',}'
                     matches_in_value = re.findall(numeric_regex_param, param_value)
                     if matches_in_value:
                         found_potential_numeric = True
                         for match in matches_in_value:
                              loc_key = (param_name, match)
                              if loc_key not in added_param_keys_for_numerics:
                                  locations.append((match, 'query', param_name)); added_param_keys_for_numerics.add(loc_key)
        final_locations = []; seen_location_tuples = set()
        for loc in locations:
            loc_tuple = (loc[0], loc[1], loc[2])
            if loc_tuple not in seen_location_tuples: final_locations.append(loc); seen_location_tuples.add(loc_tuple)
        return final_locations

# --- Custom Scan Issue Class (Modified to include similarity) ---
class AutoIDORIssue(IScanIssue):
    # Added similarity parameter
    def __init__(self, BasePair, ScanPair, Url, OriginalNumeric, TestedNumeric, LocationType, Context, helpers, stderr_ref=None, similarity=0.0):
        self._helpers=helpers; self._httpMessages=[BasePair, ScanPair]; self._httpService=BasePair.getHttpService()
        self._url=Url; self._originalNumeric=OriginalNumeric; self._testedNumeric=TestedNumeric
        self._locationType=LocationType; self._context=Context; self.stderr=stderr_ref
        self._similarity = similarity # Store similarity ratio

    def getUrl(self): return self._url
    def getIssueName(self): return "Potential IDOR"
    def getIssueType(self): return 0x08000000
    def getSeverity(self): return "High"
    def getConfidence(self):
        # Confidence can be adjusted based on similarity maybe?
        # For now, keep Firm as it passed the core checks.
        # if self._similarity < 0.9: return "Certain" # Example threshold
        return "Firm"

    def getIssueBackground(self): return None
    def getRemediationBackground(self): return None
    def getRemediationDetail(self): return None

    def getIssueDetail(self):
        location_desc = ""
        if self._locationType == 'path':
            try: path_parts = urlparse(self._url.toString()).path.strip('/').split('/'); segment = path_parts[self._context] if self._context < len(path_parts) else "[index {}]".format(self._context); location_desc = "in path segment '<b>{}</b>'".format(segment)
            except: location_desc = "in path segment (index {})".format(self._context)
        elif self._locationType == 'query': location_desc = "in query parameter '<b>{}</b>'".format(self._context)

        detail = ("Potential IDOR identified.<br>"
                  "Numeric value '<b>{}</b>' {} was changed to '<b>{}</b>'.<br>"
                  "Request URL: <code>{}</code><br>"
                  "Result: <b>200 OK</b> response with a <b>different body</b> (Similarity: <b>{:.2f}%</b>).<br>" # Added similarity
                  "<b>Action:</b> Manually verify by comparing original and modified requests/responses."
                  .format(self._originalNumeric, location_desc, self._testedNumeric,
                          self._helpers.analyzeRequest(self._httpMessages[0]).getUrl().toString(),
                          self._similarity * 100.0)) # Display as percentage
        return detail

    def _create_markers(self, request_bytes, patterns_to_mark): return ArrayList()
    def getHttpMessages(self): return self._httpMessages
    def getHttpService(self): return self._httpService