# -*- coding: utf-8 -*-
# Import redirect and url_for
from flask import Flask, jsonify, request, make_response, abort, redirect, url_for
import uuid
import datetime
import time # For subtle differences

app = Flask(__name__)

# --- Simulated Data (Remains the same) ---
USERS_DB = {
    101: {"name": "Alice", "email": "alice@example.com", "secret": "Alice_SECRET_DATA"},
    102: {"name": "Bob", "email": "bob@example.com", "secret": "Bob_SECRET_DATA"},
    103: {"name": "Charlie", "email": "charlie@example.com", "secret": "Charlie_SECRET_DATA"},
}
OTHER_USER_SIMULATED = {"name": "Other User", "email": "other@example.com", "secret": "OTHER_USER_SECRET"}
ITEMS_DB = {
    2001: {"item_name": "Widget", "price": 19.99},
    2002: {"item_name": "Gadget", "price": 55.00},
}
DOCS_DB = {
    55: "This is the real content of document 55.",
    56: "This is the real content of document 56.",
}
SIMULATED_DOC_CONTENT = {
     54: "This is simulated DIFFERENT content for document ID 54.", # For testing decrement of 55
     55: "This is simulated DIFFERENT content for document ID 55."  # For testing decrement of 56
}
ORDERS_DB = {
    "c27cdd96-3687-46c9-be2f-4bf219f3f7b1": {"product": "Thingamajig", "quantity": 5},
    "a1b2c3d4-e5f6-7890-1234-567890abcdef": {"product": "Doohickey", "quantity": 1},
}
CONFIG_DB = {
    900: {"setting": "enabled", "value": True},
}

# --- Simulated Authentication ---
VALID_SESSION_COOKIE = "SESSIONID= वैध सत्र" # Using non-ascii to test encoding safety too

def is_authenticated():
    auth_cookie = request.cookies.get('session')
    auth_header = request.headers.get('Authorization')
    # Check only cookie now for browser testing simplicity
    # return auth_cookie == VALID_SESSION_COOKIE or auth_header is not None
    return auth_cookie == VALID_SESSION_COOKIE


# --- Endpoints ---

@app.route('/')
def index():
    """Index page with Login button and endpoint list."""
    logged_in = is_authenticated()
    login_status = "Logged In" if logged_in else "Not Logged In"
    
    # Simple HTML for the index page
    html = """
    <!DOCTYPE html>
    <html>
    <head><title>IDOR Test App</title></head>
    <body>
        <h1>IDOR Test App (Simulated Responses)</h1>
        <p><strong>Status: {}</strong></p>
        <form action="/login" method="GET">
            <button type="submit">Set Login Cookie (Simulate Login)</button>
        </form>
        <p>Use specific endpoints below (after logging in if needed) to test the AutoIDOR extension.</p>
        <h2>Test Endpoints (Require Login Cookie unless noted):</h2>
        <ul>
            <li><a href="/users/102/profile">/users/102/profile</a> (Try changing ID to 101 - Should flag IDOR)</li>
            <li><a href="/users/101/profile">/users/101/profile</a> (Valid user)</li>
            <li><a href="/items/2001/info">/items/2001/info</a> (Try changing ID to 2000 - Should get 404, no IDOR flag)</li>
            <li><a href="/documents/56">/documents/56</a> (Try changing ID to 55 - Should flag IDOR due to different simulated body)</li>
            <li><a href="/documents/99">/documents/99</a> (Try changing ID to 98 - Should return similar body, likely ignored by similarity check)</li>
            <li><a href="/api/v1/orders/c27cdd96-3687-46c9-be2f-4bf219f3f7b1">/api/v1/orders/&lt;uuid&gt;</a> (Scanner should ignore UUID path segment)</li>
            <li><a href="/products?category=5&page=2&limit=50&utm_source=123&fmt=456">/products?cat=5&page=2...</a> (Scanner should ignore excluded params page, limit, utm_source, fmt)</li>
            <li><a href="/status">/status</a> (No login needed - Scanner should ignore if auth check enabled)</li>
            <li><a href="/config/900">/config/900</a> (Try changing ID to 899 - Should get different MIME type, no IDOR flag)</li>
        </ul>
    </body>
    </html>
    """.format(login_status)
    return html

# --- NEW: Login Route ---
@app.route('/login', methods=['GET'])
def login():
    """Sets the simulated session cookie and redirects."""
    response = make_response(redirect(url_for('index'))) # Redirect back to index
    response.set_cookie('session', VALID_SESSION_COOKIE, path='/') # Set cookie for the whole app
    print("DEBUG: Login cookie set.")
    return response

# --- Test Case: SIMULATED IDOR ---
@app.route('/users/<int:user_id>/profile')
def get_user_profile(user_id):
    """
    INTENDED TEST: SIMULATES IDOR.
    Accessing 101, 102, 103 returns their data.
    Accessing 100 (like decrement from 101) returns simulated OTHER data (200 OK, different body).
    Accessing 101 (like decrement from 102) returns simulated OTHER data.
    Accessing 102 (like decrement from 103) returns simulated OTHER data.
    Other invalid IDs return 404. Requires authentication.
    """
    if not is_authenticated():
        return jsonify({"error": "Authentication required"}), 401

    user_data = USERS_DB.get(user_id)
    simulated_response = None

    if user_data:
        # Valid user ID found
        simulated_response = user_data.copy()
        simulated_response["note"] = "Original user data retrieved."
    elif user_id in [100, 101, 102]: # Check if ID matches a decremented value from a valid one
        # Simulate finding "another" user's data
        simulated_response = OTHER_USER_SIMULATED.copy()
        simulated_response["note"] = "Simulated data for decremented ID {}.".format(user_id)

    if simulated_response:
        simulated_response["retrieved_at"] = datetime.datetime.utcnow().isoformat() + ".{:06d}Z".format(int(time.time() * 1000000) % 1000000)
        return jsonify(simulated_response)
    else:
         return jsonify({"error": "User not found"}), 404


# --- Test Case: No IDOR (Error Status) ---
# (Remains unchanged)
@app.route('/items/<int:item_id>/info')
def get_item_info(item_id):
    if not is_authenticated():
        return jsonify({"error": "Authentication required"}), 401
    item_data = ITEMS_DB.get(item_id)
    if item_data:
        return jsonify(item_data)
    else:
        abort(404, description="Item not found")

# --- Test Case: SIMULATED Different Body (was Same Response Body) ---
# (Remains unchanged from previous version)
@app.route('/documents/<int:doc_id>')
def get_document_info(doc_id):
    if not is_authenticated():
        return jsonify({"error": "Authentication required"}), 401
    content = None
    if doc_id in DOCS_DB: content = DOCS_DB.get(doc_id)
    elif doc_id in SIMULATED_DOC_CONTENT: content = SIMULATED_DOC_CONTENT.get(doc_id)
    else: content = "Generic content viewer: Document ID {} requested.".format(doc_id)
    response = make_response(content, 200); response.mimetype = "text/plain"
    return response

# --- Test Case: UUID Path Segment ---
# (Remains unchanged)
@app.route('/api/v1/orders/<uuid:order_uuid>')
def get_order_info(order_uuid):
    if not is_authenticated(): return jsonify({"error": "Authentication required"}), 401
    order_uuid_str = str(order_uuid); order_data = ORDERS_DB.get(order_uuid_str)
    if order_data: return jsonify(order_data)
    else: return jsonify({"error": "Order not found"}), 404

# --- Test Case: Excluded Parameters ---
# (Remains unchanged)
@app.route('/products')
def list_products():
    if not is_authenticated(): return jsonify({"error": "Authentication required"}), 401
    params = request.args.to_dict()
    return jsonify({"message": "Received product query", "params": params})

# --- Test Case: Unauthenticated Endpoint ---
# (Remains unchanged)
@app.route('/status')
def get_status():
    return jsonify({"status": "OK", "version": "1.0"})

# --- Test Case: Different MIME Type on Error ---
# (Remains unchanged)
@app.route('/config/<int:config_id>')
def get_config(config_id):
    if not is_authenticated(): return jsonify({"error": "Authentication required"}), 401
    config_data = CONFIG_DB.get(config_id)
    if config_data: return jsonify(config_data) # application/json
    else:
        html_error = "<html><body><h1>Config Not Found</h1><p>Configuration ID {} does not exist.</p></body></html>".format(config_id)
        response = make_response(html_error, 200); response.mimetype = "text/html" # text/html
        return response

# --- Main Execution Block ---
if __name__ == '__main__':
    print("Flask IDOR Test App (Simulated Responses) running on http://127.0.0.1:5000")
    print(f"Simulating required cookie: session={VALID_SESSION_COOKIE}")
    # Startup message now includes less detail, points to index page
    print("Visit http://127.0.0.1:5000 in your browser.")
    app.run(debug=False, port=8888)