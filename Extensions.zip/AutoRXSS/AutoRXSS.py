# -*- coding: utf-8 -*-
from burp import IBurpExtender, IScannerCheck, IScanIssue, IParameter
import sys
import re
from array import array # Import array for highlighting markers

try:
    from urlparse import urlparse, parse_qs # Python 2/Jython
except ImportError:
    from urllib.parse import urlparse, parse_qs # Python 3

# Bypass payloads - Use u"" for Unicode literals and escape backslashes for \u sequences
# Each entry is (payload, name, classification) where classification is:
#   'direct'     - The literal target char (index 0), tested separately
#   'concat'     - Encoding/escape variant that decodes to target char; can be concatenated
#   'individual' - Unicode/full-width variant that reflects as itself; must be sent individually
DQ_BYPASSES = [
    (u'"', u'Direct Double Quote', 'direct'),
    (u'%22', u'URL Encoded', 'concat'),
    (u'%2522', u'Double URL Encoded', 'concat'),
    (u'\\u0022', u'Unicode Encoded', 'concat'),       # Escaped backslash \\
    (u'\\u{22}', u'Unicode Code Point', 'concat'),    # Escaped backslash \\
    (u'%5cu0022', u'URL Encoded Backslash Unicode Encoded (lowercase)', 'concat'),
    (u'%5cu{22}', u'URL Encoded Backslash Unicode Codepoint (lowercase)', 'concat'),
    (u'%26quot;', u'HTML Entity (quot)', 'concat'),
    (u'\uff02', u'Full Width Double Quote U+FF02', 'individual'),
    (u'\u02ba', u'Modifier Letter Double Prime U+02BA', 'individual'),
    #(u'\u2033', u'Double Prime U+2033', 'individual'),
    (u'\u301e', u'Reversed Double Prime Quote U+301E', 'individual'),
    (u'\u201e', u'Double Low-9 Quotation Mark U+201E', 'individual'),
    (u'\u201c', u'Left Double Quotation Mark U+201C', 'individual'),
    #(u'\u275d', u'Heavy Double Turned Comma Quotation Mark Ornament U+275D', 'individual'),
    (u'%C0%A2', u'Overlong UTF-8 #1', 'concat'),
    (u'%E0%80%A2', u'Overlong UTF-8 #2', 'concat'),
    (u'%F0%80%80%A2', u'Overlong UTF-8 #3', 'concat')
]

TAG_BYPASSES = [
    (u'<', u'Direct Angle Bracket', 'direct'),
    (u'%3C', u'URL Encoded', 'concat'),
    (u'%253C', u'Double URL Encoded', 'concat'),
    (u'\\u003C', u'Unicode Encoded', 'concat'),       # Escaped backslash \\
    (u'\\u{3C}', u'Unicode Code Point', 'concat'),    # Escaped backslash \\
    (u'%5cu003C', u'URL Encoded Backslash Unicode Encoded (lowercase)', 'concat'),
    (u'%5cu{3C}', u'URL Encoded Backslash Unicode Codepoint (lowercase)', 'concat'),
    (u'%26lt;', u'HTML Entity (lt)', 'concat'),
    (u'\uff1c', u'Full Width Angle Bracket U+FF1C', 'individual'),
    (u'\u27e8', u'Mathematical Left Angle Bracket U+27E8', 'individual'),
    (u'\u2329', u'Left-Pointing Angle Bracket U+2329', 'individual'),
    #(u'\u2039', u'Single Left-Pointing Angle Quotation Mark U+2039', 'individual'),
    #(u'\u276e', u'Heavy Left-Pointing Angle Quotation Mark Ornament U+275B', 'individual'),
    (u'\u3008', u'CJK Angle Bracket U+3008', 'individual'),
    (u'%C0%BC', u'Overlong UTF-8 #1', 'concat'),
    (u'%E0%80%BC', u'Overlong UTF-8 #2', 'concat'),
    (u'%F0%80%80%BC', u'Overlong UTF-8 #3', 'concat')
]

# Threshold for body size deviation in concatenated bypass anomaly detection.
# If the concatenated response body differs by more than this fraction from
# the baseline (reflection check) response, fall back to individual checks.
BODY_SIZE_DEVIATION_THRESHOLD = 0.30


# Main Burp Extender class - Handles registration only
class BurpExtender(IBurpExtender):

    # Implement IBurpExtender
    def registerExtenderCallbacks(self, callbacks):
        # Set extension name
        callbacks.setExtensionName("AutoRXSS")
        callbacks.printOutput("AutoRXSS Extension Loaded")

        # Create an instance of our scanner class and register it
        callbacks.registerScannerCheck(AutoRxssScanner(callbacks))


# Dedicated class for the scanner check logic
class AutoRxssScanner(IScannerCheck):

    def __init__(self, callbacks):
        self._callbacks = callbacks
        self._helpers = callbacks.getHelpers()
        self.test_suffix = u"xptotest"
        # This is now part of the scanner instance
        self.scanned_requests = set()

    # Implement IScannerCheck
    def doPassiveScan(self, baseRequestResponse):
        issues = []
        helpers = self._helpers
        callbacks = self._callbacks

        # Analyze base request
        analyzed_request = helpers.analyzeRequest(baseRequestResponse)
        url = analyzed_request.getUrl()
        method = analyzed_request.getMethod()
        params = analyzed_request.getParameters()
        request_bytes = baseRequestResponse.getRequest()
        http_service = baseRequestResponse.getHttpService()

        # Analyze base response
        response_bytes = baseRequestResponse.getResponse()
        if response_bytes is None:
            return issues

        analyzed_response = helpers.analyzeResponse(response_bytes)

        # *** CHECK CONTENT-TYPE HEADER FOR JSON ***
        headers = analyzed_response.getHeaders()
        for header in headers:
            # Check for Content-Type header (case-insensitive check on header name)
            if header.lower().startswith("content-type:"):
                # Check if value contains application/json
                if "application/json" in header.lower():
                    return issues
                break

        mime_type = analyzed_response.getInferredMimeType()

        # *** Check MIME Type (HTML or XML) ***
        allowed_mime_types = ["HTML", "XML"]
        if mime_type not in allowed_mime_types:
            stated_mime = analyzed_response.getStatedMimeType()
            # Also check stated MIME type for keywords if inferred didn't match
            if not stated_mime or not any(keyword in stated_mime.upper() for keyword in allowed_mime_types):
                 return issues

        # Check Request Type (GET)
        if method.upper() != 'GET':
            return issues

        # --- Create list of all insertion points (URL Params + URL Path segments) ---
        insertion_points = []

        # 1. Add URL Parameters to insertion points
        url_params = [p for p in params if p.getType() == IParameter.PARAM_URL]
        for p in url_params:
            insertion_points.append({
                'name': p.getName(),
                'type': 'URL_PARAM',
                'original_value': p.getValue() if p.getValue() else u""
            })

        # 2. Add URL Path segments to insertion points (robustly)
        path_string = url.getPath()
        if path_string and path_string != "/":
            # Split by '/' and filter out empty strings (from leading/trailing slashes)
            path_segments = [segment for segment in path_string.split('/') if segment]
            for i, segment in enumerate(path_segments):
                insertion_points.append({
                    'name': segment, # The value of the segment
                    'type': 'URL_PATH',
                    'original_value': segment,
                    'path_segments': path_segments, # The full list of original segments
                    'path_index': i # The index of this segment
                })

        # If no insertion points found, exit
        if not insertion_points:
            return issues

        # Create request identifier based on URL path and sorted param names
        param_names_tuple = tuple(sorted([p.getName() for p in url_params]))
        request_identifier = (url.getPath(), param_names_tuple)

        # Redundancy Check is now active
        if request_identifier in self.scanned_requests:
             callbacks.printOutput("[AutoRXSS Debug] Skipping {} with params {}: Already scanned.".format(url.toString(), param_names_tuple))
             return issues # Stop processing if already scanned

        # Iterate through all identified insertion points
        for insertion_point in insertion_points:
            param_name = insertion_point['name']
            original_value = insertion_point['original_value']

            callbacks.printOutput("[AutoRXSS Debug] Testing {} '{}' in {}".format(insertion_point['type'], param_name, url.toString()))

            reflection_value = original_value + self.test_suffix # Base reflection string

            # --- 4.1. Basic Reflection Check ---
            reflection_request_bytes = self._build_test_request(http_service, request_bytes, insertion_point, reflection_value)
            if reflection_request_bytes is None:
                continue # Skip if request could not be built

            reflection_response_body_string = None
            baseline_status_code = None
            baseline_body_length = None

            try:
                reflection_check_rr = callbacks.makeHttpRequest(http_service, reflection_request_bytes)
                if reflection_check_rr.getResponse() is None:
                    callbacks.printOutput("[AutoRXSS Debug] No response for reflection check request for '{}'".format(param_name))
                    continue

                reflection_response_bytes = reflection_check_rr.getResponse()
                reflection_response_info = helpers.analyzeResponse(reflection_response_bytes)
                reflection_response_body_bytes = reflection_response_bytes[reflection_response_info.getBodyOffset():]
                reflection_response_body_string = helpers.bytesToString(reflection_response_body_bytes)

                # Store baseline for anomaly detection in concatenated checks
                baseline_status_code = reflection_response_info.getStatusCode()
                baseline_body_length = len(reflection_response_body_bytes)

                if reflection_response_body_string.find(reflection_value) == -1:
                    callbacks.printOutput("[AutoRXSS Debug] Insertion Point '{}': Initial reflection value '{}' not found in response string.".format(param_name, reflection_value))
                    continue

                callbacks.printOutput("[AutoRXSS Debug] Insertion Point '{}': Initial reflection '{}' found.".format(param_name, reflection_value))

            except Exception as e:
                callbacks.printError("[AutoRXSS Error] Failed sending reflection check for {}: {}".format(param_name, e))
                continue

            # --- 4.2. Context Check (and determine initial surroundings) ---
            found_in_dq_context = False
            found_in_tag_context = False
            initial_reflection_followed_by_dq = False
            initial_reflection_followed_by_lt = False
            dq_vulnerable = False
            tag_vulnerable = False

            if reflection_response_body_string is not None:
                start_index = 0
                while True:
                    index = reflection_response_body_string.find(reflection_value, start_index)
                    if index == -1:
                        break

                    char_before = None
                    char_after = None
                    if index > 0:
                        try: char_before = reflection_response_body_string[index-1]
                        except IndexError: pass
                    if index + len(reflection_value) < len(reflection_response_body_string):
                        try: char_after = reflection_response_body_string[index + len(reflection_value)]
                        except IndexError: pass

                    is_occurrence_in_dq = False
                    try:
                        if char_after == '"' and char_before != '>':
                             is_occurrence_in_dq = True
                             found_in_dq_context = True
                             initial_reflection_followed_by_dq = True

                        if not is_occurrence_in_dq:
                             found_in_tag_context = True
                             if char_after == '<':
                                 initial_reflection_followed_by_lt = True

                    except Exception as e_ctx:
                         callbacks.printError("[AutoRXSS Error] Error during context check for '{}' at index {}: {}".format(param_name, index, e_ctx))

                    start_index = index + 1

                if found_in_dq_context:
                    callbacks.printOutput("[AutoRXSS Debug] Insertion Point '{}': Found in DQ context. Initial reflection followed by DQ: {}".format(param_name, initial_reflection_followed_by_dq))
                if found_in_tag_context:
                     callbacks.printOutput("[AutoRXSS Debug] Insertion Point '{}': Found in Tag/Text context. Initial reflection followed by LT: {}".format(param_name, initial_reflection_followed_by_lt))


            # --- Test Direct Double Quote Injection ---
            if found_in_dq_context:
                direct_dq_payload = reflection_value + u'"'
                expected_pattern_dq = reflection_value + (u'""' if initial_reflection_followed_by_dq else u'"')

                direct_dq_request_bytes = self._build_test_request(http_service, request_bytes, insertion_point, direct_dq_payload)
                if direct_dq_request_bytes is None: continue

                try:
                    direct_dq_rr = callbacks.makeHttpRequest(http_service, direct_dq_request_bytes)
                    if direct_dq_rr.getResponse() is None:
                        continue

                    direct_dq_response_bytes = direct_dq_rr.getResponse()
                    direct_dq_response_info = helpers.analyzeResponse(direct_dq_response_bytes)
                    direct_dq_body_bytes = direct_dq_response_bytes[direct_dq_response_info.getBodyOffset():]
                    direct_dq_body_string = helpers.bytesToString(direct_dq_body_bytes)

                    if direct_dq_body_string.find(expected_pattern_dq) != -1:
                        callbacks.printOutput("[AutoRXSS VULN] Insertion Point '{}': Direct double quote injection successful (found pattern '{}')!".format(param_name, expected_pattern_dq))
                        issues.append(self.report_issue(
                            http_service, url, direct_dq_rr, insertion_point, direct_dq_payload, u"Double Quotes", None
                        ))
                        dq_vulnerable = True
                        continue
                    else:
                        callbacks.printOutput("[AutoRXSS Debug] Insertion Point '{}': Direct double quote injection failed (pattern '{}' not found). Trying bypasses.".format(param_name, expected_pattern_dq))
                except Exception as e:
                    callbacks.printError("[AutoRXSS Error] Failed sending/processing direct double quote check for {}: {}".format(param_name, e))

            # --- Test Direct HTML Tag Injection ---
            if found_in_tag_context:
                direct_tag_payload = reflection_value + u'<'
                expected_pattern_tag = reflection_value + (u'<<' if initial_reflection_followed_by_lt else u'<')

                direct_tag_request_bytes = self._build_test_request(http_service, request_bytes, insertion_point, direct_tag_payload)
                if direct_tag_request_bytes is None: continue

                try:
                    direct_tag_rr = callbacks.makeHttpRequest(http_service, direct_tag_request_bytes)
                    if direct_tag_rr.getResponse() is None:
                        continue

                    direct_tag_response_bytes = direct_tag_rr.getResponse()
                    direct_tag_response_info = helpers.analyzeResponse(direct_tag_response_bytes)
                    direct_tag_body_bytes = direct_tag_response_bytes[direct_tag_response_info.getBodyOffset():]
                    direct_tag_body_string = helpers.bytesToString(direct_tag_body_bytes)

                    if direct_tag_body_string.find(expected_pattern_tag) != -1:
                         callbacks.printOutput("[AutoRXSS VULN] Insertion Point '{}': Direct tag injection successful (found pattern '{}')!".format(param_name, expected_pattern_tag))
                         issues.append(self.report_issue(
                            http_service, url, direct_tag_rr, insertion_point, direct_tag_payload, u"HTML Tags", None
                         ))
                         tag_vulnerable = True
                         continue
                    else:
                         callbacks.printOutput("[AutoRXSS Debug] Insertion Point '{}': Direct tag injection failed (pattern '{}' not found). Trying bypasses.".format(param_name, expected_pattern_tag))
                except Exception as e:
                    callbacks.printError("[AutoRXSS Error] Failed sending/processing direct tag check for {}: {}".format(param_name, e))

            # --- Double Quote Bypass Check (Optimized: Concatenated Screening) ---
            if found_in_dq_context and not dq_vulnerable:
                callbacks.printOutput("[AutoRXSS Debug] Insertion Point '{}': Trying double quote bypasses (optimized)...".format(param_name))

                concat_bypasses, individual_bypasses = self._split_bypasses(DQ_BYPASSES)

                # Phase 1: Concatenated screening check (1 request for all concat bypasses)
                if concat_bypasses:
                    concat_payload_suffix = u''.join([bp[0] for bp in concat_bypasses])
                    concat_payload = reflection_value + concat_payload_suffix

                    concat_request_bytes = self._build_test_request(http_service, request_bytes, insertion_point, concat_payload)
                    if concat_request_bytes is not None:
                        try:
                            concat_rr = callbacks.makeHttpRequest(http_service, concat_request_bytes)
                            if concat_rr.getResponse() is not None:
                                concat_response_bytes = concat_rr.getResponse()

                                if self._is_response_anomalous(baseline_status_code, baseline_body_length, concat_response_bytes):
                                    # ANOMALOUS: Fall back to individual checks for all concat bypasses
                                    callbacks.printOutput("[AutoRXSS Debug] Insertion Point '{}': Concat DQ response anomalous, falling back to individual checks.".format(param_name))
                                    for bypass_char, bypass_name, _ in concat_bypasses:
                                        if dq_vulnerable:
                                            break
                                        dq_vulnerable = self._test_individual_bypass(
                                            http_service, request_bytes, insertion_point,
                                            reflection_value, bypass_char, bypass_name,
                                            u'"', initial_reflection_followed_by_dq,
                                            param_name, url, issues, u"Double Quotes"
                                        )
                                else:
                                    # NORMAL response: Check with regex
                                    concat_resp_info = helpers.analyzeResponse(concat_response_bytes)
                                    concat_body_bytes = concat_response_bytes[concat_resp_info.getBodyOffset():]
                                    concat_body_string = helpers.bytesToString(concat_body_bytes)

                                    regex = self._build_concat_regex(reflection_value, u'"', initial_reflection_followed_by_dq)
                                    if regex.search(concat_body_string):
                                        # MATCH: At least one bypass decoded. Fall back to identify which one.
                                        callbacks.printOutput("[AutoRXSS Debug] Insertion Point '{}': Concat DQ regex matched! Identifying specific bypass...".format(param_name))
                                        for bypass_char, bypass_name, _ in concat_bypasses:
                                            if dq_vulnerable:
                                                break
                                            dq_vulnerable = self._test_individual_bypass(
                                                http_service, request_bytes, insertion_point,
                                                reflection_value, bypass_char, bypass_name,
                                                u'"', initial_reflection_followed_by_dq,
                                                param_name, url, issues, u"Double Quotes"
                                            )
                                    else:
                                        # NO MATCH: Skip all concat bypasses (traffic savings!)
                                        callbacks.printOutput("[AutoRXSS Debug] Insertion Point '{}': Concat DQ regex did NOT match. Skipping all concatenable DQ bypasses.".format(param_name))
                        except Exception as e:
                            callbacks.printError("[AutoRXSS Error] Failed concat DQ check for {}: {}".format(param_name, e))
                            # On exception, fall back to individual for safety
                            for bypass_char, bypass_name, _ in concat_bypasses:
                                if dq_vulnerable:
                                    break
                                dq_vulnerable = self._test_individual_bypass(
                                    http_service, request_bytes, insertion_point,
                                    reflection_value, bypass_char, bypass_name,
                                    u'"', initial_reflection_followed_by_dq,
                                    param_name, url, issues, u"Double Quotes"
                                )

                # Phase 2: Individual-only bypasses (Unicode/full-width, always one-at-a-time)
                if not dq_vulnerable:
                    for bypass_char, bypass_name, _ in individual_bypasses:
                        if dq_vulnerable:
                            break
                        dq_vulnerable = self._test_individual_bypass(
                            http_service, request_bytes, insertion_point,
                            reflection_value, bypass_char, bypass_name,
                            None, False,
                            param_name, url, issues, u"Double Quotes"
                        )

                if dq_vulnerable: continue

            # --- HTML Tag Bypass Check (Optimized: Concatenated Screening) ---
            if found_in_tag_context and not tag_vulnerable:
                callbacks.printOutput("[AutoRXSS Debug] Insertion Point '{}': Trying HTML tag bypasses (optimized)...".format(param_name))

                concat_bypasses, individual_bypasses = self._split_bypasses(TAG_BYPASSES)

                # Phase 1: Concatenated screening check (1 request for all concat bypasses)
                if concat_bypasses:
                    concat_payload_suffix = u''.join([bp[0] for bp in concat_bypasses])
                    concat_payload = reflection_value + concat_payload_suffix

                    concat_request_bytes = self._build_test_request(http_service, request_bytes, insertion_point, concat_payload)
                    if concat_request_bytes is not None:
                        try:
                            concat_rr = callbacks.makeHttpRequest(http_service, concat_request_bytes)
                            if concat_rr.getResponse() is not None:
                                concat_response_bytes = concat_rr.getResponse()

                                if self._is_response_anomalous(baseline_status_code, baseline_body_length, concat_response_bytes):
                                    # ANOMALOUS: Fall back to individual checks
                                    callbacks.printOutput("[AutoRXSS Debug] Insertion Point '{}': Concat TAG response anomalous, falling back to individual checks.".format(param_name))
                                    for bypass_char, bypass_name, _ in concat_bypasses:
                                        if tag_vulnerable:
                                            break
                                        tag_vulnerable = self._test_individual_bypass(
                                            http_service, request_bytes, insertion_point,
                                            reflection_value, bypass_char, bypass_name,
                                            u'<', initial_reflection_followed_by_lt,
                                            param_name, url, issues, u"HTML Tags"
                                        )
                                else:
                                    # NORMAL response: Check with regex
                                    concat_resp_info = helpers.analyzeResponse(concat_response_bytes)
                                    concat_body_bytes = concat_response_bytes[concat_resp_info.getBodyOffset():]
                                    concat_body_string = helpers.bytesToString(concat_body_bytes)

                                    regex = self._build_concat_regex(reflection_value, u'<', initial_reflection_followed_by_lt)
                                    if regex.search(concat_body_string):
                                        # MATCH: At least one bypass decoded. Fall back to identify which one.
                                        callbacks.printOutput("[AutoRXSS Debug] Insertion Point '{}': Concat TAG regex matched! Identifying specific bypass...".format(param_name))
                                        for bypass_char, bypass_name, _ in concat_bypasses:
                                            if tag_vulnerable:
                                                break
                                            tag_vulnerable = self._test_individual_bypass(
                                                http_service, request_bytes, insertion_point,
                                                reflection_value, bypass_char, bypass_name,
                                                u'<', initial_reflection_followed_by_lt,
                                                param_name, url, issues, u"HTML Tags"
                                            )
                                    else:
                                        # NO MATCH: Skip all concat bypasses (traffic savings!)
                                        callbacks.printOutput("[AutoRXSS Debug] Insertion Point '{}': Concat TAG regex did NOT match. Skipping all concatenable TAG bypasses.".format(param_name))
                        except Exception as e:
                            callbacks.printError("[AutoRXSS Error] Failed concat TAG check for {}: {}".format(param_name, e))
                            # On exception, fall back to individual for safety
                            for bypass_char, bypass_name, _ in concat_bypasses:
                                if tag_vulnerable:
                                    break
                                tag_vulnerable = self._test_individual_bypass(
                                    http_service, request_bytes, insertion_point,
                                    reflection_value, bypass_char, bypass_name,
                                    u'<', initial_reflection_followed_by_lt,
                                    param_name, url, issues, u"HTML Tags"
                                )

                # Phase 2: Individual-only bypasses (Unicode/full-width, always one-at-a-time)
                if not tag_vulnerable:
                    for bypass_char, bypass_name, _ in individual_bypasses:
                        if tag_vulnerable:
                            break
                        tag_vulnerable = self._test_individual_bypass(
                            http_service, request_bytes, insertion_point,
                            reflection_value, bypass_char, bypass_name,
                            None, False,
                            param_name, url, issues, u"HTML Tags"
                        )

        # --- End of Insertion Point Loop ---

        # Add identifier to scanned set *after* processing all insertion points
        self.scanned_requests.add(request_identifier)

        return issues

    def _build_test_request(self, http_service, base_request_bytes, insertion_point, new_value):
        """
        Builds a new request with the new_value placed in the correct insertion point.
        """
        helpers = self._helpers

        if insertion_point['type'] == 'URL_PARAM':
            param = helpers.buildParameter(insertion_point['name'], new_value, IParameter.PARAM_URL)
            return helpers.updateParameter(base_request_bytes, param)

        elif insertion_point['type'] == 'URL_PATH':
            try:
                # *** FIX: Use the analyzeRequest overload that includes the http_service ***
                req_info = helpers.analyzeRequest(http_service, base_request_bytes)

                # Make a mutable copy of the headers list
                headers = list(req_info.getHeaders())
                first_line = headers[0]

                original_path = req_info.getUrl().getPath()

                # Get the context for reconstruction from the insertion point
                original_segments = insertion_point['path_segments']
                segment_index = insertion_point['path_index']

                # URL Encode the new value before placing it in the path
                encoded_new_value = helpers.urlEncode(new_value)

                # Create a mutable copy of the segments list
                modified_segments = list(original_segments)
                # Replace the segment at the correct index
                modified_segments[segment_index] = encoded_new_value

                # Rebuild the path string. Handle leading/trailing slashes from original.
                modified_path = "/" + "/".join(modified_segments)
                if original_path.endswith('/') and len(modified_segments) > 0:
                    modified_path += "/"

                # Rebuild the first line of the HTTP request
                modified_first_line = first_line.replace(original_path, modified_path, 1)

                # Update the headers list
                headers[0] = modified_first_line

                # Get the original request body
                body_bytes = base_request_bytes[req_info.getBodyOffset():]

                # Rebuild and return the full HTTP message
                return helpers.buildHttpMessage(headers, body_bytes)
            except Exception as e:
                self._callbacks.printError("[AutoRXSS Error] Failed to build URL_PATH test request for '{}': {}".format(insertion_point['name'], e))
                return None

        return None # Should not be reached

    def _split_bypasses(self, bypass_list):
        """Splits bypass_list[1:] into (concat_list, individual_list)."""
        concat = []
        individual = []
        for entry in bypass_list[1:]:  # skip index 0 (direct)
            if entry[2] == 'concat':
                concat.append(entry)
            else:
                individual.append(entry)
        return concat, individual

    def _build_concat_regex(self, reflection_value, target_char, followed_by_target):
        """
        Build regex pattern to detect if target_char (< or ") appears
        after reflection_value in a concatenated bypass response.
        """
        escaped_rv = re.escape(reflection_value)

        if target_char == u'<':
            # Junk chars from TAG concat bypass strings: %3C %253C \u003C \u{3C} %5cu003C %5cu{3C} %26lt; %C0%BC %E0%80%BC %F0%80%80%BC
            junk = r'[%0-9A-Fa-f\\u\{\}&lLtT;]*'
        else:  # target_char == u'"'
            # Junk chars from DQ concat bypass strings: %22 %2522 \u0022 \u{22} %5cu0022 %5cu{22} %26quot; %C0%A2 %E0%80%A2 %F0%80%80%A2
            junk = r'[%0-9A-Fa-f\\u\{\}&qQuUoOtT;]*'

        escaped_target = re.escape(target_char)

        if followed_by_target:
            # Expect: reflection_value + JUNK + target + JUNK + target
            pattern = escaped_rv + junk + escaped_target + junk + escaped_target
        else:
            # Expect: reflection_value + JUNK + target
            pattern = escaped_rv + junk + escaped_target

        return re.compile(pattern)

    def _is_response_anomalous(self, baseline_status, baseline_body_length, test_response_bytes):
        """
        Returns True if the test response is anomalous compared to baseline.
        Anomalous = different status code OR body size differs by more than threshold.
        """
        helpers = self._helpers
        test_info = helpers.analyzeResponse(test_response_bytes)
        test_status = test_info.getStatusCode()

        if test_status != baseline_status:
            return True

        test_body_length = len(test_response_bytes) - test_info.getBodyOffset()

        if baseline_body_length == 0:
            return test_body_length > 100

        deviation = abs(test_body_length - baseline_body_length) / float(baseline_body_length)
        return deviation > BODY_SIZE_DEVIATION_THRESHOLD

    def _test_individual_bypass(self, http_service, base_request_bytes, insertion_point,
                                reflection_value, bypass_char, bypass_name,
                                expected_target_char, followed_by_target,
                                param_name, url, issues, context_type):
        """
        Tests a single bypass payload individually.
        Returns True if vulnerability found, False otherwise.
        """
        helpers = self._helpers
        callbacks = self._callbacks

        bypass_payload_value = reflection_value + bypass_char

        if expected_target_char is not None:
            expected_char = expected_target_char
        else:
            expected_char = self.get_expected_reflection_char_simple(bypass_char)

        # Build expected pattern based on context
        if expected_char == u'"':
            expected_pattern = reflection_value + (u'""' if followed_by_target else u'"')
        elif expected_char == u'<':
            expected_pattern = reflection_value + (u'<<' if followed_by_target else u'<')
        else:
            # For individual Unicode bypasses, they reflect as themselves
            expected_pattern = reflection_value + expected_char

        bypass_request_bytes = self._build_test_request(http_service, base_request_bytes, insertion_point, bypass_payload_value)
        if bypass_request_bytes is None:
            return False

        try:
            bypass_rr = callbacks.makeHttpRequest(http_service, bypass_request_bytes)
            if bypass_rr.getResponse() is None:
                return False

            bypass_resp_bytes = bypass_rr.getResponse()
            bypass_resp_info = helpers.analyzeResponse(bypass_resp_bytes)
            bypass_body_bytes = bypass_resp_bytes[bypass_resp_info.getBodyOffset():]
            bypass_body_string = helpers.bytesToString(bypass_body_bytes)

            if bypass_body_string.find(expected_pattern) != -1:
                callbacks.printOutput("[AutoRXSS VULN] Insertion Point '{}': {} bypass successful with {} ({}) -> resulting in pattern '{}'!".format(
                    param_name,
                    "Double quote" if "Double" in context_type else "HTML tag",
                    bypass_name, bypass_char, expected_pattern
                ))
                issues.append(self.report_issue(
                    http_service, url, bypass_rr, insertion_point,
                    bypass_payload_value, context_type, bypass_name
                ))
                return True
        except Exception as e:
            callbacks.printError("[AutoRXSS Error] Failed sending/processing bypass check ({}) for {}: {}".format(bypass_name, param_name, e))

        return False

    def consolidateDuplicateIssues(self, existingIssue, newIssue):
        if existingIssue.getIssueName() == newIssue.getIssueName() and existingIssue.getIssueDetail() == newIssue.getIssueDetail():
            return -1
        else:
            return 0

    def doActiveScan(self, baseRequestResponse, insertionPoint):
        return None

    def get_expected_reflection_char_simple(self, bypass_payload_char):
        if bypass_payload_char in [
            u'%22', u'%2522', u'\\u0022', u'\\u{22}', u'%26quot;',
            u'%C0%A2', u'%E0%80%A2', u'%F0%80%80%A2',
            u'%5cu0022', u'%5cu{22}'
        ]:
            return u'"'
        if bypass_payload_char in [
            u'%3C', u'%253C', u'\\u003C', u'\\u{3C}', u'%26lt;',
            u'%C0%BC', u'%E0%80%BC', u'%F0%80%80%BC',
            u'%5cu003C', u'%5cu{3C}'
        ]:
            return u'<'
        return bypass_payload_char

    def report_issue(self, http_service, url, vulnerable_rr, insertion_point, payload, context_type, bypass_used):
        helpers = self._helpers
        callbacks = self._callbacks

        # Build new issue title based on insertion point type
        param_name = insertion_point['name']
        param_type = insertion_point['type']
        context_type_short = "DQ" if "Double Quotes" in context_type else "TAG"

        if param_type == 'URL_PARAM':
            issue_name = u'AutoRXSS: "{}" URL Param ({})'.format(param_name, context_type_short)
        else: # URL_PATH
            issue_name = u'AutoRXSS: URL Path Value ({})'.format(context_type_short)

        detail = u"The application reflects user input from a {} ('<b>{}</b>') into the HTML response without proper sanitization.<br/><br/>".format("URL Parameter" if param_type == 'URL_PARAM' else "URL Path Segment", param_name)
        detail += u"<b>Vulnerable Insertion Point:</b> {}<br/>".format(param_name)
        detail += u"<b>Context:</b> Reflected inside {}<br/>".format(context_type)
        encoded_payload_display = payload
        try:
            encoded_payload_display = encoded_payload_display.replace(u"&", u"&amp;").replace(u"<", u"&lt;").replace(u">", u"&gt;").replace(u'"', u"&quot;")
        except Exception:
            callbacks.printError("Error HTML encoding payload for display: {}".format(payload))
        detail += u"<b>Successful Payload Fragment:</b> {}<br/>".format(encoded_payload_display)
        if bypass_used:
            detail += u"<b>Bypass Method Used:</b> {}<br/>".format(bypass_used)
        else:
            detail += u"<b>Bypass Method Used:</b> Direct injection (no bypass needed)<br/>"

        request_highlights = []
        response_highlights = []
        vuln_request_bytes_raw = vulnerable_rr.getRequest()
        vuln_response_bytes_raw = vulnerable_rr.getResponse()

        try:
            payload_string = payload
            if vuln_request_bytes_raw:
                request_string = helpers.bytesToString(vuln_request_bytes_raw)
                start = 0
                req_len = len(request_string)
                while start < req_len:
                    index = request_string.find(payload_string, start)
                    if index == -1:
                        break
                    marker = array('i', [index, index + len(payload_string)])
                    request_highlights.append(marker)
                    start = index + 1
            if vuln_response_bytes_raw:
                response_string = helpers.bytesToString(vuln_response_bytes_raw)
                start = 0
                resp_len = len(response_string)
                while start < resp_len:
                    index = response_string.find(payload_string, start)
                    if index == -1:
                        break
                    marker = array('i', [index, index + len(payload_string)])
                    response_highlights.append(marker)
                    start = index + 1
        except Exception as e:
            callbacks.printError("[AutoRXSS Error] Failed creating highlights (string search) for payload '{}': {}".format(payload, e))
            request_highlights = []
            response_highlights = []

        highlighted_rr = callbacks.applyMarkers(vulnerable_rr, request_highlights, response_highlights)
        return CustomScanIssue(
            http_service, url, issue_name, detail,
            "High", "Firm", [highlighted_rr]
        )

# Custom implementation of IScanIssue
class CustomScanIssue(IScanIssue):
    def __init__(self, httpService, url, name, detail, severity, confidence, httpMessages):
        self._httpService = httpService
        self._url = url
        self._name = name
        self._detail = detail
        self._severity = severity
        self._confidence = confidence
        self._httpMessages = httpMessages

    def getUrl(self):
        return self._url

    def getIssueName(self):
        return self._name

    def getIssueType(self):
        return 0x08000001

    def getSeverity(self):
        return self._severity

    def getConfidence(self):
        return self._confidence

    def getIssueBackground(self):
        return None

    def getRemediationBackground(self):
        return None

    def getIssueDetail(self):
        return self._detail

    def getRemediationDetail(self):
        return None

    def getHttpMessages(self):
        return self._httpMessages

    def getHttpService(self):
        return self._httpService
