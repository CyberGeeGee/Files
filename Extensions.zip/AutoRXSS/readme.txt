AutoRXSS - Burp Suite Passive Scanner Extension for Reflected XSS Detection
============================================================================

OVERVIEW:
AutoRXSS is a Burp Suite extension (Jython/Python 2.7) that passively scans
HTTP GET requests for Reflected Cross-Site Scripting (XSS) vulnerabilities.
It performs lightweight probing to determine if there is a potential avenue
for XSS, without throwing actual attack payloads.

HOW IT WORKS:
1. Intercepts GET requests with HTML/XML responses via Burp's passive scanner
2. Identifies insertion points: URL parameters and URL path segments
3. Sends a reflection probe (appends "xptotest" to original value)
4. If reflected, detects context:
   - DQ Context: reflection appears inside double-quoted attribute (char after = ", char before != >)
   - TAG Context: reflection appears in HTML tag/text context
5. Tests direct injection of the target char (" or <)
6. If direct fails, tests encoding/bypass variants:

   OPTIMIZED CONCATENATED SCREENING (v2):
   - "Concat" bypasses (URL encoding, double encoding, unicode escapes, HTML entities,
     overlong UTF-8) are concatenated into ONE request as a screening check
   - If the response is normal (same status code, similar body size) AND the target char
     is NOT found via regex => all concat bypasses are skipped (saves ~10 requests)
   - If the response is anomalous OR regex finds a match => falls back to individual checks
   - "Individual" bypasses (Unicode/full-width chars like U+FF1C, U+FF02, etc.) are always
     sent one-at-a-time since they reflect as themselves, not as the target char

7. Reports findings as Burp Scanner issues with request/response highlighting

BYPASS TYPES TESTED:
- Direct character injection (< or ")
- URL Encoding (%3C, %22)
- Double URL Encoding (%253C, %2522)
- Unicode Escape (\u003C, \u0022)
- Unicode Code Point (\u{3C}, \u{22})
- URL Encoded Backslash Unicode (%5cu003C, %5cu0022)
- HTML Entity (%26lt;, %26quot;)
- Full Width Unicode (U+FF1C, U+FF02)
- Various Unicode quote/bracket alternatives
- Overlong UTF-8 encodings (%C0%BC, %C0%A2, etc.)

FILES:
- AutoRXSS.py        - The main Burp extension (load this in Burp)
- AutoRXSS_backup.py - Backup of the pre-optimization version
- webapp.py           - Flask test application for validating the extension
- readme.txt          - This file
- prompt.txt          - LLM prompt to regenerate the current code

INSTALLATION:
1. Ensure Jython standalone JAR is configured in Burp Suite
   (Burp > Settings > Extensions > Python Environment)
2. Go to Burp > Extensions > Add
3. Extension Type: Python
4. Select AutoRXSS.py
5. Click Next - extension will load and register as a passive scanner

TESTING WITH webapp.py:
The Flask test app (webapp.py) provides 43 routes covering every extension code path.
Run: python webapp.py (starts on http://127.0.0.1:8888)

Route categories:
  - Direct injection (2): /dq_direct, /tag_direct — no filter, direct " or < works
  - DQ concat bypass (10): /dq_bypass_* — one route per concat bypass (url_encoded,
    double_url_encoded, unicode, unicode_codepoint, backslash_unicode_lc,
    backslash_codepoint_lc, html_entity, overlong1/2/3). Returns HTTP 400 for
    concat-length payloads to trigger anomaly fallback → individual testing.
  - DQ individual bypass (5): /dq_bypass_full_width, modifier_prime, reversed_prime,
    low9_quote, left_dq — Unicode/full-width chars, always tested individually.
  - TAG concat bypass (10): /tag_bypass_* — same pattern as DQ for < context.
  - TAG individual bypass (4): /tag_bypass_full_width, math_angle, left_point, cjk_angle.
  - Concat screening (4): /dq_concat_positive (no filter → regex match → fallback),
    /tag_concat_positive, /dq_concat_negative (total filter → skip), /tag_concat_negative.
  - URL path segments (2): /pathtest/<segment>, /pathtest_dq/<segment>.
  - Negative tests (5): /safe (escaped), /no_reflection, /not_html (text/plain),
    /json_response (application/json), /post_only (POST method).

Test procedure:
1. Start webapp.py
2. Configure browser to proxy through Burp
3. Browse the index page — all test links are listed
4. Check Burp Scanner results for AutoRXSS findings
5. Verify: bypass routes produce findings, negative routes produce nothing,
   concat_negative routes show "Skipping all concatenable bypasses" in debug log

KEY DESIGN DECISIONS:
- Passive scanner only (no active scanning) - minimal traffic impact
- GET requests only - focused on reflected XSS in query params and paths
- Context-aware: different bypass strategies for DQ vs TAG contexts
- Concatenated bypass screening reduces requests by ~56% for non-vulnerable endpoints
- Stops testing a context once first bypass succeeds (reports first finding only)
- Deduplication via (path, sorted_param_names) identifier
- 30% body size deviation threshold for anomaly detection in concatenated checks

ARCHITECTURE:
- BurpExtender: Entry point, registers the scanner
- AutoRxssScanner: Core scanning logic with methods:
  - doPassiveScan(): Main scan flow
  - _build_test_request(): Constructs modified HTTP requests
  - _split_bypasses(): Separates concat vs individual bypass lists
  - _build_concat_regex(): Builds regex for concatenated response matching
  - _is_response_anomalous(): Checks if response deviates from baseline
  - _test_individual_bypass(): Tests a single bypass payload
  - get_expected_reflection_char_simple(): Maps bypass to expected reflection
  - report_issue(): Creates Burp Scanner issue with highlights
- CustomScanIssue: Implements IScanIssue interface for Burp reporting
