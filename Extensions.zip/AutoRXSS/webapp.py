# -*- coding: utf-8 -*-
from flask import Flask, request, Response
from markupsafe import escape

app = Flask(__name__)

# Extension's test suffix - used to detect probes vs normal browsing
TEST_MARKER = "xptotest"
# Concat payloads have ~10 bypass strings joined (80+ chars after marker)
CONCAT_LENGTH_THRESHOLD = 30


# =============================================================================
# Helper Functions
# =============================================================================

def filter_unsafe(val):
    """Aggressively sanitize all dangerous chars (simulates a WAF/filter)."""
    temp = val.replace(u'\\', u'&#92;')
    temp = temp.replace(u'"', u'&quot;')
    temp = temp.replace(u'<', u'&lt;')
    temp = temp.replace(u'>', u'&gt;')
    # Unicode quote variants
    temp = temp.replace(u'\uff02', u'[FWDQ]')
    temp = temp.replace(u'\u02ba', u'[MDP]')
    temp = temp.replace(u'\u301e', u'[RDP]')
    temp = temp.replace(u'\u201e', u'[DL9Q]')
    temp = temp.replace(u'\u201c', u'[LDQ]')
    # Unicode angle bracket variants
    temp = temp.replace(u'\uff1c', u'[FWAB]')
    temp = temp.replace(u'\u27e8', u'[MLAB]')
    temp = temp.replace(u'\u2329', u'[LPAB]')
    temp = temp.replace(u'\u3008', u'[CJKAB]')
    return temp


def raw_query_has_bypass(param_name_bytes, bypass_raw_bytes):
    """
    Check if the raw query string contains the bypass bytes immediately after
    the test marker for the given parameter.
    Looks for: param_name=...xptotest{bypass_bytes}
    """
    qs = request.query_string
    marker_bytes = TEST_MARKER.encode('ascii')

    # Find param= in raw query (handle first param and subsequent params)
    search_prefix = param_name_bytes + b'='
    idx = qs.find(search_prefix)
    if idx == -1:
        return False
    if idx > 0 and qs[idx - 1:idx] != b'&':
        # Not at start and not preceded by & - might be substring of another param
        alt_idx = qs.find(b'&' + search_prefix)
        if alt_idx == -1:
            return False
        idx = alt_idx + 1

    # Find the marker after param=
    param_val_start = idx + len(search_prefix)
    marker_idx = qs.find(marker_bytes, param_val_start)
    if marker_idx == -1:
        return False

    # Check if bypass bytes appear immediately after the marker
    after_marker_start = marker_idx + len(marker_bytes)
    return qs[after_marker_start:after_marker_start + len(bypass_raw_bytes)] == bypass_raw_bytes


def parse_probe(param_name):
    """
    Parse a probe request. Returns (reflection_value, after_marker, is_probe).
    - reflection_value: everything up to and including the marker (e.g., "testxptotest")
    - after_marker: the payload after the marker (e.g., '"' or '%22' decoded)
    - is_probe: True if the marker was found
    """
    val = request.args.get(param_name, '')
    marker_idx = val.find(TEST_MARKER)
    if marker_idx == -1:
        return val, '', False
    reflection_value = val[:marker_idx + len(TEST_MARKER)]
    after_marker = val[marker_idx + len(TEST_MARKER):]
    return reflection_value, after_marker, True


def make_dq_response(reflected_value, status=200):
    """DQ context: value="REFLECTED" — char after reflection is always " """
    html = '<!DOCTYPE html><html><body>'
    html += '<input type="text" value="{}">'.format(reflected_value)
    html += '</body></html>'
    return Response(html, status=status, mimetype='text/html')


def make_tag_response(reflected_value, status=200):
    """TAG context (followed_by_lt=True): <div>REFLECTED</div> — char after reflection is < """
    html = '<!DOCTYPE html><html><body>'
    html += '<div>{}</div>'.format(reflected_value)
    html += '</body></html>'
    return Response(html, status=status, mimetype='text/html')


# =============================================================================
# Factory Functions for Bypass Routes
# =============================================================================

def create_bypass_route(context, suffix, bypass_raw_bytes, expected_char, is_concat):
    """
    Generate a bypass test route.

    context: 'dq' or 'tag'
    suffix: route name suffix (e.g., 'double_url_encoded')
    bypass_raw_bytes: raw bytes to look for in query string (e.g., b'%2522')
    expected_char: char to reflect when bypass detected (e.g., u'"' or u'\uff02')
    is_concat: if True, return 400 for concat-length payloads (triggers anomaly fallback)
    """
    route_name = '{}_bypass_{}'.format(context, suffix)
    make_response = make_dq_response if context == 'dq' else make_tag_response
    param_name = 'q'
    param_name_bytes = b'q'

    @app.route('/' + route_name, endpoint=route_name)
    def handler():
        reflection_value, after_marker, is_probe = parse_probe(param_name)

        if not is_probe:
            # Normal browsing - reflect filtered value in context
            return make_response(filter_unsafe(reflection_value))

        if not after_marker:
            # Reflection check - reflect the marker value in context
            return make_response(reflection_value)

        # For concat bypass routes: long payloads get anomalous 400 response
        # This forces the extension to fall back to individual testing
        if is_concat and len(after_marker) > CONCAT_LENGTH_THRESHOLD:
            return make_response(filter_unsafe(reflection_value + after_marker), status=400)

        # Check for the specific bypass in raw query bytes
        if raw_query_has_bypass(param_name_bytes, bypass_raw_bytes):
            return make_response(reflection_value + expected_char)

        # Block everything else
        return make_response(filter_unsafe(reflection_value + after_marker))

    return handler


# =============================================================================
# Index Page
# =============================================================================

@app.route('/')
def index():
    html = """<!DOCTYPE html>
<html><head><title>AutoRXSS Test App</title></head><body>
<h1>AutoRXSS Test App - Full Coverage</h1>

<h2>Direct Injection</h2>
<ul>
  <li><a href="/dq_direct?q=test">/dq_direct?q=test</a> — DQ context, direct &quot; injection</li>
  <li><a href="/tag_direct?q=test">/tag_direct?q=test</a> — TAG context, direct &lt; injection</li>
</ul>

<h2>DQ Concat Bypass Routes (return 400 for concat → anomaly fallback)</h2>
<ul>
  <li><a href="/dq_bypass_url_encoded?q=test">/dq_bypass_url_encoded</a> — %22</li>
  <li><a href="/dq_bypass_double_url_encoded?q=test">/dq_bypass_double_url_encoded</a> — %2522</li>
  <li><a href="/dq_bypass_unicode?q=test">/dq_bypass_unicode</a> — \\u0022</li>
  <li><a href="/dq_bypass_unicode_codepoint?q=test">/dq_bypass_unicode_codepoint</a> — \\u{22}</li>
  <li><a href="/dq_bypass_backslash_unicode_lc?q=test">/dq_bypass_backslash_unicode_lc</a> — %5cu0022</li>
  <li><a href="/dq_bypass_backslash_codepoint_lc?q=test">/dq_bypass_backslash_codepoint_lc</a> — %5cu{22}</li>
  <li><a href="/dq_bypass_html_entity?q=test">/dq_bypass_html_entity</a> — %26quot;</li>
  <li><a href="/dq_bypass_overlong1?q=test">/dq_bypass_overlong1</a> — %C0%A2</li>
  <li><a href="/dq_bypass_overlong2?q=test">/dq_bypass_overlong2</a> — %E0%80%A2</li>
  <li><a href="/dq_bypass_overlong3?q=test">/dq_bypass_overlong3</a> — %F0%80%80%A2</li>
</ul>

<h2>DQ Individual Bypass Routes (Unicode/full-width, always tested individually)</h2>
<ul>
  <li><a href="/dq_bypass_full_width?q=test">/dq_bypass_full_width</a> — U+FF02 ＂</li>
  <li><a href="/dq_bypass_modifier_prime?q=test">/dq_bypass_modifier_prime</a> — U+02BA ʺ</li>
  <li><a href="/dq_bypass_reversed_prime?q=test">/dq_bypass_reversed_prime</a> — U+301E 〞</li>
  <li><a href="/dq_bypass_low9_quote?q=test">/dq_bypass_low9_quote</a> — U+201E „</li>
  <li><a href="/dq_bypass_left_dq?q=test">/dq_bypass_left_dq</a> — U+201C \u201c</li>
</ul>

<h2>TAG Concat Bypass Routes (return 400 for concat → anomaly fallback)</h2>
<ul>
  <li><a href="/tag_bypass_url_encoded?q=test">/tag_bypass_url_encoded</a> — %3C</li>
  <li><a href="/tag_bypass_double_url_encoded?q=test">/tag_bypass_double_url_encoded</a> — %253C</li>
  <li><a href="/tag_bypass_unicode?q=test">/tag_bypass_unicode</a> — \\u003C</li>
  <li><a href="/tag_bypass_unicode_codepoint?q=test">/tag_bypass_unicode_codepoint</a> — \\u{3C}</li>
  <li><a href="/tag_bypass_backslash_unicode_lc?q=test">/tag_bypass_backslash_unicode_lc</a> — %5cu003C</li>
  <li><a href="/tag_bypass_backslash_codepoint_lc?q=test">/tag_bypass_backslash_codepoint_lc</a> — %5cu{3C}</li>
  <li><a href="/tag_bypass_html_entity?q=test">/tag_bypass_html_entity</a> — %26lt;</li>
  <li><a href="/tag_bypass_overlong1?q=test">/tag_bypass_overlong1</a> — %C0%BC</li>
  <li><a href="/tag_bypass_overlong2?q=test">/tag_bypass_overlong2</a> — %E0%80%BC</li>
  <li><a href="/tag_bypass_overlong3?q=test">/tag_bypass_overlong3</a> — %F0%80%80%BC</li>
</ul>

<h2>TAG Individual Bypass Routes (Unicode/full-width, always tested individually)</h2>
<ul>
  <li><a href="/tag_bypass_full_width?q=test">/tag_bypass_full_width</a> — U+FF1C ＜</li>
  <li><a href="/tag_bypass_math_angle?q=test">/tag_bypass_math_angle</a> — U+27E8 ⟨</li>
  <li><a href="/tag_bypass_left_point?q=test">/tag_bypass_left_point</a> — U+2329 〈</li>
  <li><a href="/tag_bypass_cjk_angle?q=test">/tag_bypass_cjk_angle</a> — U+3008 〈</li>
</ul>

<h2>Concat Screening Test Routes</h2>
<ul>
  <li><a href="/dq_concat_positive?q=test">/dq_concat_positive</a> — DQ, no filter → concat regex match → fallback → found</li>
  <li><a href="/tag_concat_positive?q=test">/tag_concat_positive</a> — TAG, no filter → concat regex match → fallback → found</li>
  <li><a href="/dq_concat_negative?q=test">/dq_concat_negative</a> — DQ, total filter → concat no match → skip all</li>
  <li><a href="/tag_concat_negative?q=test">/tag_concat_negative</a> — TAG, total filter → concat no match → skip all</li>
</ul>

<h2>URL Path Segment Routes</h2>
<ul>
  <li><a href="/pathtest/myvalue">/pathtest/myvalue</a> — TAG context, direct &lt; injection via path segment</li>
  <li><a href="/pathtest_dq/myvalue">/pathtest_dq/myvalue</a> — DQ context, direct &quot; injection via path segment</li>
</ul>

<h2>Negative Test Routes (should NOT produce findings)</h2>
<ul>
  <li><a href="/safe?q=test">/safe?q=test</a> — Properly HTML-escaped output</li>
  <li><a href="/no_reflection?q=test">/no_reflection?q=test</a> — Param not reflected</li>
  <li><a href="/not_html?q=test">/not_html?q=test</a> — text/plain response (not HTML)</li>
  <li><a href="/json_response?q=test">/json_response?q=test</a> — application/json Content-Type</li>
  <li>POST to /post_only — POST-only endpoint (extension only scans GET)</li>
</ul>

</body></html>"""
    return Response(html, mimetype='text/html')


# =============================================================================
# Direct Injection Routes
# =============================================================================

@app.route('/dq_direct')
def dq_direct():
    """DQ context, no filter — direct " injection works immediately."""
    reflection_value, after_marker, is_probe = parse_probe('q')
    if not is_probe:
        return make_dq_response(filter_unsafe(reflection_value))
    # Reflect everything raw (no filter) — direct injection succeeds
    val = request.args.get('q', '')
    return make_dq_response(val)


@app.route('/tag_direct')
def tag_direct():
    """TAG context (followed_by_lt=True), no filter — direct < injection works."""
    reflection_value, after_marker, is_probe = parse_probe('q')
    if not is_probe:
        return make_tag_response(filter_unsafe(reflection_value))
    val = request.args.get('q', '')
    return make_tag_response(val)


# =============================================================================
# DQ Concat Bypass Routes (is_concat=True → 400 for concat payloads)
# =============================================================================

create_bypass_route('dq', 'url_encoded',            b'%22',             u'"',      True)
create_bypass_route('dq', 'double_url_encoded',      b'%2522',           u'"',      True)
create_bypass_route('dq', 'unicode',                 b'%5Cu0022',        u'"',      True)
create_bypass_route('dq', 'unicode_codepoint',       b'%5Cu%7B22%7D',    u'"',      True)
create_bypass_route('dq', 'backslash_unicode_lc',    b'%5cu0022',        u'"',      True)
create_bypass_route('dq', 'backslash_codepoint_lc',  b'%5cu%7B22%7D',    u'"',      True)
create_bypass_route('dq', 'html_entity',             b'%26quot%3B',      u'"',      True)
create_bypass_route('dq', 'overlong1',               b'%C0%A2',          u'"',      True)
create_bypass_route('dq', 'overlong2',               b'%E0%80%A2',       u'"',      True)
create_bypass_route('dq', 'overlong3',               b'%F0%80%80%A2',    u'"',      True)


# =============================================================================
# DQ Individual Bypass Routes (is_concat=False — always tested one-at-a-time)
# =============================================================================

create_bypass_route('dq', 'full_width',       b'%EF%BC%82',  u'\uff02',  False)
create_bypass_route('dq', 'modifier_prime',   b'%CA%BA',     u'\u02ba',  False)
create_bypass_route('dq', 'reversed_prime',   b'%E3%80%9E',  u'\u301e',  False)
create_bypass_route('dq', 'low9_quote',       b'%E2%80%9E',  u'\u201e',  False)
create_bypass_route('dq', 'left_dq',          b'%E2%80%9C',  u'\u201c',  False)


# =============================================================================
# TAG Concat Bypass Routes (is_concat=True → 400 for concat payloads)
# =============================================================================

create_bypass_route('tag', 'url_encoded',            b'%3C',             u'<',      True)
create_bypass_route('tag', 'double_url_encoded',      b'%253C',           u'<',      True)
create_bypass_route('tag', 'unicode',                 b'%5Cu003C',        u'<',      True)
create_bypass_route('tag', 'unicode_codepoint',       b'%5Cu%7B3C%7D',    u'<',      True)
create_bypass_route('tag', 'backslash_unicode_lc',    b'%5cu003C',        u'<',      True)
create_bypass_route('tag', 'backslash_codepoint_lc',  b'%5cu%7B3C%7D',    u'<',      True)
create_bypass_route('tag', 'html_entity',             b'%26lt%3B',        u'<',      True)
create_bypass_route('tag', 'overlong1',               b'%C0%BC',          u'<',      True)
create_bypass_route('tag', 'overlong2',               b'%E0%80%BC',       u'<',      True)
create_bypass_route('tag', 'overlong3',               b'%F0%80%80%BC',    u'<',      True)


# =============================================================================
# TAG Individual Bypass Routes (is_concat=False)
# =============================================================================

create_bypass_route('tag', 'full_width',    b'%EF%BC%9C',  u'\uff1c',  False)
create_bypass_route('tag', 'math_angle',    b'%E2%9F%A8',  u'\u27e8',  False)
create_bypass_route('tag', 'left_point',    b'%E2%8C%A9',  u'\u2329',  False)
create_bypass_route('tag', 'cjk_angle',     b'%E3%80%88',  u'\u3008',  False)


# =============================================================================
# Concat Screening Test Routes
# =============================================================================

@app.route('/dq_concat_positive')
def dq_concat_positive():
    """
    DQ context, NO filter on " — simulates a server with no encoding filter.
    Direct injection: extension sends testxptotest" → Burp sends %22 → Flask decodes to "
    → reflected raw → direct injection succeeds (extension finds it before reaching bypasses).

    But if direct injection is somehow missed and concat is tested:
    Concat payload includes %22 which decodes to " → reflected in response →
    concat regex matches → fallback to individual → %22 individual confirms.

    Primary purpose: tests the concat regex match → fallback code path.
    In practice, direct injection will be found first.
    """
    reflection_value, after_marker, is_probe = parse_probe('q')
    if not is_probe:
        return make_dq_response(filter_unsafe(reflection_value))
    val = request.args.get('q', '')
    return make_dq_response(val)


@app.route('/tag_concat_positive')
def tag_concat_positive():
    """TAG context, NO filter on < — same as dq_concat_positive but for TAG."""
    reflection_value, after_marker, is_probe = parse_probe('q')
    if not is_probe:
        return make_tag_response(filter_unsafe(reflection_value))
    val = request.args.get('q', '')
    return make_tag_response(val)


@app.route('/dq_concat_negative')
def dq_concat_negative():
    """
    DQ context, TOTAL filter — all bypass chars sanitized.
    Concat screening: no " in response → regex no match → extension skips all concat bypasses.
    Individual unicode bypasses: also filtered → no findings.
    Expected: extension reports nothing (tests the "skip" optimization path).
    """
    reflection_value, after_marker, is_probe = parse_probe('q')
    if not is_probe:
        return make_dq_response(filter_unsafe(reflection_value))
    if not after_marker:
        return make_dq_response(reflection_value)
    # Filter everything
    val = request.args.get('q', '')
    return make_dq_response(filter_unsafe(val))


@app.route('/tag_concat_negative')
def tag_concat_negative():
    """TAG context, TOTAL filter — same as dq_concat_negative but for TAG."""
    reflection_value, after_marker, is_probe = parse_probe('q')
    if not is_probe:
        return make_tag_response(filter_unsafe(reflection_value))
    if not after_marker:
        return make_tag_response(reflection_value)
    val = request.args.get('q', '')
    return make_tag_response(filter_unsafe(val))


# =============================================================================
# URL Path Segment Routes
# =============================================================================

@app.route('/pathtest/<segment>')
def pathtest_tag(segment):
    """
    TAG context (followed_by_lt=True) — reflects URL path segment raw.
    Direct < injection works via path segment.
    """
    return make_tag_response(segment)


@app.route('/pathtest_dq/<segment>')
def pathtest_dq(segment):
    """
    DQ context (followed_by_dq=True) — reflects URL path segment raw.
    Direct " injection works via path segment.
    """
    return make_dq_response(segment)


# =============================================================================
# Negative Test Routes (extension should NOT report findings)
# =============================================================================

@app.route('/safe')
def safe():
    """Properly HTML-escaped output — no XSS possible."""
    val = request.args.get('q', 'none')
    safe_val = escape(val)
    html = '<!DOCTYPE html><html><body>'
    html += '<span data-id="{}">Value: {}</span>'.format(safe_val, safe_val)
    html += '</body></html>'
    return Response(html, mimetype='text/html')


@app.route('/no_reflection')
def no_reflection():
    """Parameter received but not reflected in response."""
    ignored = request.args.get('q', '')
    html = '<!DOCTYPE html><html><body>'
    html += '<h1>Static Content</h1><p>Parameter was received but not used.</p>'
    html += '</body></html>'
    return Response(html, mimetype='text/html')


@app.route('/not_html')
def not_html():
    """text/plain response — extension skips non-HTML MIME types."""
    val = request.args.get('q', 'no data')
    return Response("Response Data: {}".format(val), mimetype='text/plain')


@app.route('/json_response')
def json_response():
    """application/json Content-Type — extension skips JSON responses."""
    val = request.args.get('q', 'none')
    import json
    return Response(
        json.dumps({"query": val, "results": []}),
        mimetype='application/json'
    )


@app.route('/post_only', methods=['POST'])
def post_only():
    """POST-only endpoint — extension only scans GET requests."""
    name = request.form.get('name', 'default')
    html = '<!DOCTYPE html><html><body>'
    html += '<h1>POST Result</h1><p>Name: {}</p>'.format(escape(name))
    html += '</body></html>'
    return Response(html, mimetype='text/html')


# =============================================================================
# Run
# =============================================================================

if __name__ == '__main__':
    print("Starting Flask test server on http://127.0.0.1:8888")
    print("Routes registered: {}".format(len([r for r in app.url_map.iter_rules()])))
    app.run(debug=True, host='127.0.0.1', port=8888)
