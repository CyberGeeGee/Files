# -*- coding: utf-8 -*-
# Burp Extension: AutoSSRF
# Author: Your Name / AI Assistant
# Version: 1.3.29 (Add IP to Issue Title, Detect Cloudflare)

# Burp Imports
from burp import IBurpExtender, IHttpListener, IScanIssue, IExtensionHelpers
from burp import IHttpRequestResponse, IHttpService, IParameter
from java.net import URL
from java.io import PrintWriter
from java.util import ArrayList, List, HashSet

# Python Imports
import sys, threading, time, traceback, re
from urlparse import urlparse, urlunparse
from collections import namedtuple
import cgi
from jarray import array # Use jarray for creating Java arrays
import socket, struct # For IP address checking

# --- Configuration ---
EXTENSION_NAME = "AutoSSRF"; COLLABORATOR_POLL_INTERVAL = 20
# Severity and Confidence constants are now more dynamic, defined in _report_issue
# These serve as fallbacks or defaults
HEADER_ISSUE_CONFIDENCE = "Firm"; PARAM_INTERACTION_CONFIDENCE = "Firm"
INTERACTION_TIMEOUT = 300; PATH_NUMBER_PLACEHOLDER = "{number}"
URL_PATH_REGEX = re.compile(r'(?:https?://[\w\-.]+|[\w\-.]+\.(?:com|net|org|io|dev|sh|tech|app)\b|^/[\w./-]+)', re.IGNORECASE)
IGNORED_PARAM_NAMES_CONFIG = {"aspxerrorpath"}
IGNORED_ROOT_DOMAINS_CONFIG = { "google.com", "gdsburp.com" }

# <<< ADDED: Cloudflare IPv4 CIDR Ranges >>>
# Source: https://www.cloudflare.com/ips/
CLOUDFLARE_IPV4_RANGES = [
    "173.245.48.0/20", "103.21.244.0/22", "103.22.200.0/22", "103.31.4.0/22",
    "141.101.64.0/18", "108.162.192.0/18", "190.93.240.0/20", "188.114.96.0/20",
    "197.234.240.0/22", "198.41.128.0/17", "162.158.0.0/15", "104.16.0.0/13",
    "104.24.0.0/14", "172.64.0.0/13", "131.0.72.0/22"
]

# Test Type Constants
TEST_HOST_HEADER = "Host Header"; TEST_XFF_HEADER = "Multi-Header Test"
TEST_PARAM_DOMAIN_SWAP = "URL Parameter Domain Swap"; TEST_PARAM_SUBDOMAIN_APPEND = "URL Parameter Subdomain Append"
TEST_PARAM_PATH_PREPEND = "URL Parameter Path Prepend"; TEST_PATH_SEGMENT_INJECT = "Path Segment Inject"
# Header Injection Config
MULTI_HEADERS_TO_INJECT = [ "X-Forwarded-For", "X-Real-IP", "True-Client-IP", "Forwarded", "X-Forwarded-Host", "X-Client-IP", "Client-IP", "CF-Connecting-IP", "X-Original-URL", "X-Rewrite-URL", "Referer", "X-WAP-Profile", "X-Forwarded-Scheme",]
HEADERS_NEEDING_URL_FORMAT = {"x-original-url", "x-rewrite-url", "referer", "x-wap-profile"}
# Interaction Tracking
InteractionInfo = namedtuple('InteractionInfo', ['original_request_response', 'test_request_response', 'test_type', 'collaborator_payload', 'timestamp', 'parameter_name', 'header_name'])

# --- CustomScanIssue Class (Defined BEFORE BurpExtender) ---
class CustomScanIssue(IScanIssue):
    # Adhering to formatting rule
    def __init__(self, httpService, url, httpMessages, name, detail, remediation, severity, confidence):
        self._httpService = httpService
        self._url = url
        self._httpMessages = list(httpMessages) if httpMessages is not None else []
        self._name = name
        self._detail = detail
        self._remediation = remediation
        self._severity = severity
        self._confidence = confidence
    # --- Interface Methods ---
    def getUrl(self):
        return self._url
    def getIssueName(self):
        return self._name
    def getIssueType(self):
        return 0x08000101
    def getSeverity(self):
        return self._severity
    def getConfidence(self):
        return self._confidence
    def getIssueBackground(self):
        return None
    def getRemediationBackground(self):
        return None
    def getIssueDetail(self):
        return self._detail
    def getRemediationDetail(self):
        return self._remediation
    def getHttpMessages(self):
        return self._httpMessages
    def getHttpService(self):
        return self._httpService

# --- BurpExtender Class ---
class BurpExtender(IBurpExtender, IHttpListener):

    # Adhering to formatting rule
    def registerExtenderCallbacks(self, callbacks):
        self._callbacks = callbacks
        self._helpers = callbacks.getHelpers()
        self.stdout = PrintWriter(callbacks.getStdout(), True)
        self.stderr = PrintWriter(callbacks.getStderr(), True)
        callbacks.setExtensionName(EXTENSION_NAME)
        self._processed_header_targets = HashSet()
        self._processed_header_targets_lock = threading.Lock()
        self._processed_param_targets = HashSet()
        self._processed_param_targets_lock = threading.Lock()
        self._processed_path_segment_targets = HashSet()
        self._processed_path_segment_targets_lock = threading.Lock()
        self._interaction_map = {}
        self._interaction_map_lock = threading.Lock()
        self.IGNORED_PARAM_NAMES = {name.lower() for name in IGNORED_PARAM_NAMES_CONFIG}
        self.IGNORED_ROOT_DOMAINS = {domain.lower() for domain in IGNORED_ROOT_DOMAINS_CONFIG}
        try:
            self._collaborator_context = callbacks.createBurpCollaboratorClientContext()
            self.stdout.println("Successfully created Burp Collaborator context.")
        except Exception as e:
            self.stderr.println("!!! Error creating Burp Collaborator context...")
            self.stderr.println(traceback.format_exc())
            callbacks.unloadExtension()
            return
        self._running = True
        self._poll_thread = threading.Thread(target=self._poll_collaborator)
        self._poll_thread.daemon = True
        self._poll_thread.start()
        self._cleanup_thread = threading.Thread(target=self._cleanup_interactions)
        self._cleanup_thread.daemon = True
        self._cleanup_thread.start()
        callbacks.registerHttpListener(self)
        self.stdout.println("=" * 30)
        self.stdout.println("{} Extension Loaded (v1.3.29)".format(EXTENSION_NAME)) # Version updated
        self.stdout.println("Author: Your Name / AI Assistant")
        self.stdout.println("Version: 1.3.29") # Version updated
        self.stdout.println("Processing Tools: Proxy, Spider")
        self.stdout.println("** NOTE: Parameter values highlighted in reported issues **")
        self.stdout.println("Header Scan Trigger: Unique host:port:normalized_path")
        self.stdout.println(" -> Test 1: {}".format(TEST_HOST_HEADER))
        self.stdout.println(" -> Test 2: {} ({} headers, unique payload/header)".format(TEST_XFF_HEADER, len(MULTI_HEADERS_TO_INJECT)))
        self.stdout.println("Parameter Scan Trigger: URL/Path pattern in param value on unique host:port:normalized_path:param_name")
        self.stdout.println(" -> Tests: {}, {}, {}".format(TEST_PARAM_DOMAIN_SWAP, TEST_PARAM_SUBDOMAIN_APPEND, TEST_PARAM_PATH_PREPEND))
        self.stdout.println("Path Segment Scan Trigger: Unique host:port:first_path_segment (GET only)")
        self.stdout.println(" -> Test: {} (root inject + second-segment inject)".format(TEST_PATH_SEGMENT_INJECT))
        self.stdout.println("Polling Collaborator every {} seconds.".format(COLLABORATOR_POLL_INTERVAL))
        self.stdout.println("Ignoring parameters: {}".format(", ".join(sorted(list(self.IGNORED_PARAM_NAMES))) if self.IGNORED_PARAM_NAMES else "None"))
        self.stdout.println("Ignoring root domains: {}".format(", ".join(sorted(list(self.IGNORED_ROOT_DOMAINS))) if self.IGNORED_ROOT_DOMAINS else "None"))
        self.stdout.println("=" * 30)

    # Adhering to formatting rule
    def extensionUnloaded(self):
        self.stdout.println("{} unloading...".format(EXTENSION_NAME))
        self._running = False
        self.stdout.println("{} unloaded.".format(EXTENSION_NAME))

    # Adhering to formatting rule
    def _normalize_path(self, path):
        if not path:
            return "/"
        segments = [segment for segment in path.split('/') if segment]
        normalized_segments = [PATH_NUMBER_PLACEHOLDER if segment.isdigit() else segment for segment in segments]
        return "/" + "/".join(normalized_segments)

    # Adhering to formatting rule
    def _get_root_domain(self, hostname):
        if not hostname:
            return None
        parts = hostname.lower().split('.')
        if len(parts) >= 2:
            root_domain = parts[-2] + '.' + parts[-1]
            return root_domain
        elif len(parts) == 1:
             return parts[0]
        else:
            return None

    # <<< ADDED: Helper function to check if IP is in Cloudflare CIDR ranges >>>
    def _is_cloudflare_ip(self, ip_string):
        """Checks if a given IPv4 string is within Cloudflare's published ranges."""
        if not ip_string:
            return False
        try:
            # Convert the input IP string to a long integer
            ip_addr = struct.unpack('!L', socket.inet_aton(ip_string))[0]
            # Check against each CIDR range
            for cidr in CLOUDFLARE_IPV4_RANGES:
                net_str, bits_str = cidr.split('/')
                net_addr = struct.unpack('!L', socket.inet_aton(net_str))[0]
                mask = (0xFFFFFFFF << (32 - int(bits_str))) & 0xFFFFFFFF
                # Check if the masked IP matches the network address
                if (ip_addr & mask) == (net_addr & mask):
                    return True
        except (socket.error, ValueError):
            # Handle cases where ip_string is not a valid IPv4 address
            return False
        return False


    # Adhering to formatting rule
    def processHttpMessage(self, toolFlag, messageIsRequest, messageInfo):
        allowed_tools = {self._callbacks.TOOL_PROXY, self._callbacks.TOOL_SPIDER}
        if messageIsRequest:
            return
        if not messageInfo.getResponse():
            return
        if toolFlag not in allowed_tools:
            return

        try:
            http_service = messageInfo.getHttpService()
            host = http_service.getHost()

            # Root Domain Check
            root_domain = self._get_root_domain(host)
            if root_domain and root_domain in self.IGNORED_ROOT_DOMAINS:
                # self.stdout.println("[Skipping] Host ({}) belongs to ignored root domain: {}".format(host, root_domain))
                return

            port = http_service.getPort()
            protocol = http_service.getProtocol()
            target_url_for_scope = URL(protocol, host, port, "/")
            # Scope Check
            if not self._callbacks.isInScope(target_url_for_scope):
                return

            request_info = self._helpers.analyzeRequest(messageInfo)
            url = request_info.getUrl()
            path = url.getPath()
            normalized_path = self._normalize_path(path)
            base_key_part = "{}:{}:{}".format(host, port, normalized_path)

            # --- Header Scan Logic ---
            header_target_key = base_key_part
            should_process_header = False
            with self._processed_header_targets_lock:
                if header_target_key not in self._processed_header_targets:
                    self._processed_header_targets.add(header_target_key)
                    should_process_header = True
            if should_process_header:
                 threading.Thread(target=self._run_header_ssrf_test, args=(messageInfo, TEST_HOST_HEADER)).start()
                 threading.Thread(target=self._run_header_ssrf_test, args=(messageInfo, TEST_XFF_HEADER)).start()
            # else:
            #    self.stdout.println("[Skipping] Already processed header target: {}".format(header_target_key))

            # --- Path Segment Scan Logic (GET only) ---
            http_method = request_info.getMethod()
            if http_method and http_method.upper() == "GET":
                path_segments = [s for s in path.split('/') if s]
                first_segment = path_segments[0] if path_segments else None
                per_segment_key = "{}:{}:{}".format(host, port, first_segment or "")
                root_inject_key = "{}:{}:__root__".format(host, port)
                should_process_path_seg = False
                should_do_root = False
                with self._processed_path_segment_targets_lock:
                    if per_segment_key not in self._processed_path_segment_targets:
                        self._processed_path_segment_targets.add(per_segment_key)
                        should_process_path_seg = True
                    if root_inject_key not in self._processed_path_segment_targets:
                        self._processed_path_segment_targets.add(root_inject_key)
                        should_do_root = True
                if should_process_path_seg or should_do_root:
                    threading.Thread(
                        target=self._run_path_segment_ssrf_test,
                        args=(messageInfo, first_segment, should_do_root)
                    ).start()

            # --- Parameter Scan Logic ---
            parameters = request_info.getParameters() or []
            if not parameters:
                 return

            for param in parameters:
                if param.getType() == IParameter.PARAM_URL:
                    try:
                        param_name = param.getName()
                        if param_name.lower() in self.IGNORED_PARAM_NAMES:
                            # self.stdout.println("[Skipping] Ignored parameter name: {}".format(param_name))
                            continue
                        decoded_value = self._helpers.urlDecode(param.getValue())
                        if not decoded_value:
                            continue
                        match = URL_PATH_REGEX.search(decoded_value)
                        if not match:
                            continue

                        param_target_key = (base_key_part, param_name)
                        should_process_param = False
                        with self._processed_param_targets_lock:
                            if param_target_key not in self._processed_param_targets:
                                self._processed_param_targets.add(param_target_key)
                                should_process_param = True

                        if should_process_param:
                            url_or_path_in_value = match.group(0)
                            # Informational issue reporting is removed
                            is_path_only = url_or_path_in_value.startswith('/') and not urlparse(url_or_path_in_value).hostname
                            has_hostname = urlparse(url_or_path_in_value).hostname or ('.' in url_or_path_in_value.split('/')[0] and not url_or_path_in_value.startswith('/'))
                            if has_hostname and not is_path_only:
                                threading.Thread(target=self._run_url_param_test, args=(messageInfo, param, TEST_PARAM_DOMAIN_SWAP, url_or_path_in_value)).start()
                                threading.Thread(target=self._run_url_param_test, args=(messageInfo, param, TEST_PARAM_SUBDOMAIN_APPEND, url_or_path_in_value)).start()
                            elif is_path_only:
                                threading.Thread(target=self._run_url_param_test, args=(messageInfo, param, TEST_PARAM_PATH_PREPEND, url_or_path_in_value)).start()
                            else: # Fallback
                                threading.Thread(target=self._run_url_param_test, args=(messageInfo, param, TEST_PARAM_DOMAIN_SWAP, url_or_path_in_value)).start()
                                threading.Thread(target=self._run_url_param_test, args=(messageInfo, param, TEST_PARAM_SUBDOMAIN_APPEND, url_or_path_in_value)).start()
                        # else:
                        #    self.stdout.println("[Skipping] Already processed param target: {}".format(param_target_key))

                    except Exception as e_param:
                        p_name = param.getName() if 'param_name' in locals() else "[UNKNOWN]"
                        self.stderr.println("!!! Error processing parameter '{}': {}".format(p_name, e_param))
                        # self.stderr.println(traceback.format_exc())
        except Exception as e_main:
            self.stderr.println("!!! Error in processHttpMessage for tool {}: {}".format(toolFlag, messageInfo.getHttpService().getHost()));
            self.stderr.println(traceback.format_exc())

    # Adhering to formatting rule
    def _run_header_ssrf_test(self, original_message_info, test_type):
        start_time = time.time()
        try:
            original_request = original_message_info.getRequest()
            request_info = self._helpers.analyzeRequest(original_message_info)
            original_headers = list(request_info.getHeaders())
            request_body_bytes = original_request[request_info.getBodyOffset():]
            modified_headers = []
            payload_map = {}
            base_interaction_info = None

            if test_type == TEST_HOST_HEADER:
                collaborator_payload = self._collaborator_context.generatePayload(True)
                if not collaborator_payload:
                    self.stderr.println("!!! Error generating payload for Host header test")
                    return
                payload_map[collaborator_payload] = "Host"
                new_host_header_str = "Host: " + collaborator_payload
                host_header_index = -1
                current_index = 0
                for header in original_headers:
                    if ':' in header:
                        name = header.split(":", 1)[0]
                        if name.strip().lower() == "host":
                            host_header_index = current_index
                            break
                    current_index += 1
                if host_header_index != -1:
                    modified_headers = list(original_headers)
                    modified_headers[host_header_index] = new_host_header_str
                else:
                    modified_headers = list(original_headers)
                    if len(modified_headers) > 0:
                        modified_headers.insert(1, new_host_header_str)
                    else:
                        modified_headers.append(new_host_header_str)

            elif test_type == TEST_XFF_HEADER:
                final_injection_values = {}
                temp_payload_map = {}
                original_headers_map_lower = {}
                for header in original_headers:
                    try:
                        name, val = header.split(":", 1)
                        original_headers_map_lower[name.strip().lower()] = val.strip()
                    except ValueError:
                        continue

                for header_name_to_inject in MULTI_HEADERS_TO_INJECT:
                    header_lower = header_name_to_inject.lower()
                    raw_payload = self._collaborator_context.generatePayload(True)
                    if not raw_payload:
                        self.stderr.println("!!! Failed to generate payload for header '{}'. Skipping.".format(header_name_to_inject))
                        continue
                    temp_payload_map[header_lower] = raw_payload
                    payload_map[raw_payload] = header_name_to_inject
                    injection_value = raw_payload
                    if header_lower == "forwarded":
                        injection_value = 'for="{}"'.format(raw_payload)
                    elif header_lower in HEADERS_NEEDING_URL_FORMAT:
                        original_value_found = original_headers_map_lower.get(header_lower)
                        if original_value_found:
                            try:
                                parsed = urlparse(original_value_found)
                                if parsed.scheme and parsed.netloc:
                                    rebuilt_url = urlunparse((parsed.scheme, raw_payload, parsed.path, parsed.params, parsed.query, parsed.fragment))
                                    injection_value = rebuilt_url
                                else:
                                    injection_value = "http://{}/".format(raw_payload)
                            except Exception as parse_err:
                                self.stderr.println("!!! Error parsing original URL for '{}': {}. Using default.".format(header_name_to_inject, parse_err))
                                injection_value = "http://{}/".format(raw_payload)
                        else:
                            injection_value = "http://{}/".format(raw_payload)
                    final_injection_values[header_lower] = injection_value

                headers_processed_lower = set()
                for header in original_headers:
                    try:
                        header_name, header_value = header.split(':', 1)
                        header_name_lower = header_name.strip().lower()
                        if header_name_lower in final_injection_values:
                            modified_headers.append(header_name + ": " + final_injection_values[header_name_lower])
                            headers_processed_lower.add(header_name_lower)
                        else:
                            modified_headers.append(header)
                    except ValueError:
                         modified_headers.append(header)
                for header_name_to_inject in MULTI_HEADERS_TO_INJECT:
                    header_lower = header_name_to_inject.lower()
                    if header_lower not in headers_processed_lower and header_lower in final_injection_values:
                        modified_headers.append(header_name_to_inject + ": " + final_injection_values[header_lower])
            else:
                self.stderr.println("!!! Unknown header test type provided: {}".format(test_type))
                return

            modified_request_bytes = self._helpers.buildHttpMessage(modified_headers, request_body_bytes)
            test_request_response = self._callbacks.makeHttpRequest(original_message_info.getHttpService(), modified_request_bytes)

            if test_request_response:
                base_interaction_info = InteractionInfo(
                    original_request_response=original_message_info, test_request_response=test_request_response,
                    test_type=test_type, collaborator_payload=None, timestamp=start_time,
                    parameter_name=None, header_name=None
                )
                with self._interaction_map_lock:
                    for payload, header_name in payload_map.items():
                        specific_info = base_interaction_info._replace(collaborator_payload=payload, header_name=header_name)
                        self._interaction_map[payload] = specific_info
            else:
                self.stderr.println("!!! [{}] Failed to send modified request for header test".format(test_type))
        except Exception as e:
            self.stderr.println("!!! ERROR during header SSRF test ('{}'):".format(test_type))
            self.stderr.println(traceback.format_exc())

    # Adhering to formatting rule
    def _run_url_param_test(self, original_message_info, parameter, test_type, url_or_path_in_value):
        try:
            param_name = parameter.getName()
            collaborator_payload_full = self._collaborator_context.generatePayload(True)
            if not collaborator_payload_full:
                self.stderr.println("!!! Error generating payload for param '{}'".format(param_name))
                return

            original_param_value = parameter.getValue()
            decoded_original_value = self._helpers.urlDecode(original_param_value)
            target_url_str = url_or_path_in_value
            modified_url_str = None

            if test_type == TEST_PARAM_DOMAIN_SWAP or test_type == TEST_PARAM_SUBDOMAIN_APPEND:
                py_parsed = None
                original_host = None
                try:
                    parse_test_str = target_url_str
                    if not re.match(r"^[a-zA-Z]+://", parse_test_str) and "//" in parse_test_str:
                        parse_test_str = "http:" + parse_test_str
                    elif not re.match(r"^[a-zA-Z]+://", parse_test_str):
                        parse_test_str = 'http://' + parse_test_str
                    py_parsed = urlparse(parse_test_str)
                    if not py_parsed.hostname:
                        if '.' in target_url_str and '/' not in target_url_str and ':' not in target_url_str:
                            original_host = target_url_str
                            py_parsed = urlparse('http://' + target_url_str)
                        else:
                            return
                    else:
                        original_host = py_parsed.hostname
                except Exception as e_parse:
                    return
                if not original_host:
                    return

                new_host = None
                if test_type == TEST_PARAM_DOMAIN_SWAP:
                    new_host = collaborator_payload_full
                elif test_type == TEST_PARAM_SUBDOMAIN_APPEND:
                    new_host = "{}.{}".format(original_host, collaborator_payload_full)
                else:
                    return

                try:
                    scheme = py_parsed.scheme if py_parsed.scheme else ''
                    port = py_parsed.port
                    netloc = new_host
                    if port and port != -1 and port != 80 and port != 443:
                        netloc = "{}:{}".format(new_host, port)
                    path = py_parsed.path if py_parsed.path else ''
                    query = py_parsed.query if py_parsed.query else ''
                    fragment = py_parsed.fragment if py_parsed.fragment else ''
                    modified_url_str = urlunparse((scheme, netloc, path, '', query, fragment))
                    was_just_domain = not py_parsed.scheme and not py_parsed.path and not py_parsed.query and not py_parsed.fragment and original_host == target_url_str
                    if was_just_domain:
                        modified_url_str = new_host
                    elif not scheme and modified_url_str.startswith("//"):
                        modified_url_str = modified_url_str[2:]
                except Exception as e_rebuild:
                    self.stderr.println("!!! Error rebuilding URL for param '{}', test '{}': {}".format(param_name, test_type, e_rebuild))
                    return
            elif test_type == TEST_PARAM_PATH_PREPEND:
                 modified_url_str = "http://{}/{}".format(collaborator_payload_full, target_url_str.lstrip('/'))
            else:
                 return

            if modified_url_str is None:
                return

            modified_decoded_value = decoded_original_value.replace(target_url_str, modified_url_str, 1)
            modified_param_value_encoded = self._helpers.urlEncode(modified_decoded_value)
            modified_param = self._helpers.buildParameter(param_name, modified_param_value_encoded, parameter.getType())
            original_request_bytes = original_message_info.getRequest()
            modified_request_bytes = self._helpers.updateParameter(original_request_bytes, modified_param)
            test_request_response = self._callbacks.makeHttpRequest(original_message_info.getHttpService(), modified_request_bytes)

            if test_request_response:
                interaction_data = InteractionInfo(
                    original_request_response=original_message_info, test_request_response=test_request_response,
                    test_type=test_type, collaborator_payload=collaborator_payload_full,
                    timestamp=time.time(), parameter_name=param_name, header_name=None
                )
                with self._interaction_map_lock:
                    self._interaction_map[collaborator_payload_full] = interaction_data
            else:
                 self.stderr.println("!!! [{}] Failed to send modified request for param test '{}'".format(test_type, param_name))
        except Exception as e:
            p_name = parameter.getName() if parameter else "[UNKNOWN]"
            self.stderr.println("!!! ERROR during URL param SSRF test ('{}' on param '{}'):".format(test_type, p_name));
            self.stderr.println(traceback.format_exc())

    # Adhering to formatting rule
    def _run_path_segment_ssrf_test(self, original_message_info, first_segment, should_do_root):
        try:
            tests = []
            # Variant 1 — root inject: /http://{payload}
            # Only runs if caller determined this host:port hasn't had a root inject yet.
            if should_do_root:
                payload_root = self._collaborator_context.generatePayload(True)
                if payload_root:
                    injected_path_root = "/http://{}".format(payload_root)
                    tests.append((payload_root, injected_path_root, "Path[0]"))
            # Variant 2 — second-segment inject: /{first_segment}/http://{payload}
            # Runs whenever this method is called with a non-empty first_segment.
            if first_segment:
                payload_second = self._collaborator_context.generatePayload(True)
                if payload_second:
                    injected_path_second = "/{}/http://{}".format(first_segment, payload_second)
                    tests.append((payload_second, injected_path_second, "Path[1] after /{}".format(first_segment)))
            for (payload, injected_path, label) in tests:
                try:
                    original_request_bytes = original_message_info.getRequest()
                    request_info_local = self._helpers.analyzeRequest(original_message_info)
                    original_headers = list(request_info_local.getHeaders())
                    http_service = original_message_info.getHttpService()
                    # Extract original request line parts
                    # original_headers[0] == "GET /original/path HTTP/1.1"
                    request_line_parts = original_headers[0].split(' ')
                    method = request_line_parts[0] if len(request_line_parts) > 0 else "GET"
                    original_path_query = request_line_parts[1] if len(request_line_parts) > 1 else "/"
                    http_version = request_line_parts[2] if len(request_line_parts) > 2 else "HTTP/1.1"
                    # Preserve any query string from the original path
                    query_start = original_path_query.find('?')
                    query_string = original_path_query[query_start:] if query_start != -1 else ""
                    # Build new request line with injected path
                    new_request_line = "{} {}{} {}".format(method, injected_path, query_string, http_version)
                    # --- KEY FIX ---
                    # Manually assemble the full HTTP request as a raw string,
                    # then convert to bytes. This bypasses buildHttpMessage's
                    # internal validation which silently drops requests when the
                    # path contains "://" (treats them as malformed).
                    header_lines = [new_request_line] + original_headers[1:]
                    body_bytes = original_request_bytes[request_info_local.getBodyOffset():]
                    # Build headers string: each header line separated by CRLF,
                    # with a blank line between headers and body
                    headers_str = "\r\n".join(header_lines) + "\r\n\r\n"
                    headers_bytes = self._helpers.stringToBytes(headers_str)
                    # Concatenate header bytes + body bytes into final request
                    modified_request_bytes = headers_bytes + body_bytes
                    test_request_response = self._callbacks.makeHttpRequest(
                        http_service, modified_request_bytes
                    )
                    if test_request_response:
                        interaction_data = InteractionInfo(
                            original_request_response=original_message_info,
                            test_request_response=test_request_response,
                            test_type=TEST_PATH_SEGMENT_INJECT,
                            collaborator_payload=payload,
                            timestamp=time.time(),
                            parameter_name=None,
                            header_name=label
                        )
                        with self._interaction_map_lock:
                            self._interaction_map[payload] = interaction_data
                        self.stdout.println("[{}] Sent path inject to {}:{} — {}".format(
                            TEST_PATH_SEGMENT_INJECT,
                            http_service.getHost(),
                            http_service.getPort(),
                            injected_path
                        ))
                    else:
                        self.stderr.println("!!! [{}] makeHttpRequest returned None for path: {}".format(
                            TEST_PATH_SEGMENT_INJECT, injected_path))
                except Exception as e_variant:
                    self.stderr.println("!!! [{}] Error sending variant '{}': {}".format(
                        TEST_PATH_SEGMENT_INJECT, label, e_variant))
                    self.stderr.println(traceback.format_exc())
        except Exception as e:
            self.stderr.println("!!! ERROR during path segment SSRF test:")
            self.stderr.println(traceback.format_exc())

    # Adhering to formatting rule
    def _poll_collaborator(self):
        while self._running:
            try:
                interactions = self._collaborator_context.fetchAllCollaboratorInteractions()
                if interactions:
                    processed_full_payloads = set()
                    with self._interaction_map_lock:
                        current_map_keys = list(self._interaction_map.keys())
                        for interaction in interactions:
                            interaction_prefix = interaction.getProperty("interaction_id")
                            if not interaction_prefix:
                                continue
                            found_match_key = None
                            for full_payload_key in current_map_keys:
                                if full_payload_key.startswith(interaction_prefix):
                                    if full_payload_key in self._interaction_map and full_payload_key not in processed_full_payloads:
                                        found_match_key = full_payload_key
                                        break
                            if found_match_key:
                                interaction_info = self._interaction_map.pop(found_match_key)
                                processed_full_payloads.add(found_match_key)
                                self.stdout.println(">>> Collaborator interaction for {} {}(Payload: {}). Reporting issue...".format(
                                    interaction_info.test_type,
                                    "Header: {} ".format(interaction_info.header_name) if interaction_info.header_name else "",
                                    found_match_key))
                                threading.Thread(target=self._report_issue, args=(interaction_info, interaction)).start()
            except Exception as e:
                self.stderr.println("!!! Error polling Burp Collaborator:")
                self.stderr.println(traceback.format_exc())
            time.sleep(COLLABORATOR_POLL_INTERVAL)

    # Adhering to formatting rule
    def _cleanup_interactions(self):
        while self._running:
            try:
                now = time.time()
                cleaned_count = 0
                payloads_to_remove = []
                with self._interaction_map_lock:
                    payloads_to_remove = [
                        p for p, info in self._interaction_map.items()
                        if (now - info.timestamp) > INTERACTION_TIMEOUT
                    ]
                    for payload in payloads_to_remove:
                        if payload in self._interaction_map:
                             del self._interaction_map[payload]
                             cleaned_count += 1
            except Exception as e:
                self.stderr.println("!!! Error during interaction cleanup:")
                self.stderr.println(traceback.format_exc())
            sleep_duration = max(1, INTERACTION_TIMEOUT / 2)
            time.sleep(sleep_duration)

    # <<< REMOVED: _report_url_param_found_issue function is no longer needed >>>

    # <<< MODIFIED: Logic for dynamic title and severity >>>
    def _report_issue(self, interaction_info, interaction):
        try:
            original_req_resp_obj = interaction_info.original_request_response
            test_req_resp_obj = interaction_info.test_request_response
            http_service = original_req_resp_obj.getHttpService()
            url = self._helpers.analyzeRequest(original_req_resp_obj).getUrl()

            # --- Start Dynamic Title/Severity Logic ---
            interaction_type = interaction.getProperty("type") or "Unknown" # e.g., "DNS", "HTTP"
            client_ip = interaction.getProperty("client_ip") or "N/A"
            payload_used = interaction_info.collaborator_payload or "N/A"

            # Determine severity based on interaction type
            if interaction_type.upper() == "HTTP":
                severity = "High"
            elif interaction_type.upper() == "DNS":
                severity = "Medium"
            else:
                severity = "Low" # Fallback for unknown types

            # Determine trigger details and confidence
            trigger_string = "Unknown"
            confidence = "Firm" # Default confidence
            if interaction_info.parameter_name:
                trigger_string = "Param: {}".format(interaction_info.parameter_name)
                confidence = PARAM_INTERACTION_CONFIDENCE
                trigger_source = "parameter '<b>{}</b>'".format(cgi.escape(interaction_info.parameter_name))
                trigger_field = "Parameter: {}<br>".format(cgi.escape(interaction_info.parameter_name))
            elif interaction_info.header_name:
                trigger_string = "Header: {}".format(interaction_info.header_name)
                confidence = HEADER_ISSUE_CONFIDENCE
                trigger_source = "header '<b>{}</b>'".format(cgi.escape(interaction_info.header_name))
                trigger_field = "Header: {}<br>Test Type: {}<br>".format(cgi.escape(interaction_info.header_name), interaction_info.test_type)

            # Check if IP is Cloudflare
            ip_string = client_ip
            if self._is_cloudflare_ip(client_ip):
                ip_string = "{} (CF)".format(client_ip)

            # Combine all parts for the final issue title
            issue_name = "{} - {} - {} - {}".format(
                EXTENSION_NAME,
                interaction_type.upper(),
                ip_string,
                trigger_string
            )
            # --- End Dynamic Title/Severity Logic ---

            # --- Highlighting Logic (Parameters Only) ---
            marked_original_req_resp = original_req_resp_obj
            marked_test_req_resp = test_req_resp_obj
            if interaction_info.parameter_name:
                request_markers_orig = ArrayList()
                request_markers_test = ArrayList()
                try: # Original request markers
                    req_info_orig = self._helpers.analyzeRequest(original_req_resp_obj)
                    for p in req_info_orig.getParameters():
                        if p.getName() == interaction_info.parameter_name:
                            vs = p.getValueStart()
                            ve = p.getValueEnd()
                            if vs >= 0 and ve >= 0 and ve >= vs:
                                request_markers_orig.add(array([vs, ve], 'i'))
                                break
                except Exception as e_mark_orig:
                     self.stderr.println("!!! Error finding markers in original req for param {}: {}".format(interaction_info.parameter_name, e_mark_orig))
                try: # Test request markers
                    req_info_test = self._helpers.analyzeRequest(test_req_resp_obj)
                    for p_test in req_info_test.getParameters():
                         if p_test.getName() == interaction_info.parameter_name:
                              vs_test = p_test.getValueStart()
                              ve_test = p_test.getValueEnd()
                              if vs_test >= 0 and ve_test >= 0 and ve_test >= vs_test:
                                   request_markers_test.add(array([vs_test, ve_test], 'i'))
                                   break
                except Exception as e_mark_test:
                     self.stderr.println("!!! Error finding markers in test req for param {}: {}".format(interaction_info.parameter_name, e_mark_test))

                if not request_markers_orig.isEmpty():
                    try:
                        marked_original_req_resp = self._callbacks.applyMarkers(original_req_resp_obj, request_markers_orig, None)
                    except Exception as e_apply_orig:
                         self.stderr.println("!!! Error applying markers to original request: {}".format(e_apply_orig))
                if not request_markers_test.isEmpty():
                     try:
                        marked_test_req_resp = self._callbacks.applyMarkers(test_req_resp_obj, request_markers_test, None)
                     except Exception as e_apply_test:
                         self.stderr.println("!!! Error applying markers to test request: {}".format(e_apply_test))
            # --- End Highlighting Logic ---

            http_messages = [marked_original_req_resp, marked_test_req_resp]

            # --- Build Detail String ---
            detail = """Burp Collaborator interaction detected.<br>
<b>Triggered By:</b> {trigger_field}<b>Interaction Type:</b> {interaction_type}<br>
<b>Client IP:</b> {client_ip}<br>
<b>Collaborator Payload:</b> {payload}<br>""".format(
                trigger_field=trigger_field, interaction_type=interaction_type,
                client_ip=cgi.escape(client_ip), payload=cgi.escape(payload_used)
            )
            if interaction_type == "DNS":
                query_type = interaction.getProperty("query_type")
                if query_type:
                    detail += "<b>DNS Query Type:</b> {}<br>".format(cgi.escape(query_type))
            if interaction_type == "HTTP":
                http_request_raw = interaction.getProperty("request")
                if http_request_raw:
                    try:
                        import base64
                        http_request_decoded = base64.b64decode(http_request_raw).decode('utf-8', 'ignore')
                        detail += "<br><b>Received HTTP Request:</b><br><pre>{}</pre><br>".format(cgi.escape(http_request_decoded))
                    except Exception:
                        detail += "<br><b>Received Raw HTTP Request (Base64):</b> {}...<br>".format(cgi.escape(http_request_raw[:100]))

            # --- Build Remediation & Issue ---
            remediation = "Review server-side code handling {}. Implement strict validation (allow-list) for any outbound requests based on this input.".format(trigger_source)
            scan_issue = CustomScanIssue(
                http_service, url, http_messages, issue_name, detail, remediation, severity, confidence
            )

            # --- Duplicate Check ---
            already_reported = False
            try:
                existing_issues = self._callbacks.getScanIssues(url.toString());
                for issue in existing_issues:
                    if issue.getIssueName() == issue_name and issue.getUrl().toString() == url.toString():
                        already_reported = True
                        break
            except Exception as e_getissues:
                 self.stderr.println("!!! Error checking duplicate 'SSRF Interaction': {}".format(e_getissues))

            # --- Add Issue ---
            if not already_reported:
                 self._callbacks.addScanIssue(scan_issue)
                 self.stdout.println(">>> Successfully reported SSRF issue: {} | URL: {}".format(issue_name, url))
        except Exception as e:
            self.stderr.println("!!! FATAL ERROR in _report_issue thread:")
            self.stderr.println(traceback.format_exc())

