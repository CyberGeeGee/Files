# AutoSSRF: Path Segment Inject — Analysis Plan (v5)

## Conclusion: The Code Is Correct

After reading the fully applied v4 source, the dedup logic in `processHttpMessage` is correctly implemented:

```python
with self._processed_path_segment_targets_lock:
    if per_segment_key not in self._processed_path_segment_targets:
        self._processed_path_segment_targets.add(per_segment_key)
        should_process_path_seg = True
    if root_inject_key not in self._processed_path_segment_targets:
        self._processed_path_segment_targets.add(root_inject_key)
        should_do_root = True
```

Both keys are checked and set **atomically under a single lock acquisition** before any thread is spawned. There is no race condition. The `should_do_root` boolean is decided before the thread exists and passed in as a plain argument. `_run_path_segment_ssrf_test` makes no dedup decisions of its own.

---

## Why Multiple Root Injects Are Appearing

The root inject key is scoped to `host:port`:

```python
root_inject_key = "{}:{}:__root__".format(host, port)
```

**One root inject per distinct `host:port` is correct and expected behaviour.** Looking at the observed log output:

```
/http://...                      ← host A, root inject
/p/http://...                    ← host A, first segment "p"
/shell-sdk/http://...            ← host A, first segment "shell-sdk"
/http://...                      ← host B, root inject  (different host)
/agent/http://...                ← host B, first segment "agent"
/%40cbr/http://...               ← host B, first segment "%40cbr"
/http://...                      ← host C, root inject  (different host again)
/favicon.ico/http://...          ← host C, first segment "favicon.ico"
/rest/http://...                 ← host C, first segment "rest"
/hunt-suite/http://...           ← host C, first segment "hunt-suite"
```

Three root injects = three distinct in-scope hosts. This is the intended behaviour: every unique host gets exactly one root inject and one second-segment inject per unique first segment.

---

## The Only Real Fix: Add Host Attribution to Log Lines

The log line currently only prints the injected path, making it impossible to tell whether a repeated `/http://...` is a genuine duplicate on the same host or a correct first-fire on a new host. Adding the host to the log line makes this immediately auditable.

### Change: update the stdout log line in `_run_path_segment_ssrf_test`

**Current (line ~579):**
```python
self.stdout.println("[{}] Sent path inject: {}".format(
    TEST_PATH_SEGMENT_INJECT, injected_path))
```

**Replace with:**
```python
self.stdout.println("[{}] Sent path inject to {}:{} — {}".format(
    TEST_PATH_SEGMENT_INJECT,
    http_service.getHost(),
    http_service.getPort(),
    injected_path
))
```

### Result

The log will now read:

```
[Path Segment Inject] Sent path inject to app1.example.com:443 — /http://abc.burp.example.com
[Path Segment Inject] Sent path inject to app1.example.com:443 — /p/http://def.burp.example.com
[Path Segment Inject] Sent path inject to app1.example.com:443 — /shell-sdk/http://ghi.burp.example.com
[Path Segment Inject] Sent path inject to api.example.com:443  — /http://jkl.burp.example.com
[Path Segment Inject] Sent path inject to api.example.com:443  — /agent/http://mno.burp.example.com
```

This makes it immediately clear that each root inject is scoped to a different host and is not a bug.

---

## Summary

| Question | Answer |
|---|---|
| Is the dedup logic correct? | ✅ Yes — single lock, both keys checked atomically, no race |
| Are the multiple root injects a bug? | ✅ No — one root inject per distinct `host:port` is correct |
| Is any code logic change needed? | ❌ No |
| What should change? | Add `host:port` to the log line so attribution is visible |
