from flask import Flask, request
import requests
import sys
import re
from urllib.parse import unquote

# --- Configuration ---
APP_PORT = 8888
REQUEST_TIMEOUT = 2  # Short timeout for outbound requests (seconds)

app = Flask(__name__)

# --- Helper: make an outbound HTTP GET request ---
def make_outbound_request(url_to_fetch, source_info):
    if not url_to_fetch.startswith(('http://', 'https://')):
        if '.' in url_to_fetch.split('/')[0]:
            url_to_fetch = "http://" + url_to_fetch
        else:
            url_to_fetch = "http://" + url_to_fetch

    print(">>> [{}]: Attempting outbound GET to: {}".format(source_info, url_to_fetch))
    try:
        response = requests.get(url_to_fetch, timeout=REQUEST_TIMEOUT, verify=False)
        print(">>> [{}]: Status {}".format(source_info, response.status_code))
        return "Fetched ({}): Status {}".format(url_to_fetch, response.status_code), 200
    except requests.exceptions.Timeout:
        print(">>> [{}]: Timed out fetching {}".format(source_info, url_to_fetch))
        return "Error: Request to {} timed out.".format(url_to_fetch), 500
    except requests.exceptions.RequestException as e:
        print(">>> [{}]: RequestException fetching {}: {}".format(source_info, url_to_fetch, e))
        return "Error: Request to {} failed: {}".format(url_to_fetch, e), 500
    except Exception as e:
        print(">>> [{}]: Generic error fetching {}: {}".format(source_info, url_to_fetch, e))
        return "Error: Generic error fetching {}: {}".format(url_to_fetch, e), 500


# --- Helper: reconstruct a proper URL from a Werkzeug-mangled injected path ---
def reconstruct_injected_url(raw):
    """
    Werkzeug's <path:> converter collapses consecutive slashes, so the
    extension's injected path  /http://{payload}  arrives as:
        'http:/{payload}'   (one slash consumed as the route separator)

    Restore the missing slash to produce a valid URL.
    """
    fixed = re.sub(r'^(https?:/)([^/])', r'\1/\2', raw)
    if re.match(r'^https?://', fixed):
        return fixed
    return 'http://' + raw


# ---------------------------------------------------------------------------
# Existing check routes (unchanged from original)
# ---------------------------------------------------------------------------

@app.route('/')
def index():
    return """
    <h1>AutoSSRF Test Application</h1>

    <h2>Existing checks</h2>
    <ul>
        <li><a href="/host_header">/host_header</a> &mdash; reads and fetches the Host header value</li>
        <li><a href="/multi_header">/multi_header</a> &mdash; reads X-Forwarded-For, Referer, X-WAP-Profile etc.</li>
        <li><a href="/param_ssrf_url?target=http://example.com/ssrf">/param_ssrf_url?target=...</a> &mdash; fetches the 'target' param</li>
        <li><a href="/param_ssrf_domain?domain=example.com">/param_ssrf_domain?domain=...</a> &mdash; fetches the 'domain' param</li>
        <li><a href="/param_ssrf_path?resource=/api/v1/data">/param_ssrf_path?resource=...</a> &mdash; path prepend</li>
    </ul>

    <h2>Path Segment Inject check (new)</h2>
    <p>
        Browse the seed links below through Burp. The AutoSSRF extension registers each
        unique first path segment, then automatically fires two probes:
    </p>
    <ul>
        <li><b>Variant 1 (root inject):</b>
            <code>GET /http://&lt;payload&gt;</code> &rarr;
            catch-all detects http:/ prefix, reconstructs URL, makes outbound request.</li>
        <li><b>Variant 2 (second-segment inject):</b>
            <code>GET /&lt;seg&gt;/http://&lt;payload&gt;</code> &rarr;
            catch-all detects http:/ in remainder, reconstructs URL, makes outbound request.</li>
    </ul>
    <p>Seed links (browse these first through Burp):</p>
    <ul>
        <li><a href="/api/items">/api/items</a> &mdash; seeds segment <code>api</code></li>
        <li><a href="/proxy/status">/proxy/status</a> &mdash; seeds segment <code>proxy</code></li>
        <li><a href="/fetch/resource">/fetch/resource</a> &mdash; seeds segment <code>fetch</code></li>
    </ul>
    <p>Check Burp &rarr; Scanner &rarr; Issue Activity and the extension Output tab.</p>
    """, 200


@app.route('/host_header')
def test_host_header():
    """Reads the Host header and attempts to fetch it."""
    host_val = request.headers.get('Host')
    if host_val:
        return make_outbound_request(host_val, "Host Header")
    return "Host header not found.", 400


@app.route('/multi_header')
def test_multi_header():
    """Reads several injected headers and fetches the first match found."""
    headers_to_check = [
        "X-Forwarded-For", "Referer", "X-WAP-Profile",
        "X-Real-IP", "X-Original-URL",
    ]
    for header_name in headers_to_check:
        val = request.headers.get(header_name)
        if val:
            print(">>> [Multi-Header]: Found '{}' = {}".format(header_name, val))
            return make_outbound_request(val, "Multi-Header: {}".format(header_name))
    return "None of the tested headers found.", 200


@app.route('/param_ssrf_url')
def test_param_ssrf_url():
    """Fetches the 'target' URL parameter directly."""
    target = request.args.get('target')
    if target:
        return make_outbound_request(target, "Param SSRF URL (target)")
    return "Missing 'target' parameter.", 400


@app.route('/param_ssrf_domain')
def test_param_ssrf_domain():
    """Fetches the 'domain' parameter."""
    domain = request.args.get('domain')
    if domain:
        return make_outbound_request(domain, "Param SSRF Domain (domain)")
    return "Missing 'domain' parameter.", 400


@app.route('/param_ssrf_path')
def test_param_ssrf_path():
    """Prepends an internal host to the 'resource' path parameter."""
    resource = request.args.get('resource')
    if resource:
        if not resource.startswith('/'):
            resource = '/' + resource
        internal_url = "http://internal-service.local" + resource
        return make_outbound_request(internal_url, "Param SSRF Path (resource)")
    return "Missing 'resource' parameter.", 400


# ---------------------------------------------------------------------------
# Path Segment Inject check — single catch-all route
#
# The extension sends:
#
#   Variant 1 (root inject):
#       GET /http://{payload} HTTP/1.1
#       Werkzeug <path:subpath> captures: 'http:/{payload}'
#       (Leading slash consumed by route; one slash of '//' also consumed)
#
#   Variant 2 (second-segment inject):
#       GET /{first_seg}/http://{payload} HTTP/1.1
#       Werkzeug <path:subpath> captures: '{first_seg}/http:/{payload}'
#
# This route is declared AFTER all fixed routes so Flask matches those first.
# ---------------------------------------------------------------------------

@app.route('/<path:subpath>')
def path_segment_catch_all(subpath):
    """
    Decision tree:
      1. subpath starts with 'http:/' or 'https:/'
           -> Variant 1: reconstruct URL and fetch (collaborator callback expected)
      2. The part after the first '/' starts with 'http:/' or 'https:/'
           -> Variant 2: reconstruct URL and fetch (collaborator callback expected)
      3. Otherwise
           -> Normal browse: return 200 so the extension seeds this first segment
    """
    decoded = unquote(subpath)
    parts = decoded.split('/', 1)
    first_seg = parts[0]
    remainder = parts[1] if len(parts) == 2 else None

    # Variant 1: full subpath is the injected URL
    # e.g. decoded = 'http:/abc123.burpcollaborator.net'
    if re.match(r'^https?:/', decoded):
        url = reconstruct_injected_url(decoded)
        print(">>> [Path Segment Inject - Variant 1 (root)]: {}".format(url))
        result, status = make_outbound_request(url, "Path Segment Inject - Variant 1 (root)")
        return result, status

    # Variant 2: remainder after first segment is the injected URL
    # e.g. decoded = 'api/http:/abc123.burpcollaborator.net'
    if remainder is not None and re.match(r'^https?:/', remainder):
        url = reconstruct_injected_url(remainder)
        print(">>> [Path Segment Inject - Variant 2 (/{}/)]: {}".format(first_seg, url))
        result, status = make_outbound_request(url, "Path Segment Inject - Variant 2 (/{})".format(first_seg))
        return result, status

    # Normal request: seed the first segment, return 200
    print(">>> [Path Catch-all]: normal /{}, first_seg='{}'".format(decoded, first_seg))
    return "OK: /{} (segment '{}' seeded for path-segment SSRF probing)".format(decoded, first_seg), 200


# --- Main Execution ---
if __name__ == '__main__':
    print("Starting Flask SSRF Test App on http://0.0.0.0:{}".format(APP_PORT))
    sys.stdout.flush()
    app.run(host='0.0.0.0', port=APP_PORT, debug=False, threaded=True)
