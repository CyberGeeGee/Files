"""
AutoSecretsCrack - Burp Suite Extension
Passively detects known/weak secrets in ASP.NET ViewState and JWT tokens.

Modules:
  - ViewState: Detects known ASP.NET machine keys (ported from badsecrets)
  - JWT: Detects weak HMAC secrets in JSON Web Tokens
"""

import re
import json
import struct
import base64
import hashlib
import hmac
import os
from java.io import PrintWriter
from burp import IBurpExtender, IScannerCheck, IScanIssue
from jarray import array

# Java crypto imports for AES/DES/3DES decryption
from javax.crypto import Cipher
from javax.crypto.spec import SecretKeySpec, IvParameterSpec

# Import Java exception classes for proper exception handling
from javax.crypto import BadPaddingException
from java.lang import Exception as JavaException
from java.lang import Throwable

EXTENSION_NAME = "AutoSecretsCrack"


# ============================================================================
# Shared utilities
# ============================================================================

def bytes_to_str(b):
    """Convert Java byte array or Python bytes to Python string"""
    if hasattr(b, 'tostring'):
        return b.tostring()
    elif isinstance(b, str):
        return b
    else:
        return str(b)


def base64url_decode(s):
    """Decode base64url string (JWT uses base64url without padding)"""
    s = str(s)
    s = s.replace('-', '+').replace('_', '/')
    padding = 4 - len(s) % 4
    if padding != 4:
        s += '=' * padding
    return base64.b64decode(s)


class ScanIssue(IScanIssue):
    """Generic scan issue used by all modules"""

    def __init__(self, httpService, url, httpMessages, name, detail, severity="High", confidence="Certain"):
        self._httpService = httpService
        self._url = url
        self._httpMessages = httpMessages
        self._name = name
        self._detail = detail
        self._severity = severity
        self._confidence = confidence

    def getUrl(self):
        return self._url

    def getIssueName(self):
        return self._name

    def getIssueType(self):
        return 0x08000000

    def getSeverity(self):
        return self._severity

    def getConfidence(self):
        return self._confidence

    def getIssueDetail(self):
        return self._detail

    def getRemediationDetail(self):
        return None

    def getHttpMessages(self):
        return self._httpMessages

    def getHttpService(self):
        return self._httpService

    def getIssueBackground(self):
        return None

    def getRemediationBackground(self):
        return None


# ============================================================================
# JWT Checker Module
# ============================================================================

class JWTChecker:
    """Detects JWTs signed with known weak HMAC secrets"""

    # Supported HMAC algorithms
    HMAC_ALGS = {
        "HS256": hashlib.sha256,
        "HS384": hashlib.sha384,
        "HS512": hashlib.sha512,
    }

    JWT_REGEX = re.compile(r'(?<!\w)eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}')

    def __init__(self, callbacks, helpers, jwt_secrets, stdout, stderr):
        self._callbacks = callbacks
        self._helpers = helpers
        self._jwt_secrets = jwt_secrets
        self.stdout = stdout
        self.stderr = stderr
        self._checked_jwts = set()

    def log(self, message):
        self.stdout.println("[AutoSecretsCrack][JWT] " + str(message))

    def log_error(self, message):
        self.stderr.println("[AutoSecretsCrack][JWT ERROR] " + str(message))

    def decode_jwt_header(self, jwt_token):
        """Decode JWT header and return (header_dict, algorithm) or (None, None)"""
        parts = jwt_token.split('.')
        if len(parts) != 3:
            return None, None
        try:
            header_json = bytes_to_str(base64url_decode(parts[0]))
            header = json.loads(header_json)
            alg = header.get('alg', '')
            return header, alg
        except Exception:
            return None, None

    def decode_jwt_payload(self, jwt_token):
        """Decode JWT payload and return dict or None"""
        parts = jwt_token.split('.')
        if len(parts) != 3:
            return None
        try:
            payload_json = bytes_to_str(base64url_decode(parts[1]))
            return json.loads(payload_json)
        except Exception:
            return None

    def verify_jwt_hmac(self, jwt_token, secret, hash_func):
        """Verify JWT HMAC signature with given secret. Returns True if match."""
        parts = jwt_token.split('.')
        if len(parts) != 3:
            return False
        signing_input = parts[0] + "." + parts[1]
        try:
            expected_sig = bytes_to_str(base64url_decode(parts[2]))
        except Exception:
            return False
        computed = hmac.new(secret, signing_input, hash_func).digest()
        return computed == expected_sig

    def crack_jwt(self, jwt_token):
        """Try to crack a JWT's HMAC secret. Returns dict with details or None."""
        header, alg = self.decode_jwt_header(jwt_token)
        if not header or not alg:
            return None

        if alg not in self.HMAC_ALGS:
            return None

        hash_func = self.HMAC_ALGS[alg]

        for secret in self._jwt_secrets:
            if self.verify_jwt_hmac(jwt_token, secret, hash_func):
                payload = self.decode_jwt_payload(jwt_token)
                return {
                    "secret": secret,
                    "algorithm": alg,
                    "header": header,
                    "payload": payload,
                }
        return None

    def scan(self, baseRequestResponse, helpers):
        """
        Scan a request/response pair for JWTs with weak secrets.
        Returns list of IScanIssue or empty list.
        """
        issues = []

        response = baseRequestResponse.getResponse()
        if response is None:
            return issues

        request_info = helpers.analyzeRequest(baseRequestResponse)
        response_info = helpers.analyzeResponse(response)
        http_service = baseRequestResponse.getHttpService()
        url_obj = request_info.getUrl()
        url = str(url_obj.toString())

        # Build full response as string for searching
        response_str = bytes_to_str(response)

        # Fast pre-check: skip if no "eyJ" anywhere in the response
        if "eyJ" not in response_str:
            return issues

        # Get header string and body string separately for location tracking
        body_offset = response_info.getBodyOffset()
        headers_str = response_str[:body_offset]
        body_str = response_str[body_offset:]

        # Find all JWTs in headers and body
        jwt_matches = []  # list of (jwt_string, location_label, match_start_in_response)

        for m in self.JWT_REGEX.finditer(headers_str):
            jwt_matches.append((m.group(0), "response header", m.start()))
        for m in self.JWT_REGEX.finditer(body_str):
            jwt_matches.append((m.group(0), "response body", m.start() + body_offset))

        if not jwt_matches:
            return issues

        # Deduplicate JWTs within this response
        seen_jwts = set()
        unique_matches = []
        for jwt_str, location, offset in jwt_matches:
            if jwt_str not in seen_jwts:
                seen_jwts.add(jwt_str)
                unique_matches.append((jwt_str, location, offset))

        for jwt_str, location, match_offset in unique_matches:
            # Global deduplication
            dedupe_key = jwt_str[:100]
            if dedupe_key in self._checked_jwts:
                continue
            self._checked_jwts.add(dedupe_key)

            header, alg = self.decode_jwt_header(jwt_str)
            if not alg or alg not in self.HMAC_ALGS:
                continue

            self.log("Found " + alg + " JWT in " + location + " at: " + url)

            result = self.crack_jwt(jwt_str)
            if not result:
                self.log("  No weak secret found")
                continue

            self.log("  SECRET FOUND: " + result["secret"])

            # Build hashcat POC
            poc_cmd = "hashcat -m 16500 -a 0 " + jwt_str + " <dictionary_file>"

            # Build detail HTML
            detail = "<p>A JWT in the " + location + " is signed with a <strong>known weak secret</strong>.</p>"
            detail += "<p><b>URL:</b> " + url + "</p>"
            detail += "<p><b>Location:</b> " + location + "</p>"
            detail += "<p><b>Algorithm:</b> " + result["algorithm"] + "</p>"
            detail += "<p><b>Secret:</b> <code>" + result["secret"] + "</code></p>"

            if result["header"]:
                detail += "<p><b>JWT Header:</b> <code>" + json.dumps(result["header"]) + "</code></p>"
            if result["payload"]:
                payload_str = json.dumps(result["payload"])
                if len(payload_str) > 500:
                    payload_str = payload_str[:500] + "..."
                detail += "<p><b>JWT Payload:</b> <code>" + payload_str + "</code></p>"

            detail += "<p><b>JWT (truncated):</b> <code>" + jwt_str[:120] + "...</code></p>"
            detail += "<p><br/><b>Proof of Concept:</b></p>"
            detail += "<pre>" + poc_cmd + "</pre>"

            # Create markers
            try:
                marker = array([match_offset, match_offset + len(jwt_str)], 'i')
                annotated = self._callbacks.applyMarkers(baseRequestResponse, None, [marker])
            except Exception:
                annotated = baseRequestResponse

            issue = ScanIssue(
                http_service,
                url_obj,
                [annotated],
                "JWT Weak Secret Detected",
                detail,
            )
            issues.append(issue)

        return issues


# ============================================================================
# ViewState Checker Module
# ============================================================================

class ViewStateChecker:
    """Detects ASP.NET ViewStates signed with known machine keys"""

    HASH_SIZES = {
        "MD5": 16,
        "SHA1": 20,
        "SHA256": 32,
        "SHA384": 48,
        "SHA512": 64
    }

    HASH_ALGS = {
        "SHA1": hashlib.sha1,
        "MD5": hashlib.md5,
        "SHA256": hashlib.sha256,
        "SHA384": hashlib.sha384,
        "SHA512": hashlib.sha512,
    }

    VIEWSTATE_PREAMBLE = "\xff\x01"

    VIEWSTATE_PATTERN = re.compile(
        r'<input[^>]+__VIEWSTATE[^>]+value="([^"]+)"',
        re.IGNORECASE
    )
    GENERATOR_PATTERN = re.compile(
        r'<input[^>]+__VIEWSTATEGENERATOR[^>]+value="([A-Fa-f0-9]{8})"',
        re.IGNORECASE
    )

    def __init__(self, callbacks, helpers, machine_keys, stdout, stderr):
        self._callbacks = callbacks
        self._helpers = helpers
        self._machine_keys = machine_keys
        self.stdout = stdout
        self.stderr = stderr
        self._checked_viewstates = set()

    def log(self, message):
        self.stdout.println("[AutoSecretsCrack][ViewState] " + str(message))

    def log_error(self, message):
        self.stderr.println("[AutoSecretsCrack][ViewState ERROR] " + str(message))

    def unpad(self, s):
        s = bytes_to_str(s)
        if not s:
            return s
        pad_len = ord(s[-1])
        if pad_len > 0 and pad_len <= len(s):
            return s[:-pad_len]
        return s

    def valid_preamble(self, data):
        data = bytes_to_str(data)
        if len(data) >= 2 and data[0:2] == self.VIEWSTATE_PREAMBLE:
            return True
        return False

    def sp800_108_derivekey(self, key, label, context, keyLengthInBits):
        from javax.crypto import Mac
        from javax.crypto.spec import SecretKeySpec

        lblcnt = 0 if label is None else len(label)
        ctxcnt = 0 if context is None else len(context)

        buffer = "\x00" * (4 + lblcnt + 1 + ctxcnt + 4)
        if lblcnt != 0:
            buffer = buffer[:4] + label + buffer[4 + lblcnt:]
        if ctxcnt != 0:
            buffer = buffer[:5 + lblcnt] + context + buffer[5 + lblcnt + ctxcnt:]

        key_len_bytes = struct.pack(">I", keyLengthInBits)
        buffer = buffer[:5 + lblcnt + ctxcnt] + key_len_bytes + buffer[5 + lblcnt + ctxcnt + 4:]

        res_parts = []
        total_bytes = int(keyLengthInBits / 8)
        bytes_filled = 0
        num = 1

        mac = Mac.getInstance("HmacSHA512")
        key_spec = SecretKeySpec(key, "HmacSHA512")

        while bytes_filled < total_bytes:
            counter_bytes = struct.pack(">I", num)
            buffer = counter_bytes + buffer[4:]
            mac.init(key_spec)
            mac_bytes = bytes_to_str(mac.doFinal(buffer))
            cnt = min(total_bytes - bytes_filled, len(mac_bytes))
            res_parts.append(mac_bytes[:cnt])
            bytes_filled += cnt
            num += 1

        return "".join(res_parts)

    def write_vlq_string(self, string):
        encoded_string = string.encode("utf-8")
        length = len(encoded_string)
        length_vlq = []
        while length >= 0x80:
            length_vlq.append(chr((length | 0x80) & 0xFF))
            length >>= 7
        length_vlq.append(chr(length))
        return "".join(length_vlq) + encoded_string

    def get_specific_purposes_from_url(self, url):
        try:
            from urlparse import urlparse
            parsed = urlparse(url)
            str_path = parsed.path

            if "/" in str_path:
                iis_app_in_path = str_path.rsplit("/", 1)[0] or "/"
            else:
                iis_app_in_path = "/"

            template_source = iis_app_in_path[:-1] if iis_app_in_path.endswith("/") else iis_app_in_path
            if not template_source:
                template_source = "/"

            str_path_lower = str_path.lower()
            iis_app_lower = iis_app_in_path.lower()

            if iis_app_lower in str_path_lower:
                relative_path = str_path_lower.split(iis_app_lower, 1)[1]
            else:
                relative_path = str_path

            if relative_path.startswith("/"):
                relative_path = relative_path[1:]

            type_name = relative_path.replace(".", "_").replace("/", "_")
            if type_name.endswith("_"):
                type_name = type_name[:-1]

            return [
                "TemplateSourceDirectory: " + template_source.upper(),
                "Type: " + type_name.upper()
            ]
        except Exception as e:
            self.log_error("Error parsing URL for KDF: " + str(e))
            return ["TemplateSourceDirectory: /", "Type: DEFAULT_ASPX"]

    def viewstate_validate(self, vkey_bytes, encrypted, viewstate_bytes, generator, url, mode):
        viewstate_bytes = bytes_to_str(viewstate_bytes)
        vkey_bytes = bytes_to_str(vkey_bytes)
        generator = bytes_to_str(generator)

        candidate_hash_algs = list(self.HASH_SIZES.keys())

        for hash_alg in candidate_hash_algs:
            hash_size = self.HASH_SIZES[hash_alg]
            if len(viewstate_bytes) < hash_size:
                continue

            viewstate_data = viewstate_bytes[:-hash_size]
            signature = viewstate_bytes[-hash_size:]

            try:
                if hash_alg == "MD5":
                    md5_bytes = viewstate_data + vkey_bytes + "\x00" * 4
                    h = hashlib.md5(md5_bytes)
                else:
                    vs_data_bytes = viewstate_data
                    if not encrypted:
                        vs_data_bytes += generator
                    vkey_to_use = vkey_bytes
                    if mode == "DOTNET45" and url:
                        label = "WebForms.HiddenFieldPageStatePersister.ClientState"
                        specific_purposes = self.get_specific_purposes_from_url(url)
                        context = "".join([self.write_vlq_string(p) for p in specific_purposes])
                        vkey_to_use = bytes_to_str(self.sp800_108_derivekey(vkey_bytes, label, context, len(vkey_bytes) * 8))
                    h = hmac.new(vkey_to_use, vs_data_bytes, self.HASH_ALGS[hash_alg])

                if signature == h.digest():
                    return hash_alg
            except Exception as e:
                continue

        return None

    def viewstate_decrypt(self, ekey_bytes, hash_alg, viewstate_bytes, url, mode):
        viewstate_bytes = bytes_to_str(viewstate_bytes)
        ekey_bytes = bytes_to_str(ekey_bytes)

        hash_size = self.HASH_SIZES[hash_alg]
        vs_size = len(viewstate_bytes)

        dec_algos = set()
        if (vs_size - hash_size) % 16 == 0:
            dec_algos.add("AES")
        if (vs_size - hash_size) % 8 == 0:
            dec_algos.add("DES")
            dec_algos.add("3DES")

        for dec_algo in dec_algos:
            try:
                if dec_algo == "AES":
                    block_size = 16
                    iv = viewstate_bytes[0:block_size]
                    ekey_to_use = ekey_bytes[:32]
                    if mode == "DOTNET45" and url:
                        label = "WebForms.HiddenFieldPageStatePersister.ClientState"
                        specific_purposes = self.get_specific_purposes_from_url(url)
                        context = "".join([self.write_vlq_string(p) for p in specific_purposes])
                        derived = self.sp800_108_derivekey(ekey_bytes[:32], label, context, len(ekey_bytes[:32]) * 8)
                        ekey_to_use = bytes_to_str(derived)

                    cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
                    key_spec = SecretKeySpec(ekey_to_use, "AES")
                    iv_spec = IvParameterSpec(iv)
                    cipher.init(Cipher.DECRYPT_MODE, key_spec, iv_spec)
                    encrypted_raw = viewstate_bytes[block_size:-hash_size]
                    decrypted_raw = cipher.doFinal(encrypted_raw)
                    decrypted = self.unpad(decrypted_raw) if mode == "DOTNET45" else decrypted_raw
                    if self.valid_preamble(decrypted):
                        return dec_algo

                elif dec_algo == "3DES":
                    block_size = 8
                    iv = viewstate_bytes[0:block_size]
                    ekey_to_use = ekey_bytes[:24]
                    cipher = Cipher.getInstance("DESede/CBC/PKCS5Padding")
                    key_spec = SecretKeySpec(ekey_to_use, "DESede")
                    iv_spec = IvParameterSpec(iv)
                    cipher.init(Cipher.DECRYPT_MODE, key_spec, iv_spec)
                    encrypted_raw = viewstate_bytes[block_size:-hash_size]
                    decrypted_raw = cipher.doFinal(encrypted_raw)
                    decrypted = self.unpad(decrypted_raw)
                    if self.valid_preamble(decrypted):
                        return dec_algo

                elif dec_algo == "DES":
                    block_size = 8
                    iv = viewstate_bytes[0:block_size]
                    ekey_to_use = ekey_bytes[:8]
                    cipher = Cipher.getInstance("DES/CBC/PKCS5Padding")
                    key_spec = SecretKeySpec(ekey_to_use, "DES")
                    iv_spec = IvParameterSpec(iv)
                    cipher.init(Cipher.DECRYPT_MODE, key_spec, iv_spec)
                    encrypted_raw = viewstate_bytes[block_size:-hash_size]
                    decrypted_raw = cipher.doFinal(encrypted_raw)
                    decrypted = self.unpad(decrypted_raw)
                    if self.valid_preamble(decrypted):
                        return dec_algo

            except (Exception, JavaException, Throwable, BadPaddingException):
                pass

        return None

    def check_viewstate(self, viewstate_b64, generator_hex, url):
        try:
            viewstate_bytes = bytes_to_str(base64.b64decode(viewstate_b64))
        except Exception:
            return None

        try:
            generator = struct.pack("<I", int(generator_hex, 16))
        except Exception:
            generator = "\x00\x00\x00\x00"

        encrypted = not self.valid_preamble(viewstate_bytes)

        for vkey_hex, ekey_hex in self._machine_keys:
            try:
                vkey_bytes = vkey_hex.decode("hex")
            except Exception:
                continue

            confirmed_ekey = None
            decryption_algo = None

            for mode in ["DOTNET40", "DOTNET45"]:
                try:
                    validation_algo = self.viewstate_validate(
                        vkey_bytes, encrypted, viewstate_bytes, generator, url, mode
                    )

                    if validation_algo:
                        if encrypted and ekey_hex:
                            try:
                                ekey_bytes = ekey_hex.decode("hex")
                                decryption_algo = self.viewstate_decrypt(
                                    ekey_bytes, validation_algo, viewstate_bytes, url, mode
                                )
                                if decryption_algo:
                                    confirmed_ekey = ekey_hex
                            except Exception:
                                pass

                        result = {
                            "validationKey": vkey_hex,
                            "validationAlgo": validation_algo,
                            "mode": mode
                        }
                        if confirmed_ekey:
                            result["encryptionKey"] = confirmed_ekey
                            result["encryptionAlgo"] = decryption_algo
                        return result
                except Exception as e:
                    continue

        return None

    def scan(self, baseRequestResponse, helpers):
        """
        Scan a request/response for ViewState with known machine keys.
        Returns list of IScanIssue or empty list.
        """
        issues = []

        request_info = helpers.analyzeRequest(baseRequestResponse)
        http_service = baseRequestResponse.getHttpService()

        # ViewState only appears in GET requests returning HTML
        if request_info.getMethod() != "GET":
            return issues

        response = baseRequestResponse.getResponse()
        if response is None:
            return issues

        response_info = helpers.analyzeResponse(response)
        mime_type = response_info.getInferredMimeType()
        if mime_type and mime_type not in ["HTML", "html", "text/html", "application/xhtml+xml"]:
            return issues

        body_offset = response_info.getBodyOffset()
        response_body = response[body_offset:].tostring()

        viewstate_match = self.VIEWSTATE_PATTERN.search(response_body)
        if not viewstate_match:
            return issues

        viewstate_value = viewstate_match.group(1)

        generator_match = self.GENERATOR_PATTERN.search(response_body)
        generator_value = generator_match.group(1) if generator_match else "00000000"

        url_obj = request_info.getUrl()
        url = str(url_obj.toString())

        dedupe_key = viewstate_value[:100] + "|" + generator_value + "|" + url[:100]
        if dedupe_key in self._checked_viewstates:
            return issues
        self._checked_viewstates.add(dedupe_key)

        self.log("Checking viewstate at: " + url)
        self.log("  Generator: " + generator_value)
        self.log("  ViewState length: " + str(len(viewstate_value)))

        result = self.check_viewstate(viewstate_value, generator_value, url)

        if result:
            self.log("MATCH FOUND! Mode: " + result["mode"])
            self.log("  Validation: " + result["validationAlgo"])
            self.log("  Key: " + result["validationKey"][:32] + "...")

            # Build POC command
            poc_cmd = "ysoviewstate.exe -r req.txt"
            poc_cmd += " -vk " + result["validationKey"]
            if "encryptionKey" in result:
                poc_cmd += " -ek " + result["encryptionKey"]
                poc_cmd += " -ea " + result["encryptionAlgo"]
            poc_cmd += " -va " + result["validationAlgo"]
            poc_cmd += " --mode " + result["mode"]
            if generator_value != "00000000":
                poc_cmd += " --generator " + generator_value
            if url.lower().startswith("https"):
                poc_cmd += " --ssl"
            poc_cmd += " -c http://{collaboratorurl}"

            # Build detail HTML
            detail = "<p>The ASP.NET ViewState at this URL is signed with a <strong>known machine key</strong>.</p>"
            detail += "<p><b>URL:</b> " + url + "</p>"
            detail += "<p><b>Mode:</b> " + result["mode"] + "</p>"
            detail += "<p><b>Validation Algorithm:</b> " + result["validationAlgo"] + "</p>"
            detail += "<p><b>Validation Key:</b> <code>" + result["validationKey"] + "</code></p>"

            if "encryptionKey" in result:
                detail += "<p><b>Encryption Algorithm:</b> " + result["encryptionAlgo"] + "</p>"
                detail += "<p><b>Encryption Key:</b> <code>" + result["encryptionKey"] + "</code></p>"

            detail += "<p><b>ViewState (truncated):</b> <code>" + viewstate_value[:100] + "...</code></p>"
            if generator_value != "00000000":
                detail += "<p><b>Generator:</b> <code>" + generator_value + "</code></p>"

            detail += "<p><br/><b>Proof of Concept:</b></p>"
            detail += "<pre>" + poc_cmd + "</pre>"

            # Create markers
            try:
                match_start = viewstate_match.start(1)
                match_end = viewstate_match.end(1)
                marker = array([match_start + body_offset, match_end + body_offset], 'i')
                annotated = self._callbacks.applyMarkers(baseRequestResponse, None, [marker])
            except Exception:
                annotated = baseRequestResponse

            issue = ScanIssue(
                http_service,
                url_obj,
                [annotated],
                "ASP.NET Known Machine Key Detected",
                detail,
            )
            issues.append(issue)

        return issues


# ============================================================================
# BurpExtender - Main entry point
# ============================================================================

class BurpExtender(IBurpExtender, IScannerCheck):

    def registerExtenderCallbacks(self, callbacks):
        self._callbacks = callbacks
        self._helpers = callbacks.getHelpers()

        self.stdout = PrintWriter(callbacks.getStdout(), True)
        self.stderr = PrintWriter(callbacks.getStderr(), True)

        callbacks.setExtensionName(EXTENSION_NAME)

        self.stdout.println("[" + EXTENSION_NAME + "] Extension loading...")

        # Resolve extension directory
        self._ext_dir = self._resolve_ext_dir()

        # Load resources
        machine_keys = self._load_machine_keys()
        jwt_secrets = self._load_jwt_secrets()

        self.stdout.println("[" + EXTENSION_NAME + "] Loaded " + str(len(machine_keys)) + " machine keys")
        self.stdout.println("[" + EXTENSION_NAME + "] Loaded " + str(len(jwt_secrets)) + " JWT secrets")

        # Create module instances
        self._viewstate = ViewStateChecker(callbacks, self._helpers, machine_keys, self.stdout, self.stderr)
        self._jwt = JWTChecker(callbacks, self._helpers, jwt_secrets, self.stdout, self.stderr)

        callbacks.registerScannerCheck(self)

        self.stdout.println("[" + EXTENSION_NAME + "] Extension loaded successfully!")
        self.stdout.println("[" + EXTENSION_NAME + "] Modules: ViewState, JWT")

    def _resolve_ext_dir(self):
        """Find directory containing resource files"""
        ext_dir = None
        try:
            ext_dir = os.path.dirname(os.path.abspath(__file__))
            self.stdout.println("[" + EXTENSION_NAME + "] Extension dir: " + ext_dir)
        except Exception:
            pass

        if not ext_dir or not os.path.exists(os.path.join(ext_dir, "aspnet_machinekeys.txt")):
            cwd = os.getcwd()
            if os.path.exists(os.path.join(cwd, "aspnet_machinekeys.txt")):
                ext_dir = cwd
                self.stdout.println("[" + EXTENSION_NAME + "] Using CWD: " + cwd)
            else:
                self.stderr.println("[" + EXTENSION_NAME + "] Cannot find resource files!")
                ext_dir = cwd
        return ext_dir

    def _load_file_lines(self, filename, skip_header=False, csv_split=False):
        """Generic file loader. Returns list of strings or tuples."""
        filepath = os.path.join(self._ext_dir, filename)
        results = []
        if not os.path.exists(filepath):
            self.stdout.println("[" + EXTENSION_NAME + "] " + filename + " not found (optional)")
            return results
        try:
            with open(filepath, "r") as f:
                if skip_header:
                    f.readline()
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    if csv_split:
                        parts = line.split(",")
                        if len(parts) >= 2:
                            a, b = parts[0].strip(), parts[1].strip()
                            if a and b:
                                results.append((a, b))
                    else:
                        results.append(line)
        except Exception as e:
            self.stderr.println("[" + EXTENSION_NAME + "] Error loading " + filename + ": " + str(e))
        return results

    def _load_machine_keys(self):
        """Load machine keys from both key files"""
        keys = self._load_file_lines("aspnet_machinekeys.txt", csv_split=True)
        keys += self._load_file_lines("MachineKeys.csv", skip_header=True, csv_split=True)
        return keys

    def _load_jwt_secrets(self):
        """Load JWT secrets wordlist"""
        return self._load_file_lines("jwt_secrets.txt")

    def doPassiveScan(self, baseRequestResponse):
        """Run all modules and merge results"""
        issues = []
        try:
            issues += self._viewstate.scan(baseRequestResponse, self._helpers)
        except Exception as e:
            self.stderr.println("[" + EXTENSION_NAME + "] ViewState error: " + str(e))
        try:
            issues += self._jwt.scan(baseRequestResponse, self._helpers)
        except Exception as e:
            self.stderr.println("[" + EXTENSION_NAME + "] JWT error: " + str(e))
        return issues if issues else None

    def doActiveScan(self, baseRequestResponse, insertionPoint):
        return None

    def consolidateDuplicateIssues(self, existingIssue, newIssue):
        if existingIssue.getIssueName() == newIssue.getIssueName() and existingIssue.getIssueDetail() == newIssue.getIssueDetail():
            return -1  # True duplicate, keep existing only
        return 0  # Different issues, report both
