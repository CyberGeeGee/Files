================================================================================
AutoSecretsCrack - Burp Suite Extension
================================================================================

DESCRIPTION:
-----------
AutoSecretsCrack is a Burp Suite passive scanner extension (Python/Jython) that
detects known/weak secrets in HTTP traffic. It currently includes two modules:

1. ViewState Module - Detects ASP.NET pages using known machine keys for
   ViewState signing/encryption. Ported from badsecrets by blacklanternsecurity.

2. JWT Module - Detects JSON Web Tokens signed with known weak HMAC secrets
   by brute-forcing against a wordlist of common JWT secrets.

Both modules run passively on all proxied traffic with no extra requests sent.

================================================================================
MODULES:
-------

ViewState Module:
- Triggers on GET requests returning HTML with __VIEWSTATE
- Extracts ViewState value and ViewStateGenerator
- Tests against ~7,400 known machine keys (aspnet_machinekeys.txt + MachineKeys.csv)
- Supports MD5, SHA1, SHA256, SHA384, SHA512 validation
- Supports AES, 3DES, DES decryption
- Handles both .NET 4.0 and .NET 4.5+ (SP800-108 KDF)
- Reports POC command using ysoviewstate.exe

JWT Module:
- Triggers on ANY response containing "eyJ" (fast pre-check)
- Extracts JWTs from both response headers and body via regex
- Only cracks HMAC-based algorithms: HS256, HS384, HS512
- Tests against 3,500+ known weak JWT secrets (jwt_secrets.txt)
- Reports POC command using hashcat mode 16500

================================================================================
REQUIREMENTS:
------------
- Burp Suite Professional or Free
- Jython 2.7 standalone JAR (configured in Burp Extensions options)
- Resource files in same directory as the extension

================================================================================
INSTALLATION:
------------
1. In Burp, go to Extender -> Extensions -> Add
2. Extension Type: Python
3. Select AutoSecretsCrack.py
4. Click "Next"

Expected output:
    [AutoSecretsCrack] Loaded 7483 machine keys
    [AutoSecretsCrack] Loaded 3502 JWT secrets
    [AutoSecretsCrack] Extension loaded successfully!
    [AutoSecretsCrack] Modules: ViewState, JWT

================================================================================
FILES:
-----
- AutoSecretsCrack.py      - Main extension file
- aspnet_machinekeys.txt   - Known ASP.NET machine keys (~3,770 entries)
- MachineKeys.csv          - Microsoft additional machine keys (~3,713 entries)
- jwt_secrets.txt          - Known weak JWT secrets (~3,502 entries)
- readme.txt               - This file
- prompt.txt               - Prompt to reproduce this extension
- compile.txt              - Usage instructions (no compilation needed)

================================================================================
LOGGING:
-------
Module-specific log prefixes:
    [AutoSecretsCrack][ViewState] Checking viewstate at: ...
    [AutoSecretsCrack][ViewState] MATCH FOUND! Mode: DOTNET45
    [AutoSecretsCrack][JWT] Found HS256 JWT in response header at: ...
    [AutoSecretsCrack][JWT]   SECRET FOUND: mysecret123

================================================================================
CREDITS:
-------
- ViewState module based on badsecrets by blacklanternsecurity
- JWT secrets wordlist from badsecrets project

================================================================================
VERSION:
-------
2.0 - Renamed to AutoSecretsCrack, added JWT module
1.0 - Initial release as ViewStateLeaker
