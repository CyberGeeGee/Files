from burp import IBurpExtender, IMessageEditorTabFactory, IMessageEditorTab
from javax.swing import JPanel, JScrollPane, JTextArea, JButton
from java.awt import BorderLayout, Toolkit, FlowLayout
from java.awt.datatransfer import StringSelection
from java.lang import String
import re
import json
from collections import OrderedDict

class BurpExtender(IBurpExtender):
    """
    Main class for the Burp extension.
    Registers two separate tab factories: one for Bragi and one for Markdown.
    """
    def registerExtenderCallbacks(self, callbacks):
        self._callbacks = callbacks
        self._helpers = callbacks.getHelpers()
        callbacks.setExtensionName("Formatters")
        
        # Register the Bragi Formatter tab
        callbacks.registerMessageEditorTabFactory(BragiFormatterFactory(self._helpers))
        
        # Register the Markdown Formatter tab
        callbacks.registerMessageEditorTabFactory(MarkdownFormatterFactory(self._helpers))
        return

# --- Factories ---

class BragiFormatterFactory(IMessageEditorTabFactory):
    def __init__(self, helpers):
        self._helpers = helpers

    def createNewInstance(self, controller, editable):
        return BragiFormatterTab(controller, editable, self._helpers)

class MarkdownFormatterFactory(IMessageEditorTabFactory):
    def __init__(self, helpers):
        self._helpers = helpers

    def createNewInstance(self, controller, editable):
        return MarkdownFormatterTab(controller, editable, self._helpers)

# --- Base Tab Class (Shared Logic) ---

class BaseFormatterTab(IMessageEditorTab):
    """
    Base class containing shared UI setup and body processing logic.
    """
    def __init__(self, controller, editable, helpers):
        self._controller = controller
        self._editable = editable
        self._helpers = helpers

        # UI Setup
        self._panel = JPanel(BorderLayout())
        topPanel = JPanel(FlowLayout(FlowLayout.LEFT))
        self._copyButton = JButton("Copy", actionPerformed=self.copyText)
        topPanel.add(self._copyButton)
        self._panel.add(topPanel, BorderLayout.NORTH)

        self._textArea = JTextArea()
        self._textArea.setEditable(False)
        self._scrollPane = JScrollPane(self._textArea)
        self._panel.add(self._scrollPane, BorderLayout.CENTER)

    def getUiComponent(self):
        return self._panel

    def isEnabled(self, content, isRequest):
        return content is not None

    def setMessage(self, content, isRequest):
        requestBytes = self._controller.getRequest()
        responseBytes = self._controller.getResponse()
        formatted = self.formatReport(requestBytes, responseBytes)
        self._textArea.setText(formatted)
        self._textArea.setCaretPosition(0)

    def getMessage(self):
        return None

    def isModified(self):
        return False

    def getSelectedData(self):
        return None

    def copyText(self, event):
        text = self._textArea.getText()
        selection = StringSelection(text)
        clipboard = Toolkit.getDefaultToolkit().getSystemClipboard()
        clipboard.setContents(selection, selection)

    def processBody(self, raw_bytes, analysis_info, charset, content_type_header):
        """
        Shared logic to extract, decode, clean, and prettify the body.
        """
        bodyOffset = analysis_info.getBodyOffset()
        if len(raw_bytes) <= bodyOffset:
            return "", False

        rawBodyBytes = raw_bytes[bodyOffset:]
        
        # 1. Robust Decoding using Java String (Reverted to this method as it is stable in Jython)
        try:
            # Decode using the specified charset, then convert to a Python string
            body = str(String(rawBodyBytes, charset))
        except:
            try:
                # Fallback to UTF-8
                body = str(String(rawBodyBytes, "UTF-8"))
            except:
                # Final fallback using Burp helpers
                body = self._helpers.bytesToString(rawBodyBytes)

        # 2. JSON Prettifying (Ordered)
        if content_type_header and "json" in content_type_header.lower():
            try:
                # Attempt to parse as JSON with order preservation
                parsed_json = json.loads(body.strip(), object_pairs_hook=OrderedDict)
                body = json.dumps(parsed_json, indent=4)
            except ValueError:
                pass
        
        # 3. Remove Binary/Non-Printable Characters
        # Keep tab (\t), newline (\n), return (\r) and printable range
        body = re.sub(r'[^\x20-\x7E\n\r\t]', '', body)

        # 4. Truncation
        truncated = False
        if len(body) > 500:
            body = body[:500].rstrip()
            truncated = True

        return body, truncated

    def formatReport(self, requestBytes, responseBytes):
        raise NotImplementedError("Subclasses must implement formatReport")

# --- Specific Implementations ---

class BragiFormatterTab(BaseFormatterTab):
    def getTabCaption(self):
        return "Bragi Formatter"

    def formatReport(self, requestBytes, responseBytes):
        sb = []
        
        # --- Request ---
        if requestBytes:
            reqInfo = self._helpers.analyzeRequest(requestBytes)
            reqHeaders = reqInfo.getHeaders()
            sb.append('<gdscode language="http" hdr="Reproduction Request">\n')
            
            if reqHeaders.size() > 0:
                sb.append(reqHeaders.get(0) + "\n")

            reqCharset = "UTF-8"
            reqContentType = ""

            for i in range(1, reqHeaders.size()):
                header = reqHeaders.get(i)
                lower_header = header.lower()
                
                if (lower_header.startswith("host:") or 
                    lower_header.startswith("content-type:") or 
                    lower_header.startswith("x-amz-target:")):
                    
                    if lower_header.startswith("content-type:"):
                        reqContentType = header.split(":", 1)[1].strip()
                        match = re.search('charset=([^;]+)', header, re.IGNORECASE)
                        if match: reqCharset = match.group(1).strip()
                    
                    sb.append(header + "\n")
                
                elif lower_header.startswith("authorization:"):
                    parts = header.split(":", 1)
                    val = parts[1].strip()
                    if len(val) > 50: val = val[:50] + "[...]"
                    sb.append(parts[0] + ": " + val + "\n")
                
                elif lower_header.startswith("cookie:"):
                    parts = header.split(":", 1)
                    val = parts[1].strip()
                    if len(val) > 50: val = val[:50] + "[...]"
                    sb.append(parts[0] + ": " + val + "\n")

            sb.append("[...]\n\n")

            body, truncated = self.processBody(requestBytes, reqInfo, reqCharset, reqContentType)
            if body:
                sb.append(body)
                if truncated: sb.append("\n[...]")
                if not body.endswith("\n"): sb.append("\n")

            sb.append("</gdscode>\n\n")

        # --- Response ---
        if responseBytes:
            respInfo = self._helpers.analyzeResponse(responseBytes)
            respHeaders = respInfo.getHeaders()
            sb.append('<gdscode language="http" hdr="Reproduction Response">\n')
            
            if respHeaders.size() > 0:
                sb.append(respHeaders.get(0) + "\n")

            respCharset = "UTF-8"
            respContentType = ""

            for i in range(1, respHeaders.size()):
                header = respHeaders.get(i)
                if header.lower().startswith("content-type:"):
                    respContentType = header.split(":", 1)[1].strip() # Use this for JSON check later
                    sb.append(header + "\n")
                    match = re.search('charset=([^;]+)', header, re.IGNORECASE)
                    if match: respCharset = match.group(1).strip()
                elif header.lower().startswith("content-length:"):
                    sb.append(header + "\n")

            sb.append("[...]\n\n")

            # Check inferred mime type as backup for response
            inferredType = respInfo.getInferredMimeType()
            if inferredType and "json" in inferredType.lower():
                # If header didn't specify it, use inferred for processing
                if not "json" in respContentType.lower():
                    respContentType = "application/json"

            body, truncated = self.processBody(responseBytes, respInfo, respCharset, respContentType)
            if body:
                sb.append(body)
                if truncated: sb.append("\n[...]")
                if not body.endswith("\n"): sb.append("\n")
            
            sb.append("</gdscode>\n")
        
        return "".join(sb)


class MarkdownFormatterTab(BaseFormatterTab):
    def getTabCaption(self):
        return "Markdown Formatter"

    def formatReport(self, requestBytes, responseBytes):
        sb = []

        # --- Request ---
        if requestBytes:
            reqInfo = self._helpers.analyzeRequest(requestBytes)
            reqHeaders = reqInfo.getHeaders()
            
            sb.append("Reproduction Request:\n")
            sb.append("```\n")

            if reqHeaders.size() > 0:
                sb.append(reqHeaders.get(0) + "\n")

            reqCharset = "UTF-8"
            reqContentType = ""

            for i in range(1, reqHeaders.size()):
                header = reqHeaders.get(i)
                lower_header = header.lower()
                
                if (lower_header.startswith("host:") or 
                    lower_header.startswith("content-type:") or 
                    lower_header.startswith("x-amz-target:")):
                    
                    if lower_header.startswith("content-type:"):
                        reqContentType = header.split(":", 1)[1].strip()
                        match = re.search('charset=([^;]+)', header, re.IGNORECASE)
                        if match: reqCharset = match.group(1).strip()
                    
                    sb.append(header + "\n")
                
                elif lower_header.startswith("authorization:"):
                    parts = header.split(":", 1)
                    val = parts[1].strip()
                    if len(val) > 50: val = val[:50] + "[...REDACTED...]" # Markdown specific redaction marker
                    sb.append(parts[0] + ": " + val + "\n")
                
                elif lower_header.startswith("cookie:"):
                    parts = header.split(":", 1)
                    val = parts[1].strip()
                    if len(val) > 50: val = val[:50] + "[...REDACTED...]"
                    sb.append(parts[0] + ": " + val + "\n")

            sb.append("[...]\n\n")

            body, truncated = self.processBody(requestBytes, reqInfo, reqCharset, reqContentType)
            if body:
                sb.append(body)
                if truncated: sb.append("\n[...]") # Keep simple marker inside block, or use REDACTED if preferred
                if not body.endswith("\n"): sb.append("\n")

            sb.append("```\n\n")

        # --- Response ---
        if responseBytes:
            respInfo = self._helpers.analyzeResponse(responseBytes)
            respHeaders = respInfo.getHeaders()
            
            sb.append("Reproduction Response:\n")
            sb.append("```\n")

            if respHeaders.size() > 0:
                sb.append(respHeaders.get(0) + "\n")

            respCharset = "UTF-8"
            respContentType = ""

            for i in range(1, respHeaders.size()):
                header = respHeaders.get(i)
                if header.lower().startswith("content-type:"):
                    respContentType = header.split(":", 1)[1].strip()
                    sb.append(header + "\n")
                    match = re.search('charset=([^;]+)', header, re.IGNORECASE)
                    if match: respCharset = match.group(1).strip()
                elif header.lower().startswith("content-length:"):
                    sb.append(header + "\n")

            sb.append("[...]\n\n")

            inferredType = respInfo.getInferredMimeType()
            if inferredType and "json" in inferredType.lower():
                if not "json" in respContentType.lower():
                    respContentType = "application/json"

            body, truncated = self.processBody(responseBytes, respInfo, respCharset, respContentType)
            if body:
                sb.append(body)
                if truncated: sb.append("\n[...REDACTED...]") # Using the style requested
                if not body.endswith("\n"): sb.append("\n")

            sb.append("```\n")

        return "".join(sb)