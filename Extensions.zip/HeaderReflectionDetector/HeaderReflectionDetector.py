# -*- coding: utf-8 -*-
from burp import (IBurpExtender, IScannerCheck, IScanIssue, IParameter,
                  IRequestInfo, IResponseInfo)
from java.net import URL
import array
import cgi # Use cgi for Python 2.x Jython compatibility

# --- Constants ---

# Minimum length of reflected input to report (reduce noise)
MIN_URL_QUERY_INPUT_LENGTH = 5
MIN_REQUEST_HEADER_INPUT_LENGTH = 5

# Common tracking/analytics query parameter names (lowercase)
IGNORED_PARAM_NAMES_EXACT = {
    "gclid", # Google Click Identifier
    "fbclid", # Facebook Click Identifier
    "msclkid", # Microsoft Click Identifier
    "dclid", # Google Display Click Identifier
    "mc_cid", # Mailchimp Campaign ID
    "mc_eid", # Mailchimp Email ID
    "_ga", # Google Analytics Client ID (Older)
    "_gl", # Google Analytics Linker Param
    "yclid", # Yandex Click ID
    "zanpid", # Zanox Affiliate ID
    "cjevent", # Commission Junction Event ID
    "irclickid" # Impact Radius Click ID
}
# Common tracking/analytics query parameter prefixes (lowercase)
IGNORED_PARAM_NAMES_PREFIXES = (
    "utm_", # Urchin Tracking Module (source, medium, campaign, term, content)
    "pk_", # Matomo (formerly Piwik) campaign, keyword
    "piwik_", # Piwik (legacy) campaign, keyword
    "matomo_", # Matomo campaign, keyword, content, etc.
    "mkevt_", # Marketo
    "trk_", # General tracking prefix sometimes used
)

# Response Headers to ignore (case-insensitive), excluding Set-Cookie
IGNORED_RESPONSE_HEADERS = {
    "content-type", "content-length", "cache-control", "date",
    "strict-transport-security", "expires", "pragma", "server",
    "connection", "transfer-encoding", "vary", "accept-ranges",
    "age", "etag", "last-modified", "location", "retry-after",
    "x-frame-options", "x-content-type-options", "x-xss-protection",
    "content-security-policy", "content-security-policy-report-only",
    "referrer-policy", "feature-policy", "permissions-policy",
    "cross-origin-opener-policy", "cross-origin-resource-policy",
    "cross-origin-embedder-policy", "access-control-allow-origin",
    "access-control-allow-credentials", "access-control-expose-headers",
    "access-control-max-age", "access-control-allow-methods",
    "access-control-allow-headers", "x-powered-by", "via", "alt-svc",
    "keep-alive", "content-language", "p3p", "priority", "upgrade",
    "sec-websocket-protocol" # Added as requested
}

# Request Headers to ignore (case-insensitive) when checking for reflection source
IGNORED_REQUEST_HEADERS = {
    "host", "user-agent", "accept", "accept-language", "accept-encoding",
    "referer", "connection", "cookie", "content-length", "content-type",
    "cache-control", "origin", "upgrade-insecure-requests", "dnt", "te",
    "authorization", "proxy-authorization", "if-modified-since", "if-none-match",
    "sec-ch-ua", "sec-ch-ua-mobile", "sec-ch-ua-platform",
    "sec-fetch-site", "sec-fetch-mode", "sec-fetch-user", "sec-fetch-dest",
    "access-control-request-method", "upgrade", "expect", "from",
    "max-forwards", "proxy-connection", "via", "x-requested-with",
    "x-http-method-override"
}

# --- Burp Extender Class ---
class BurpExtender(IBurpExtender, IScannerCheck):

    # registerExtenderCallbacks remains the same...
    def registerExtenderCallbacks(self, callbacks):
        self._callbacks = callbacks
        self._helpers = callbacks.getHelpers()
        callbacks.setExtensionName("Header Reflection Detector") # Updated name
        callbacks.registerScannerCheck(self)
        print("Header Reflection Detector loaded.")
        return

    # --- Helper to find Request Header Value offsets ---
    def calculate_request_header_value_indices(self, raw_request_bytes, req_info, header_str_to_find, header_value_str):
        """Calculates start/end indices of header_value_str within the specific header_str_to_find in the raw request."""
        start_abs = -1
        end_abs = -1
        try:
            # 1. Find the full header line in the request headers section
            request_headers_bytes = raw_request_bytes[:req_info.getBodyOffset()]
            header_line_bytes = self._helpers.stringToBytes(header_str_to_find)
            header_start_index = self._helpers.indexOf(request_headers_bytes, header_line_bytes, True, 0, len(request_headers_bytes))

            if header_start_index != -1:
                # 2. Find the start of the value within that line
                # Find the colon separator within the header line bytes
                separator_index_relative = -1
                for i in range(len(header_line_bytes)):
                    if header_line_bytes[i] == ord(':'):
                        separator_index_relative = i
                        break

                if separator_index_relative != -1:
                    value_bytes = self._helpers.stringToBytes(header_value_str)
                    value_start_relative = self._helpers.indexOf(header_line_bytes, value_bytes, True, separator_index_relative + 1, len(header_line_bytes))

                    if value_start_relative != -1:
                         start_abs = header_start_index + value_start_relative
                         end_abs = start_abs + len(value_bytes)

        except Exception as e:
            print("Error calculating request header value index for value '{}' in header '{}': {}".format(header_value_str, header_str_to_find, e))

        return start_abs, end_abs


    # --- Main Scan Logic ---
    def doPassiveScan(self, baseRequestResponse):
        issues = []
        request_bytes = baseRequestResponse.getRequest() # Get raw bytes early
        response_bytes = baseRequestResponse.getResponse()

        if response_bytes is None or request_bytes is None:
            return None

        req_info = self._helpers.analyzeRequest(baseRequestResponse) # Analyze using the service/bytes
        resp_info = self._helpers.analyzeResponse(response_bytes)
        url = req_info.getUrl()

        # --- 1. Gather Inputs AND their Source Locations ---
        # Stores tuples: (source_type_str, value, req_start_offset, req_end_offset, name_or_None)
        source_inputs = []

        # 1a. Process URL Query Parameters
        params = req_info.getParameters()
        for param in params:
            if param.getType() == IParameter.PARAM_URL:
                param_name = param.getName()
                param_name_lower = param_name.lower()
                is_ignored = False
                if param_name_lower in IGNORED_PARAM_NAMES_EXACT: is_ignored = True
                else:
                    for prefix in IGNORED_PARAM_NAMES_PREFIXES:
                        if param_name_lower.startswith(prefix): is_ignored = True; break

                if not is_ignored:
                    value = param.getValue()
                    if value and len(value) >= MIN_URL_QUERY_INPUT_LENGTH:
                         # Get offsets directly from IParameter
                         start = param.getValueStart()
                         end = param.getValueEnd()
                         source_inputs.append(("URL Query Param", value, start, end, param_name))

        # 1b. Process Custom Request Headers
        request_headers = req_info.getHeaders() # Get header strings
        for header_str in request_headers:
            if ':' not in header_str: continue
            parts = header_str.split(':', 1)
            req_header_name = parts[0].strip()
            req_header_value = parts[1].strip() # This is the value we'll check

            # Check if header is NOT ignored AND value meets minimum length
            if req_header_name.lower() not in IGNORED_REQUEST_HEADERS and len(req_header_value) >= MIN_REQUEST_HEADER_INPUT_LENGTH:
                # Calculate offsets of the value within the raw request
                start, end = self.calculate_request_header_value_indices(request_bytes, req_info, header_str, req_header_value)
                source_inputs.append(("Request Header", req_header_value, start, end, req_header_name))


        # If no relevant inputs found, exit
        if not source_inputs:
            return None

        # --- 2. Analyze Response Headers for Reflections ---
        response_headers = resp_info.getHeaders()
        # Stores tuples: (source_type, source_name, input_val, resp_header_str, req_start, req_end, resp_start, resp_end)
        found_reflections = []

        for resp_header_str in response_headers:
            if ':' not in resp_header_str: continue
            resp_header_name = resp_header_str.split(':', 1)[0].strip()
            resp_header_name_lower = resp_header_name.lower()
            should_scan_header = (resp_header_name_lower == "set-cookie" or
                                  resp_header_name_lower not in IGNORED_RESPONSE_HEADERS)

            if should_scan_header:
                # Check all collected source inputs against this response header
                for source_type, input_val, req_start, req_end, input_name in source_inputs:
                     if input_val in resp_header_str: # Check reflection
                        # Calculate response indices
                        resp_start, resp_end = self.calculate_reflection_indices(baseRequestResponse, resp_info, resp_header_str, input_val)
                        # Store more structured data
                        found_reflections.append((source_type, input_name, input_val, resp_header_str, req_start, req_end, resp_start, resp_end))


        # --- 3. Report Issue if Reflections Found ---
        if found_reflections:
            # --- START: Dynamic Title Generation ---
            # Get details from the *first* reflection found to build the title
            first_reflection = found_reflections[0]
            # Unpack the source name and response header string
            _, source_name, _, resp_header_str, _, _, _, _ = first_reflection

            # Get the destination header name
            dest_header_name = resp_header_str.split(':', 1)[0].strip()

            # Construct the new, dynamic issue title using a pipe
            issue_title = "Response Header Reflected: \"{} | {}\"".format(source_name, dest_header_name)
            # --- END: Dynamic Title Generation ---

            issue_detail_parts = ["Reflections found:<ul>"]
            request_markers = []
            response_markers = []
            unique_reported_reflections = set() # Avoid duplicate list items

            for source_type, source_name, input_val, resp_header_str, req_start, req_end, resp_start, resp_end in found_reflections:
                # Build source description for the details list
                if source_type == "Request Header":
                    source_description = "Request Header '{}'".format(source_name)
                else: # URL Query Param
                    source_description = "URL Query Param '{}'".format(source_name)

                report_key = (source_description, input_val, resp_header_str)
                if report_key not in unique_reported_reflections:
                    issue_detail_parts.append("<li>Source: {} | Input: <code>{}</code> reflected in Header: <code>{}</code></li>".format(
                        cgi.escape(source_description), cgi.escape(input_val), cgi.escape(resp_header_str)
                    ))
                    unique_reported_reflections.add(report_key)

                # Add markers if indices are valid
                if req_start != -1 and req_end != -1:
                    request_markers.append(array.array('i', [req_start, req_end]))
                if resp_start != -1 and resp_end != -1:
                     response_markers.append(array.array('i', [resp_start, resp_end]))

            # Deduplicate markers
            unique_req_markers = {tuple(marker) for marker in request_markers}
            final_request_markers = [array.array('i', m) for m in unique_req_markers]
            unique_resp_markers = {tuple(marker) for marker in response_markers}
            final_response_markers = [array.array('i', m) for m in unique_resp_markers]

            issue_detail_parts.append("</ul>")

            # Apply markers to BOTH request and response
            marked_request_response = self._callbacks.applyMarkers(baseRequestResponse, final_request_markers, final_response_markers)

            issues.append(CustomScanIssue(
                baseRequestResponse.getHttpService(), url,
                [marked_request_response],
                issue_title, # Pass the new dynamic title
                "".join(issue_detail_parts),
                "Medium", "Firm"
            ))

        return issues if issues else None

    # calculate_reflection_indices helper function remains the same...
    def calculate_reflection_indices(self, baseRequestResponse, resp_info, header_str, input_val):
        start_abs = -1
        end_abs = -1
        try:
            response_bytes = baseRequestResponse.getResponse()
            response_headers_bytes = response_bytes[:resp_info.getBodyOffset()]
            header_bytes = self._helpers.stringToBytes(header_str)
            header_start_index = self._helpers.indexOf(response_headers_bytes, header_bytes, True, 0, len(response_headers_bytes))
            if header_start_index != -1:
                input_bytes = self._helpers.stringToBytes(input_val)
                reflection_start_in_header_bytes = self._helpers.indexOf(header_bytes, input_bytes, True, 0, len(header_bytes))
                if reflection_start_in_header_bytes != -1:
                    start_abs = header_start_index + reflection_start_in_header_bytes
                    end_abs = start_abs + len(input_bytes)
        except Exception as e:
            print("Error calculating response reflection index for input '{}' in header '{}': {}".format(input_val, header_str, e))
        return start_abs, end_abs

    # consolidateDuplicateIssues remains the same...
    def consolidateDuplicateIssues(self, existingIssue, newIssue):
        # We can now make consolidation more specific if we want
        # For now, let's keep it simple. If titles are different, they are different issues.
        if existingIssue.getIssueName() == newIssue.getIssueName() and \
           existingIssue.getUrl().getPath() == newIssue.getUrl().getPath():
            return -1 # Keep existing issue
        return 0

# CustomScanIssue class remains the same...
class CustomScanIssue(IScanIssue):
    def __init__(self, httpService, url, httpMessages, name, detail, severity, confidence):
        self._httpService = httpService
        self._url = url
        self._httpMessages = httpMessages
        self._name = name
        self._detail = detail
        self._severity = severity
        self._confidence = confidence
    def getUrl(self): return self._url
    def getIssueName(self): return self._name
    def getIssueType(self): return 0
    def getSeverity(self): return self._severity
    def getConfidence(self): return self._confidence
    def getIssueBackground(self): return None
    def getRemediationBackground(self): return None
    def getIssueDetail(self): return self._detail
    def getRemediationDetail(self): return None
    def getHttpMessages(self): return self._httpMessages
    def getHttpService(self): return self._httpService
