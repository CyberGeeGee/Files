from flask import Flask, request, make_response
from markupsafe import escape
import os # Used for a slightly more unique default value

app = Flask(__name__)

# --- Helper Function to create a response ---
# (Using the same helper function as you provided)
def create_response(text, status_code=200, headers=None, cookies=None):
    """Creates a Flask response object."""
    response = make_response(text, status_code)
    if headers:
        for key, value in headers.items():
            # WARNING: Unsafe reflection for testing only!
            try:
                if key.lower() != 'set-cookie':
                     response.headers.set(key, value)
            except Exception as e:
                print(f"Warning: Could not set header '{key}': {e}")

    if cookies:
        for key, value in cookies.items():
            # WARNING: Unsafe reflection for testing only!
             response.set_cookie(key, value)

    response.headers.set("X-Test-App", "Header-Reflection-Tester-V2")
    return response

# --- Routes for Testing ---

@app.route('/')
def index():
    """Homepage - Updated with new test cases."""
    # Note: Changed port in help text to 8888 as used in your app.run call
    body = """
    <h1>Header Reflection Test App V2</h1>
    <p>Use Burp Suite with the Header Reflection Detector extension (V2) to test these endpoints:</p>
    <h2>URL Parameter/Path Reflection Tests:</h2>
    <ul>
        <li><a href="/reflect_set_cookie?data=TestCookieValue123">/reflect_set_cookie?data=...</a> (Reflects 'data' in Set-Cookie value)</li>
        <li><a href="/reflect_custom_header_value?input=CustomValue987">/reflect_custom_header_value?input=...</a> (Reflects 'input' in X-User-Input value)</li>
        <li><a href="/reflect_custom_header_name?name=DynamicHeaderPart">/reflect_custom_header_name?name=...</a> (Reflects 'name' in X-Dynamic-[name] header name)</li>
        <li><a href="/reflect_path/From_URL_Path_Segment">/reflect_path/...</a> (Reflects path segment in X-Path-Reflected header value)</li>
        <li><a href="/reflect_in_ignored?ignored_input=IgnoredStuff">/reflect_in_ignored?ignored_input=...</a> (Reflects URL input in 'Server' header - SHOULD NOT BE FLAGGED)</li>
    </ul>
    <h2>Request Header Reflection Tests (Use Burp Repeater or similar):</h2>
    <p>These require manually adding specific request headers.</p>
    <ul>
        <li><b>/reflect_request_header</b>:
            <ul>
                <li>Add header <code>X-Correlation-ID: CORR_ID_123</code> -> Should reflect in <code>X-Reflected-Correlation</code> response header (FLAG).</li>
                <li>Add header <code>X-Session-Hint: Hint_ABC</code> -> Should reflect in <code>session_hint_cookie</code> Set-Cookie value (FLAG).</li>
                <li>Add header <code>X-Debug-Info: DebugData999</code> -> Should reflect in <code>Server</code> response header (NO FLAG - ignored target).</li>
            </ul>
        </li>
        <li><b>/reflect_ignored_request_header</b>:
            <ul>
                <li>Send with standard <code>User-Agent: TestAgent/1.0</code> -> Reflects User-Agent in <code>X-Ignored-Source-Test</code> (NO FLAG - ignored source).</li>
            </ul>
        </li>
        <li><b>/reflect_multiple?path_input=Segment1&query_input=Query1</b>:
             <ul>
                <li>Add header <code>X-Trace-ID: TraceXYZ</code> -> Reflects URL path, URL query, *and* Request Header X-Trace-ID into different response headers/cookies (ALL 3 SHOULD FLAG).</li>
            </ul>
        </li>
    </ul>
    <p><b>Note:</b> Refreshing pages might send cached requests without custom headers. Use Repeater for precise control of request headers.</p>
    """
    return create_response(body)

# --- Existing URL Reflection Routes (Unchanged unless noted) ---

@app.route('/reflect_set_cookie')
def reflect_set_cookie():
    user_data = request.args.get('data', 'DefaultData')
    body = f"Reflecting URL Param 'data'='{escape(user_data)}' in Set-Cookie header value."
    cookies = {'reflected_data_cookie': user_data}
    return create_response(body, cookies=cookies)

@app.route('/reflect_custom_header_value')
def reflect_custom_header_value():
    user_input = request.args.get('input', 'DefaultInput')
    body = f"Reflecting URL Param 'input'='{escape(user_input)}' in X-User-Input header value."
    headers = {'X-User-Input': f'Value was: {user_input}'}
    return create_response(body, headers=headers)

@app.route('/reflect_custom_header_name')
def reflect_custom_header_name():
    header_name_part = request.args.get('name', 'DefaultNamePart')
    safe_name_part = "".join(c for c in header_name_part if c.isalnum() or c in ['-'])
    if not safe_name_part: safe_name_part = "InvalidCharsRemoved"
    custom_header_name = f'X-Dynamic-{safe_name_part}'
    body = f"Reflecting URL Param 'name'='{escape(header_name_part)}' into header name: {escape(custom_header_name)}"
    headers = {custom_header_name: 'StaticValue'}
    return create_response(body, headers=headers)

@app.route('/reflect_path/<path:path_segment>')
def reflect_path(path_segment):
    body = f"Reflecting path segment '{escape(path_segment)}' in X-Path-Reflected header value."
    headers = {'X-Path-Reflected': f'Path data: {path_segment}'}
    return create_response(body, headers=headers)

@app.route('/reflect_in_ignored')
def reflect_in_ignored():
    """Reflects URL param AND a custom request header into an IGNORED response header."""
    ignored_data_url = request.args.get('ignored_input', 'DefaultIgnoredURL')
    # Also check for a custom request header to reflect into the ignored response header
    ignored_data_header = request.headers.get('X-Ignored-Source', 'DefaultIgnoredHeader')

    body = f"Reflecting URL Param 'ignored_input'='{escape(ignored_data_url)}' AND Request Header 'X-Ignored-Source'='{escape(ignored_data_header)}' into 'Server' header. Neither should trigger the extension."
    # Combine reflections into the ignored header
    headers = {'Server': f'TestServer reflecting URL: {ignored_data_url} AND Header: {ignored_data_header}'}
    return create_response(body, headers=headers)

# --- New/Modified Routes for Request Header Reflection ---

@app.route('/reflect_request_header')
def reflect_request_header():
    """
    Tests reflection of CUSTOM request headers into various response headers.
    Requires manual setting of request headers (e.g., via Repeater).
    """
    # 1. Reflect X-Correlation-ID -> X-Reflected-Correlation (Custom -> Custom) - SHOULD FLAG
    correlation_id = request.headers.get('X-Correlation-ID', 'DefaultCorrID' + os.urandom(4).hex())
    headers = {'X-Reflected-Correlation': f'Processed {correlation_id}'}

    # 2. Reflect X-Session-Hint -> Set-Cookie (Custom -> Set-Cookie) - SHOULD FLAG
    session_hint = request.headers.get('X-Session-Hint', 'DefaultHint' + os.urandom(4).hex())
    cookies = {'session_hint_cookie': f'HintValue_{session_hint}'}

    # 3. Reflect X-Debug-Info -> Server (Custom -> Ignored Response Header) - SHOULD NOT FLAG
    debug_info = request.headers.get('X-Debug-Info', 'DefaultDebug' + os.urandom(4).hex())
    # Append to Server header (which is ignored by the extension)
    headers['Server'] = f'TestServer reflecting debug: {debug_info}'

    body = f"""
    Testing Request Header Reflections:<br/>
    - X-Correlation-ID ('{escape(correlation_id)}') reflected in X-Reflected-Correlation? -> Check Response Headers (Should Flag)<br/>
    - X-Session-Hint ('{escape(session_hint)}') reflected in session_hint_cookie? -> Check Response Headers (Should Flag)<br/>
    - X-Debug-Info ('{escape(debug_info)}') reflected in Server? -> Check Response Headers (Should NOT Flag)<br/>
    <br/>Use Burp Repeater to send requests with these headers set.
    """
    return create_response(body, headers=headers, cookies=cookies)

@app.route('/reflect_ignored_request_header')
def reflect_ignored_request_header():
    """Reflects an IGNORED request header (User-Agent) into a custom response header."""
    ua_string = request.headers.get('User-Agent', 'DefaultUA')
    body = f"Reflecting ignored request header 'User-Agent'='{escape(ua_string)}' into 'X-Ignored-Source-Test'. This should NOT trigger the extension."
    headers = {'X-Ignored-Source-Test': f'UA was: {ua_string}'}
    return create_response(body, headers=headers)

@app.route('/reflect_multiple')
def reflect_multiple():
    """Reflects URL path, URL query, AND a custom request header."""
    path_data = request.args.get('path_input', 'DefaultPathMulti')
    query_data = request.args.get('query_input', 'DefaultQueryMulti')
    trace_id = request.headers.get('X-Trace-ID', 'DefaultTrace' + os.urandom(4).hex()) # Get custom header

    body = f"""
    Reflecting multiple sources:<br/>
    - URL Param 'path_input'='{escape(path_data)}' in X-Multi-Path header.<br/>
    - URL Param 'query_input'='{escape(query_data)}' in multi_cookie (Set-Cookie).<br/>
    - Request Header 'X-Trace-ID'='{escape(trace_id)}' in X-Multi-Trace header.<br/>
    All three reflections should be flagged by the extension in a single issue.
    """

    headers = {
        'X-Multi-Path': f'Reflected path param: {path_data}',
        'X-Multi-Trace': f'Reflected trace ID: {trace_id}' # Reflect trace ID here
    }
    cookies = {'multi_cookie': query_data} # Reflect query param here

    return create_response(body, headers=headers, cookies=cookies)


# --- Run the App ---
if __name__ == '__main__':
    print("Starting Flask test server on http://127.0.0.1:8888") # Using port 8888 from your example
    print("WARNING: This app reflects user input unsafely for testing purposes ONLY.")
    print("Do NOT use this pattern in production applications.")
    app.run(host='0.0.0.0', port=8888, debug=False) # Changed port to 8888