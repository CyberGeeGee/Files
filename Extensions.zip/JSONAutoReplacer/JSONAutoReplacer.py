# -*- coding: utf-8 -*-
# Important: Ensure Jython 2.7 Standalone JAR is configured in Burp's Python Environment.

from burp import IBurpExtender, IHttpListener, ITab
from javax.swing import (JPanel, JSplitPane, JTextArea, JScrollPane,
                         JTextField, JLabel, JButton, JToggleButton, # Added JToggleButton
                         BoxLayout, Box, BorderFactory, SwingUtilities,
                         UIManager)
from java.awt import BorderLayout, FlowLayout, Dimension, Color
from javax.swing.event import DocumentListener
from java.io import PrintWriter
from java.lang import Runnable, String
from java.nio.charset import StandardCharsets, Charset
from java.util import ArrayList, Arrays
import re # For charset detection
import traceback # For better error logging

# --- Configuration Constants ---
SETTING_TARGET_KEYWORDS = "json_autoreplacer_keywords_py"
SETTING_APPEND_STRING = "json_autoreplacer_append_string_py"
SETTING_ENABLED_STATE = "json_autoreplacer_enabled_state_py" # New setting key
DEFAULT_APPEND_STRING = u"<img src=1>" # Make default unicode
DEFAULT_KEYWORDS = ["xpto","gdssecurity","AonTest"]
DEFAULT_ENABLED_STATE = True # Default to enabled
EXTENSION_NAME = "JSON AutoReplacer"

class BurpExtender(IBurpExtender, IHttpListener, ITab, DocumentListener):

    _callbacks = None
    _helpers = None
    _stdout = None
    _stderr = None

    # Configuration state
    targetKeywords = []
    appendString = DEFAULT_APPEND_STRING
    isEnabled = DEFAULT_ENABLED_STATE # <-- Added state variable

    # UI Elements (initialized in buildUi)
    _mainPanel = None
    _keywordsTextArea = None
    _appendTextField = None
    _statusLabel = None
    _toggleButton = None # <-- Added toggle button reference

    # Flag to prevent listener loops
    _isUpdating = False

    def registerExtenderCallbacks(self, callbacks):
        self._callbacks = callbacks
        self._helpers = callbacks.getHelpers()
        # Use try-with-resources equivalent if available, otherwise manual flush/close needed on unload
        self._stdout = PrintWriter(callbacks.getStdout(), True)
        self._stderr = PrintWriter(callbacks.getStderr(), True)

        self._callbacks.setExtensionName(EXTENSION_NAME)
        self._stdout.println("{} Loading...".format(EXTENSION_NAME))

        # --- Initialize Configuration ---
        self.loadSettings() # Load includes the enabled state now

        # --- Build UI (must run on EDT) ---
        # Use invokeLater to ensure UI setup happens on the EDT correctly
        SwingUtilities.invokeLater(self.buildUi)

        # --- Register Listeners ---
        callbacks.registerHttpListener(self)
        # Add Suite Tab is handled within buildUi after panel creation

        self._stdout.println("Initial Keywords: {}".format(", ".join(self.targetKeywords)))
        self._stdout.println("Initial Append String: {}".format(self.appendString))
        self._stdout.println("Initial State: {}".format("Enabled" if self.isEnabled else "Disabled"))
        self._stdout.println("Initialization Complete")

    # ===========================================================================
    # Settings Management
    # ===========================================================================

    def loadSettings(self):
        """Loads settings from Burp's persistence."""
        self._stdout.println("Loading settings...")
        try:
            # Load Keywords
            savedKeywordsStr = self._callbacks.loadExtensionSetting(SETTING_TARGET_KEYWORDS)
            if savedKeywordsStr:
                self.targetKeywords = [kw.strip() for kw in savedKeywordsStr.splitlines() if kw.strip()]
            else:
                self.targetKeywords = list(DEFAULT_KEYWORDS) # Use list() for mutable copy

            if not self.targetKeywords: # Ensure default if loading resulted in empty
                 self.targetKeywords = list(DEFAULT_KEYWORDS)

            # Load Append String
            savedAppendStr = self._callbacks.loadExtensionSetting(SETTING_APPEND_STRING)
            if savedAppendStr is not None:
                self.appendString = unicode(savedAppendStr) # Convert Java String to Python unicode
            else:
                self.appendString = DEFAULT_APPEND_STRING

            # Load Enabled State <--- NEW
            savedEnabledStateStr = self._callbacks.loadExtensionSetting(SETTING_ENABLED_STATE)
            if savedEnabledStateStr is not None:
                self.isEnabled = savedEnabledStateStr.lower() == 'true'
            else:
                self.isEnabled = DEFAULT_ENABLED_STATE # Default if nothing saved

            self._stdout.println("Settings Loaded (Enabled: {}).".format(self.isEnabled))

            # Update UI elements if they exist (must run on EDT)
            def updateUiElements():
                self._isUpdating = True # Prevent listener loops
                try:
                    if hasattr(self, '_appendTextField') and self._appendTextField:
                        self._appendTextField.setText(self.appendString)
                    if hasattr(self, '_keywordsTextArea') and self._keywordsTextArea:
                        self._keywordsTextArea.setText("\n".join(self.targetKeywords))
                    if hasattr(self, '_toggleButton') and self._toggleButton:
                        self._updateToggleButtonState() # Update toggle button appearance
                finally:
                    self._isUpdating = False

            if SwingUtilities.isEventDispatchThread():
                 updateUiElements()
            else:
                 SwingUtilities.invokeLater(updateUiElements)

        except Exception as e:
            self._stderr.println("Error loading settings: {}".format(e))
            traceback.print_exc(file=self._stderr)


    def saveSettings(self):
        """Saves settings using Burp's persistence."""
        try:
            keywordsStr = "\n".join(self.targetKeywords)
            self._callbacks.saveExtensionSetting(SETTING_TARGET_KEYWORDS, keywordsStr)
            # Ensure appendString is saved correctly (even if empty)
            self._callbacks.saveExtensionSetting(SETTING_APPEND_STRING, self.appendString)
            # Save Enabled State <--- NEW
            self._callbacks.saveExtensionSetting(SETTING_ENABLED_STATE, str(self.isEnabled).lower())

            self._stdout.println("Settings Saved (Enabled: {}).".format(self.isEnabled))
            self.updateStatus("Settings saved.", False)
        except Exception as e:
            self._stderr.println("Error saving settings: {}".format(e))
            traceback.print_exc(file=self._stderr)
            self.updateStatus("Error saving settings: {}".format(e), True)


    # ===========================================================================
    # UI Creation and Management (ITab)
    # ===========================================================================

    def buildUi(self):
        """Builds the extension's UI components. Must run on EDT."""
        self._mainPanel = JSplitPane(JSplitPane.VERTICAL_SPLIT)
        self._mainPanel.setResizeWeight(0.7) # Give more space to keywords

        # --- Top Panel: Target Keywords ---
        topPanel = JPanel(BorderLayout(5, 5))
        topPanel.setBorder(BorderFactory.createTitledBorder("Target Keywords (one per line)"))
        self._keywordsTextArea = JTextArea("\n".join(self.targetKeywords))
        self._keywordsTextArea.getDocument().addDocumentListener(self) # Listen for changes
        keywordsScrollPane = JScrollPane(self._keywordsTextArea)
        topPanel.add(keywordsScrollPane, BorderLayout.CENTER)

        # --- Bottom Panel: Configuration and Status ---
        bottomPanel = JPanel(BorderLayout(5, 5))
        bottomPanel.setBorder(BorderFactory.createTitledBorder("Configuration & Status"))

        # --- Config Sub-Panel (Toggle, Append String) ---
        configPanel = JPanel(FlowLayout(FlowLayout.LEFT))

        # Enable/Disable Toggle Button <--- NEW
        self._toggleButton = JToggleButton(actionPerformed=self._toggleEnableDisable)
        self._updateToggleButtonState() # Set initial text/state based on loaded settings
        configPanel.add(self._toggleButton)
        configPanel.add(Box.createHorizontalStrut(10)) # Add some spacing

        # Append String
        configPanel.add(JLabel("Append String:"))
        self._appendTextField = JTextField(self.appendString, 30)
        self._appendTextField.getDocument().addDocumentListener(self) # Listen for changes
        configPanel.add(self._appendTextField)

        # Status Label
        self._statusLabel = JLabel("Status: Initialized.")
        self._statusLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5))

        bottomPanel.add(configPanel, BorderLayout.NORTH)
        bottomPanel.add(self._statusLabel, BorderLayout.SOUTH)

        # --- Assemble Main Pane ---
        self._mainPanel.setTopComponent(topPanel)
        self._mainPanel.setBottomComponent(bottomPanel)

        # Add the custom tab to Burp's UI
        # Ensure callbacks is valid before adding tab
        if self._callbacks:
             self._callbacks.addSuiteTab(self)
             self._stdout.println("UI Initialized and Tab Added")
        else:
             self._stderr.println("Error: Callbacks not initialized before adding Suite Tab.")


    # --- ITab methods ---
    def getTabCaption(self):
        # Per user request, use the extension name for the tab caption
        # If you want a specific fixed name, uncomment the line below
        # return "AutoReplacer (JSON)"
        return EXTENSION_NAME # Use the defined constant

    def getUiComponent(self):
        return self._mainPanel

    # --- DocumentListener methods (for auto-save) ---
    def _updateFromDocument(self, event):
        """Handles text changes in Keywords or Append String fields."""
        if self._isUpdating: # Prevent recursion during programmatic updates
            return

        # Run update logic on EDT to be safe, although listeners usually are.
        def runUpdate():
            source = event.getDocument()
            try:
                saveNeeded = False
                if hasattr(self, '_keywordsTextArea') and source == self._keywordsTextArea.getDocument():
                    keywordsStr = self._keywordsTextArea.getText()
                    # Update internal list, removing empty lines
                    newKeywords = [kw.strip() for kw in keywordsStr.splitlines() if kw.strip()]
                    if newKeywords != self.targetKeywords:
                         self.targetKeywords = newKeywords
                         self._stdout.println("Keywords updated from UI: {}".format(", ".join(self.targetKeywords)))
                         saveNeeded = True
                elif hasattr(self, '_appendTextField') and source == self._appendTextField.getDocument():
                    # getText() returns Java String, convert to Python unicode
                    newAppendString = unicode(self._appendTextField.getText())
                    if newAppendString != self.appendString:
                         self.appendString = newAppendString
                         self._stdout.println("Append string updated from UI: {}".format(self.appendString))
                         saveNeeded = True

                if saveNeeded:
                    self.saveSettings() # Auto-save if changes occurred

            except Exception as e:
                self._stderr.println("Error updating from UI document listener: {}".format(e))
                traceback.print_exc(file=self._stderr)
                self.updateStatus("Error updating settings: {}".format(e), True)

        # Schedule the update on the EDT
        SwingUtilities.invokeLater(runUpdate)


    def insertUpdate(self, event):
        self._updateFromDocument(event)

    def removeUpdate(self, event):
        self._updateFromDocument(event)

    def changedUpdate(self, event):
        # Usually not needed for plain text components
        pass

    # --- UI Action Handlers ---

    def _toggleEnableDisable(self, event):
        """Handles the toggle button click. Source event already on EDT."""
        self.isEnabled = not self.isEnabled # Flip the state
        self._updateToggleButtonState() # Update button appearance
        self.saveSettings() # Save the new state immediately
        statusMsg = "Extension Enabled." if self.isEnabled else "Extension Disabled."
        self.updateStatus(statusMsg, False)
        self._stdout.println(statusMsg)

    def _updateToggleButtonState(self):
        """Updates the toggle button's text and selected state based on self.isEnabled. Needs to run on EDT."""
        if not hasattr(self, '_toggleButton') or not self._toggleButton: # Safety check
            return

        def run():
            if self.isEnabled:
                self._toggleButton.setText("Enabled")
                self._toggleButton.setSelected(True)
                # Optional: Set color for visual cue
                # self._toggleButton.setForeground(Color.GREEN.darker())
            else:
                self._toggleButton.setText("Disabled")
                self._toggleButton.setSelected(False)
                # Optional: Set color for visual cue
                # self._toggleButton.setForeground(Color.RED)

        if SwingUtilities.isEventDispatchThread():
            run()
        else:
            # Should typically be called from EDT contexts (init, action listener)
            # but invokeLater is safer if called from elsewhere.
            SwingUtilities.invokeLater(run)


    # --- Utility to update status label safely ---
    def updateStatus(self, message, isError):
        """Updates the status label on the EDT."""
        def run():
            if hasattr(self, '_statusLabel') and self._statusLabel:
                prefix = "Status: "
                self._statusLabel.setText(prefix + message)
                self._statusLabel.setForeground(Color.RED if isError else UIManager.getColor("Label.foreground"))

        if SwingUtilities.isEventDispatchThread():
            run()
        else:
            SwingUtilities.invokeLater(run)

        # Also log to appropriate stream
        if isError:
            self._stderr.println("Status Update (Error): " + message)
        else:
            self._stdout.println("Status Update: " + message)

    # ===========================================================================
    # HTTP Processing (IHttpListener)
    # ===========================================================================

    def processHttpMessage(self, toolFlag, messageIsRequest, messageInfo):
        # --- Step 1: Check if Enabled --- <--- NEW Check
        if not self.isEnabled:
            return

        # --- Step 2: Check if Response Processing is Applicable ---
        # Only process responses
        if messageIsRequest:
            return

        # Ensure keywords are configured (shouldn't happen with defaults, but safe check)
        if not self.targetKeywords:
            return

        # Get response bytes
        responseBytes = messageInfo.getResponse()
        if responseBytes is None:
            return # No response data

        # Analyze response
        responseInfo = self._helpers.analyzeResponse(responseBytes)
        headers = responseInfo.getHeaders()
        bodyBytes = responseBytes[responseInfo.getBodyOffset():]

        if not bodyBytes: # No body to process
            return

        # --- Step 3: JSON Detection ---
        isJson = False
        statedMimeType = responseInfo.getStatedMimeType() or "" # Ensure string type
        inferredMimeType = responseInfo.getInferredMimeType() or "" # Ensure string type

        if 'json' in statedMimeType.lower():
            isJson = True
        elif 'json' in inferredMimeType.lower(): # Check inferred only if stated isn't JSON
            isJson = True
            # self._stdout.println("Detected JSON via InferredMimeType: " + inferredMimeType) # Debug

        if not isJson:
            return # Not JSON, ignore

        # --- Step 4: Determine Charset ---
        charset = StandardCharsets.UTF_8 # Default
        contentTypeHeader = ""

        # Find Content-Type header directly
        for header in headers:
             # Case-insensitive check for the header name
             if header.lower().startswith("content-type:"):
                  contentTypeHeader = header # Use the full header line
                  break

        # Extract charset from the header if found
        if contentTypeHeader:
            match = re.search(r"charset=([^;\s]+)", contentTypeHeader, re.IGNORECASE)
            if match:
                charsetName = match.group(1).strip().upper()
                try:
                    # Handle common aliases explicitly if needed
                    if charsetName == 'UTF8': charsetName = 'UTF-8'
                    # Add more aliases if required: e.g., 'WINDOWS-1252', 'ISO-8859-1' etc.
                    charset = Charset.forName(charsetName)
                    # self._stdout.println("Using charset: {}".format(charset.name())) # Debug
                except Exception as e:
                    self._stderr.println("Unsupported/Unknown charset found: '{}'. Falling back to UTF-8. Error: {}".format(charsetName, e))
                    charset = StandardCharsets.UTF_8
        # else: self._stdout.println("No charset found in headers, using default UTF-8.") # Debug

        # --- Step 5: Decode, Modify, Re-encode ---
        try:
            # Decode body using determined charset -> java.lang.String -> Python unicode
            bodyJavaString = String(bodyBytes, charset.name())
            bodyPythonString = unicode(bodyJavaString)
            originalBodyPythonString = bodyPythonString # Keep for comparison

            # Perform replacement
            modifiedBodyString = self.replaceKeywordsInJsonValues(bodyPythonString)

            # If modification occurred, update the response
            if modifiedBodyString != originalBodyPythonString:
                self.updateStatus("Replaced keywords in JSON response (Charset: {}).".format(charset.name()), False)

                # Encode modified string back to bytes using the SAME charset
                modifiedBodyJavaString = String(modifiedBodyString) # Python unicode back to Java String
                modifiedBodyBytes = modifiedBodyJavaString.getBytes(charset.name())

                # Update Content-Length header
                newHeaders = self.updateContentLength(headers, len(modifiedBodyBytes))

                # Build new response
                newResponseBytes = self._helpers.buildHttpMessage(newHeaders, modifiedBodyBytes)

                # Update the messageInfo object
                messageInfo.setResponse(newResponseBytes)
                # self._stdout.println("Response updated.") # Debug

        except UnicodeDecodeError as ude:
             self._stderr.println("Decoding Error processing JSON response body with charset '{}'. Check response encoding vs. header. Error: {}".format(charset.name(), ude))
             traceback.print_exc(file=self._stderr)
             self.updateStatus("Decoding Error: {}".format(ude), True)
        except UnicodeEncodeError as uee:
             self._stderr.println("Encoding Error processing JSON response body with charset '{}'. Check replacement string compatibility. Error: {}".format(charset.name(), uee))
             traceback.print_exc(file=self._stderr)
             self.updateStatus("Encoding Error: {}".format(uee), True)
        except Exception as e:
            self._stderr.println("General Error processing JSON response body: {}".format(e))
            traceback.print_exc(file=self._stderr)
            self.updateStatus("Error during replacement: {}".format(e), True)


    def replaceKeywordsInJsonValues(self, jsonPythonString):
        """
        Replaces target keywords found ONLY within JSON string values.
        Uses a simple state machine approach on a Python unicode string.
        """
        result = []
        inString = False
        escape = False
        n = len(jsonPythonString)
        i = 0
        appendStr = self.appendString # Use the configured string

        while i < n:
            char = jsonPythonString[i]

            if char == '"' and not escape:
                inString = not inString
                result.append(char)
                i += 1
                escape = False # Reset escape immediately after quote toggle
            elif inString:
                foundKeyword = None
                # Check potential keywords starting at current position
                for keyword in self.targetKeywords:
                    # Basic check: keyword cannot contain quotes or backslashes itself for this simple parser
                    # This is an inherent limitation of this simple approach.
                    # if '"' in keyword or '\\' in keyword: continue # Skip potentially problematic keywords

                    kw_len = len(keyword)
                    # Ensure we don't go out of bounds and check for match
                    if i + kw_len <= n and jsonPythonString[i : i + kw_len] == keyword:
                        # Check if the character *after* the keyword would terminate the string
                        # This avoids partial matches like replacing "key" in "keyword" if "key" is a target
                        # Note: This simple check might not be perfect for all edge cases
                        if i + kw_len == n or jsonPythonString[i + kw_len] in ('"', '\\'): # End of string or special char
                             foundKeyword = keyword
                             break
                        # If it's just a normal character, assume it's part of a larger word
                        # This requires more thought - maybe check for word boundaries?
                        # For now, let's allow replacement anywhere inside the string value.
                        # Reverting the boundary check for simplicity as original code did.
                        foundKeyword = keyword
                        break # Found the first matching keyword

                if foundKeyword:
                    result.append(foundKeyword)
                    result.append(appendStr) # Append the configured string
                    i += len(foundKeyword)
                    escape = False # Reset escape flag after jumping
                else:
                    # Append current char and handle escape status for the *next* iteration
                    result.append(char)
                    escape = (char == '\\' and not escape)
                    i += 1
            else: # Not in a string literal
                result.append(char)
                # Handle escape status outside strings (relevant for structure like \/ in JSON)
                escape = (char == '\\' and not escape)
                i += 1

        # Check for unterminated string (might indicate malformed JSON or parsing issue)
        if inString:
            self._stderr.println("Warning: JSON string parsing ended while inside a string literal. Input might be malformed.")

        return u"".join(result) # Ensure result is unicode


    def updateContentLength(self, headers, newLength):
        """Updates or adds the Content-Length header in a list of headers."""
        newHeaders = ArrayList()
        found = False
        clHeader = "Content-Length: {}".format(newLength)
        for header in headers:
            # Use lower() for case-insensitive comparison
            if header.lower().startswith("content-length:"):
                newHeaders.add(clHeader) # Replace with the new value
                found = True
            else:
                newHeaders.add(header) # Keep the original header
        if not found:
            newHeaders.add(clHeader) # Add if it wasn't present
        return newHeaders

# Note: Burp implicitly loads and instantiates the class named BurpExtender.