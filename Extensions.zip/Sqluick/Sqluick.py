# -*- coding: utf-8 -*-
from burp import IBurpExtender, IScannerCheck, IScanIssue, IContextMenuFactory
from java.io import PrintWriter
from javax.swing import JMenuItem
import re, time, threading
import java.awt.event.ActionListener as ActionListener

class BurpExtender(IBurpExtender, IScannerCheck, IContextMenuFactory):

    def registerExtenderCallbacks(self, callbacks):
        self._callbacks = callbacks
        self._helpers = callbacks.getHelpers()
        # Set extension name to "Sqluick"
        callbacks.setExtensionName("Sqluick")
        callbacks.registerScannerCheck(self)
        callbacks.registerContextMenuFactory(self)
        self._stdout = PrintWriter(callbacks.getStdout(), True)
        self._stderr = PrintWriter(callbacks.getStderr(), True)
        self._callbacks.printOutput("Extension loaded: Sqluick")
        # Dictionary to track scanned parameters per target.
        # For passive scans (full==False), keys: "URL" and "Cookie".
        # For full scans (full==True), keys: "URL", "Cookie", and "Body".
        self.scanned_params = {}
        return

    def doPassiveScan(self, baseRequestResponse):
        # Passive scans use the original behavior: only GET requests and only URL & Cookie.
        return self.performSqluickScan(baseRequestResponse, force=False, full=False)

    def performSqluickScan(self, baseRequestResponse, force=False, full=False):
        """
        Core scanning routine for Sqluick.
        
        In passive mode (full==False):
          • Checks that request method is GET,
          • Checks that response code is 200,
          • Checks that request is in scope,
          • And scans only URL and Cookie parameters.
        
        In Full Request Scan mode (full==True):
          • These checks are skipped,
          • All parameters (URL, Cookie, and Body) are scanned.
          • Additionally, if force is False the extension will skip a parameter
            if it was scanned before (per target and per parameter type).
          • If force is True, no such check is done.
        
        In both modes, if the original response is missing and full==True,
        the extension sends the request manually to obtain a baseline response.
        If no response is returned (e.g., due to timeout), the scan is aborted.
        
        Returns a list of IScanIssue objects (each includes the original request/response,
        the single-quote (Test1) and double-quote (Test2) results) or None.
        """
        verbose_log = []
        issues = []
        
        request = baseRequestResponse.getRequest()
        response = baseRequestResponse.getResponse()
        httpService = baseRequestResponse.getHttpService()
        analyzedRequest = self._helpers.analyzeRequest(httpService, request)
        
        # Passive mode extra checks.
        if not full:
            if analyzedRequest.getMethod() != "GET":
                verbose_log.append("Request is not GET; skipping scan.")
                self._printVerbose(verbose_log)
                return None
            if response is None:
                verbose_log.append("No response received; skipping scan.")
                self._printVerbose(verbose_log)
                return None
            analyzedResponse = self._helpers.analyzeResponse(response)
            if analyzedResponse.getStatusCode() != 200:
                verbose_log.append("Response code is not 200; skipping scan.")
                self._printVerbose(verbose_log)
                return None
            url = analyzedRequest.getUrl()
            if not self._callbacks.isInScope(url):
                verbose_log.append("Request URL " + str(url) + " is out of scope; skipping scan.")
                self._printVerbose(verbose_log)
                return None
        else:
            # In full scan mode, skip those checks.
            url = analyzedRequest.getUrl()
        
        # For full scan mode, if baseline response is missing, try to obtain it.
        if response is None:
            if full:
                verbose_log.append("No original response; sending request for baseline.")
                baseRequestResponse = self._callbacks.makeHttpRequest(httpService, request)
                response = baseRequestResponse.getResponse()
                if response is None:
                    verbose_log.append("No response received after re-sending; aborting full scan.")
                    self._printVerbose(verbose_log)
                    return None
            else:
                verbose_log.append("No response received; skipping scan.")
                self._printVerbose(verbose_log)
                return None

        analyzedResponse = self._helpers.analyzeResponse(response)
        # Calculate original response body length.
        orig_body_offset = analyzedResponse.getBodyOffset()
        originalBodyLength = len(response) - orig_body_offset
        
        # Use original response timing as baseline (t0 = 0)
        t0 = 0

        parameters = analyzedRequest.getParameters()
        foundParam = False
        
        # Set up tracking per target.
        target_id = "{}:{}:{}".format(httpService.getHost(), httpService.getPort(), httpService.getProtocol())
        if target_id not in self.scanned_params:
            if full:
                self.scanned_params[target_id] = {"URL": set(), "Cookie": set(), "Body": set()}
            else:
                self.scanned_params[target_id] = {"URL": set(), "Cookie": set()}
        
        for param in parameters:
            # In full scan mode, process URL, Cookie, and Body parameters.
            # In passive mode, process only URL and Cookie.
            if full:
                if param.getType() not in (param.PARAM_URL, param.PARAM_COOKIE, param.PARAM_BODY):
                    continue
            else:
                if param.getType() not in (param.PARAM_URL, param.PARAM_COOKIE):
                    continue

            foundParam = True
            paramName = param.getName()
            origValue = param.getValue()
            paramType = param.getType()
            # Determine category key.
            if paramType == param.PARAM_URL:
                cat = "URL"
            elif paramType == param.PARAM_COOKIE:
                cat = "Cookie"
            elif paramType == param.PARAM_BODY:
                cat = "Body"
            else:
                continue
            pTypeStr = cat

            # In non-force mode, skip if already scanned.
            if not force:
                if paramName in self.scanned_params[target_id].get(cat, set()):
                    verbose_log.append("Parameter '" + paramName + "' in " + cat + " already scanned; skipping.")
                    continue
                else:
                    self.scanned_params[target_id][cat].add(paramName)
            
            verbose_log.append("Scanning parameter: " + paramName + " (Type: " + pTypeStr + ")")
            
            # --------------------- Test 1: Single Quote ---------------------
            test1_value = origValue + "'"
            if paramType == param.PARAM_COOKIE:
                req1 = self.updateCookieParameter(request, param, test1_value, verbose_log)
            else:
                newParam = self._helpers.buildParameter(paramName, test1_value, paramType)
                req1 = self._helpers.updateParameter(request, newParam)
            t1_start = time.time()
            resp1 = self._callbacks.makeHttpRequest(httpService, req1)
            t1_end = time.time()
            duration1 = t1_end - t1_start
            resp1_response = resp1.getResponse()
            if resp1_response is None:
                verbose_log.append("Test1 for parameter " + paramName + " did not receive a response; skipping.")
                continue
            resp1_info = self._helpers.analyzeResponse(resp1_response)
            test1_body_offset = resp1_info.getBodyOffset()
            test1BodyLength = len(resp1_response) - test1_body_offset
            diff1 = abs(test1BodyLength - originalBodyLength) / float(originalBodyLength)
            verbose_log.append("Test1 for parameter " + paramName + ": content diff = {:.2f}, duration = {:.2f} sec".format(diff1, duration1))
            
            # Decide which branch to follow.
            if diff1 > 0.1:
                # --------------------- Content-Based Branch ---------------------
                test2_value = origValue + "''"
                if paramType == param.PARAM_COOKIE:
                    req2 = self.updateCookieParameter(request, param, test2_value, verbose_log)
                else:
                    newParam = self._helpers.buildParameter(paramName, test2_value, paramType)
                    req2 = self._helpers.updateParameter(request, newParam)
                resp2 = self._callbacks.makeHttpRequest(httpService, req2)
                resp2_response = resp2.getResponse()
                if resp2_response is None:
                    verbose_log.append("Test2 for parameter " + paramName + " did not receive a response; skipping.")
                    continue
                resp2_info = self._helpers.analyzeResponse(resp2_response)
                t2_body_len = len(resp2_response) - resp2_info.getBodyOffset()
                verbose_log.append("Test2 for parameter " + paramName + ": content length = " + str(t2_body_len))
                if resp2_info.getStatusCode() != analyzedResponse.getStatusCode():
                    verbose_log.append("Test2: Status code differs for parameter " + paramName + "; skipping further tests.")
                    continue
                if not (t2_body_len == originalBodyLength or abs(t2_body_len - test1BodyLength)/float(test1BodyLength) > 0.1):
                    verbose_log.append("Test2: Content difference for parameter " + paramName + " not significant compared to Test1; skipping further tests.")
                    continue

                resp3 = self._callbacks.makeHttpRequest(httpService, req1)
                resp3_response = resp3.getResponse()
                if resp3_response is None:
                    verbose_log.append("Test3 for parameter " + paramName + " did not receive a response; skipping.")
                    continue
                resp3_info = self._helpers.analyzeResponse(resp3_response)
                test3_body_offset = resp3_info.getBodyOffset()
                test3BodyLength = len(resp3_response) - test3_body_offset
                diff3 = abs(test3BodyLength - originalBodyLength) / float(originalBodyLength)
                if resp3_info.getStatusCode() == analyzedResponse.getStatusCode() and diff3 <= 0.1:
                    verbose_log.append("Test3: No significant content change on repeat for parameter " + paramName + "; skipping further tests.")
                    continue

                resp4 = self._callbacks.makeHttpRequest(httpService, req2)
                resp4_response = resp4.getResponse()
                if resp4_response is None:
                    verbose_log.append("Test4 for parameter " + paramName + " did not receive a response; skipping.")
                    continue
                resp4_info = self._helpers.analyzeResponse(resp4_response)
                t4_body_len = len(resp4_response) - resp4_info.getBodyOffset()
                if resp4_info.getStatusCode() != analyzedResponse.getStatusCode():
                    verbose_log.append("Test4: Status code differs for parameter " + paramName + "; no vulnerability found.")
                else:
                    if t4_body_len == originalBodyLength or abs(t4_body_len - test3BodyLength)/float(test3BodyLength) > 0.1:
                        verbose_log.append("Sqluick vulnerability detected on parameter " + paramName + " (Response Difference).")
                        issue = CustomScanIssue(
                            httpService,
                            url,
                            [baseRequestResponse, resp1, resp2],
                            "Sqluick (Quick Find - Response Difference)",
                            "Parameter '" + paramName + "' (Type: " + pTypeStr + ") appears vulnerable to Sqluick based on content differences.",
                            "High"
                        )
                        issues.append(issue)
                    else:
                        verbose_log.append("Test4: Final content check for parameter " + paramName + " did not show significant difference; no vulnerability found.")
            else:
                # --------------------- Timing-Based Branch ---------------------
                if duration1 <= 3:
                    verbose_log.append("Test1 timing: Delay {:.2f} sec is not >3 sec for parameter ".format(duration1) + paramName + "; skipping timing tests.")
                    continue
                test2_value = origValue + "''"
                if paramType == param.PARAM_COOKIE:
                    req2 = self.updateCookieParameter(request, param, test2_value, verbose_log)
                else:
                    newParam = self._helpers.buildParameter(paramName, test2_value, paramType)
                    req2 = self._helpers.updateParameter(request, newParam)
                t2_start = time.time()
                resp2 = self._callbacks.makeHttpRequest(httpService, req2)
                t2_end = time.time()
                duration2 = t2_end - t2_start
                if (duration2 - duration1) <= 3:
                    verbose_log.append("Test2 timing: Difference ({:.2f} sec) not >3 sec for parameter ".format(duration2 - duration1) + paramName + "; skipping timing tests.")
                    continue

                t3_start = time.time()
                resp3 = self._callbacks.makeHttpRequest(httpService, req1)
                t3_end = time.time()
                duration3 = t3_end - t3_start

                t4_start = time.time()
                resp4 = self._callbacks.makeHttpRequest(httpService, req2)
                t4_end = time.time()
                duration4 = t4_end - t4_start

                verbose_log.append("Timing for parameter " + paramName + ": Test1 = {:.2f}, Test2 = {:.2f}, Test3 = {:.2f}, Test4 = {:.2f} sec".format(duration1, duration2, duration3, duration4))
                if (duration4 - duration3) > 3:
                    verbose_log.append("Sqluick vulnerability detected on parameter " + paramName + " (Timing Difference).")
                    issue = CustomScanIssue(
                        httpService,
                        url,
                        [baseRequestResponse, resp1, resp2],
                        "Sqluick (Quick Find - Timing Difference)",
                        "Parameter '" + paramName + "' (Type: " + pTypeStr + ") appears vulnerable to Sqluick based on timing differences.",
                        "High"
                    )
                    issues.append(issue)
                else:
                    verbose_log.append("Test4 timing: Final timing difference for parameter " + paramName + " did not exceed threshold; no vulnerability found.")

        if not foundParam:
            verbose_log.append("No URL, Cookie, or Body parameters found in request; skipping Sqluick scan.")

        self._printVerbose(verbose_log)
        return issues if issues else None

    def updateCookieParameter(self, request, param, new_value, verbose_log):
        analyzedRequest = self._helpers.analyzeRequest(request)
        headers = list(analyzedRequest.getHeaders())
        new_headers = []
        cookie_header = None
        for header in headers:
            if header.lower().startswith("cookie:"):
                cookie_header = header
            else:
                new_headers.append(header)
        if cookie_header:
            pattern = re.compile(r'(' + re.escape(param.getName()) + r'=)([^;]*)')
            new_cookie_header = pattern.sub(lambda m: m.group(1) + new_value, cookie_header)
            verbose_log.append("Original Cookie header: " + cookie_header)
            verbose_log.append("New Cookie header: " + new_cookie_header)
            new_headers.append(new_cookie_header)
        else:
            new_headers.append("Cookie: " + param.getName() + "=" + new_value)
        body = request[analyzedRequest.getBodyOffset():]
        return self._helpers.buildHttpMessage(new_headers, body)

    def consolidateDuplicateIssues(self, existingIssue, newIssue):
        if existingIssue.getIssueName() == newIssue.getIssueName():
            return -1
        return 0

    def _printVerbose(self, logs):
        for line in logs:
            self._callbacks.printOutput(line)

    def createMenuItems(self, invocation):
        menu_list = []
        # Two menu items for Full Request Scan.
        item_full = JMenuItem("Full Request Scan")
        item_full.addActionListener(FullScanAction(invocation, self, force=False))
        menu_list.append(item_full)
        item_full_force = JMenuItem("Full Request Scan (Force)")    
        item_full_force.addActionListener(FullScanAction(invocation, self, force=True))
        menu_list.append(item_full_force)
        return menu_list

class FullScanAction(ActionListener):
    def __init__(self, invocation, extender, force):
        self.invocation = invocation
        self.extender = extender
        self.force = force

    def actionPerformed(self, event):
        messages = self.invocation.getSelectedMessages()
        if messages is None:
            return
        # Run full scan in a new thread to avoid blocking the Swing EDT.
        scan_thread = threading.Thread(target=self.runFullScan, args=(messages,))
        scan_thread.start()

    def runFullScan(self, messages):
        # For Full Request Scan, we set full=True.
        for msg in messages:
            issues = self.extender.performSqluickScan(msg, force=self.force, full=True)
            if issues:
                for issue in issues:
                    self.extender._callbacks.addScanIssue(issue)

class CustomScanIssue(IScanIssue):
    def __init__(self, httpService, url, httpMessages, name, detail, severity):
        self._httpService = httpService
        self._url = url
        self._httpMessages = httpMessages
        self._name = name
        self._detail = detail
        self._severity = severity

    def getUrl(self):
        return self._url

    def getIssueName(self):
        return self._name

    def getIssueType(self):
        return 0  # Custom scan issue type

    def getSeverity(self):
        return self._severity

    def getConfidence(self):
        return "Firm"

    def getIssueBackground(self):
        return None

    def getRemediationBackground(self):
        return None

    def getIssueDetail(self):
        return self._detail

    def getRemediationDetail(self):
        return None

    def getHttpMessages(self):
        return self._httpMessages

    def getHttpService(self):
        return self._httpService
