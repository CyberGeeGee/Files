# -*- coding: utf-8 -*-
from flask import Flask, request, Response, render_template_string
import time, json

app = Flask(__name__)

@app.route('/')
def index():
    html = """
    <html>
      <head><title>Sqluick Test Cases</title></head>
      <body>
        <h1>Sqluick Test Cases</h1>
        <h2>Query Parameter Tests (GET)</h2>
        <ul>
          <li><a href="/search?id=1">Normal Response (id=1)</a></li>
          <li><a href="/search?id=1'">Vulnerable Response (id=1')</a></li>
          <li><a href="/search?id=1''">Baseline Response (id=1'')</a></li>
          <li><a href="/search?id=small">Normal Response (id=small)</a></li>
          <li><a href="/search?id=small'">Small Change (id=small')</a></li>
          <li><a href="/search?id=small''">Baseline Response (id=small'')</a></li>
          <li><a href="/search?id=timing">Normal Timing (id=timing)</a></li>
          <li><a href="/search?id=timing'">Timing Delay (id=timing')</a></li>
          <li><a href="/search?id=timing''">Baseline Timing (id=timing'')</a></li>
        </ul>
        <h2>Cookie Parameter Tests</h2>
        <p>
          Use the /set_cookie endpoint to set the session cookie, then click the link below.
        </p>
        <ul>
          <li><a href="/set_cookie?value=1">Set Cookie: 1 (Normal)</a></li>
          <li><a href="/set_cookie?value=1%27">Set Cookie: 1' (Vulnerable)</a></li>
          <li><a href="/set_cookie?value=1%27%27">Set Cookie: 1'' (Baseline)</a></li>
          <li><a href="/set_cookie?value=small">Set Cookie: small (Normal)</a></li>
          <li><a href="/set_cookie?value=small%27">Set Cookie: small' (Small Change)</a></li>
          <li><a href="/set_cookie?value=small%27%27">Set Cookie: small'' (Baseline)</a></li>
          <li><a href="/set_cookie?value=timing">Set Cookie: timing (Normal Timing)</a></li>
          <li><a href="/set_cookie?value=timing%27">Set Cookie: timing' (Timing Delay)</a></li>
          <li><a href="/set_cookie?value=timing%27%27">Set Cookie: timing'' (Baseline Timing)</a></li>
        </ul>
        <p>
          After setting a cookie, click <a href="/cookie_test">here</a> to view the cookie response.
        </p>
        <h2>POST Body Parameter Tests</h2>
        <ul>
          <li><a href="/post_test">POST Test Cases (click to open form)</a></li>
        </ul>
        <h2>JSON Body Parameter Tests</h2>
        <ul>
          <li><a href="/json_test">JSON Test Cases (click to open form)</a></li>
        </ul>
      </body>
    </html>
    """
    return render_template_string(html)

@app.route('/search')
def search():
    param = request.args.get('id', '')
    # Timing branch for query parameters.
    if param.startswith("timing"):
        base_value = "Normal timing response for id: " + param.rstrip("'")
        if param.endswith("''"):
            time.sleep(8)
            return Response(base_value, status=200, mimetype='text/plain')
        elif param.endswith("'"):
            time.sleep(4)
            return Response(base_value, status=200, mimetype='text/plain')
        else:
            return Response(base_value, status=200, mimetype='text/plain')
    # Small change branch.
    elif param.startswith("small"):
        base_value = "Normal response for id: " + param.rstrip("'")
        if param.endswith("''"):
            return Response(base_value, status=200, mimetype='text/plain')
        elif param.endswith("'"):
            return Response(base_value + " ", status=200, mimetype='text/plain')
        else:
            return Response(base_value, status=200, mimetype='text/plain')
    else:
        baseline = "Normal response for id: " + param
        if param.endswith("''"):
            base_value = param[:-2]
            return Response("Normal response for id: " + base_value, status=200, mimetype='text/plain')
        elif param.endswith("'"):
            return Response("SQL error: unmatched quote in query. Detailed error: Your SQL query has a syntax error due to an unmatched quote.", status=200, mimetype='text/plain')
        else:
            return Response(baseline, status=200, mimetype='text/plain')

@app.route('/set_cookie')
def set_cookie():
    value = request.args.get("value", "default")
    resp = Response("Cookie 'session' set to: " + value + ".<br><a href='/cookie_test'>Click here to test cookie response</a>", 
                    status=200, mimetype='text/html')
    resp.set_cookie("session", value)
    return resp

@app.route('/cookie_test')
def cookie_test():
    session_val = request.cookies.get("session", "")
    if session_val == "":
        return Response("No 'session' cookie set. Use the /set_cookie endpoint to set one.", status=200, mimetype='text/plain')
    # Timing branch for cookies.
    if session_val.startswith("timing"):
        base_value = "Normal timing response for cookie session: " + session_val.rstrip("'")
        if session_val.endswith("''"):
            time.sleep(8)
            return Response(base_value, status=200, mimetype='text/plain')
        elif session_val.endswith("'"):
            time.sleep(4)
            return Response(base_value, status=200, mimetype='text/plain')
        else:
            return Response(base_value, status=200, mimetype='text/plain')
    # Small change branch for cookies.
    elif session_val.startswith("small"):
        base_value = "Normal response for cookie session: " + session_val.rstrip("'")
        if session_val.endswith("''"):
            return Response(base_value, status=200, mimetype='text/plain')
        elif session_val.endswith("'"):
            return Response(base_value + " ", status=200, mimetype='text/plain')
        else:
            return Response(base_value, status=200, mimetype='text/plain')
    else:
        baseline = "Normal response for cookie session: " + session_val
        if session_val.endswith("''"):
            base_value = session_val[:-2]
            return Response("Normal response for cookie session: " + base_value, status=200, mimetype='text/plain')
        elif session_val.endswith("'"):
            return Response("SQL error: unmatched quote in cookie. Detailed error: The cookie value caused an SQL syntax error due to an unmatched quote.", status=200, mimetype='text/plain')
        else:
            return Response(baseline, status=200, mimetype='text/plain')

@app.route('/post_test', methods=['GET', 'POST'])
def post_test():
    if request.method == 'GET':
        html = """
        <html>
          <head><title>POST Test Cases</title></head>
          <body>
            <h1>POST Test Cases</h1>
            <form action="/post_test" method="post">
              <label for="data">Body Parameter (data):</label>
              <input type="text" name="data" id="data" value="1">
              <input type="submit" value="Submit">
            </form>
            <p>Try values such as:</p>
            <ul>
              <li>Normal: <code>1</code></li>
              <li>Vulnerable: <code>1'</code></li>
              <li>Baseline: <code>1''</code></li>
              <li>Small change: <code>small</code>, <code>small'</code>, <code>small''</code></li>
              <li>Timing: <code>timing</code>, <code>timing'</code>, <code>timing''</code></li>
            </ul>
          </body>
        </html>
        """
        return html
    else:
        data = request.form.get('data', '')
        if data.startswith("timing"):
            base_value = "Normal timing response for body data: " + data.rstrip("'")
            if data.endswith("''"):
                time.sleep(8)
                return Response(base_value, status=200, mimetype='text/plain')
            elif data.endswith("'"):
                time.sleep(4)
                return Response(base_value, status=200, mimetype='text/plain')
            else:
                return Response(base_value, status=200, mimetype='text/plain')
        elif data.startswith("small"):
            base_value = "Normal response for body data: " + data.rstrip("'")
            if data.endswith("''"):
                return Response(base_value, status=200, mimetype='text/plain')
            elif data.endswith("'"):
                return Response(base_value + " ", status=200, mimetype='text/plain')
            else:
                return Response(base_value, status=200, mimetype='text/plain')
        else:
            baseline = "Normal response for body data: " + data
            if data.endswith("''"):
                base_value = data[:-2]
                return Response("Normal response for body data: " + base_value, status=200, mimetype='text/plain')
            elif data.endswith("'"):
                return Response("SQL error: unmatched quote in body. Detailed error: The submitted data caused an SQL syntax error due to an unmatched quote.", status=200, mimetype='text/plain')
            else:
                return Response(baseline, status=200, mimetype='text/plain')

@app.route('/json_test', methods=['GET', 'POST'])
def json_test():
    if request.method == 'GET':
        # Use JavaScript to send the JSON request with the correct content type.
        html = """
        <html>
          <head>
            <title>JSON Test Cases</title>
            <script>
              function submitJSON() {
                var jsondata = document.getElementById("jsondata").value;
                fetch("/json_test", {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json"
                  },
                  body: jsondata
                }).then(response => response.text())
                  .then(text => {
                    document.getElementById("result").innerText = text;
                  });
                return false;
              }
            </script>
          </head>
          <body>
            <h1>JSON Test Cases</h1>
            <p>Submit a JSON object with a key "data". For example:</p>
            <pre>
{
  "data": "1"
}
            </pre>
            <p>Try test cases such as:</p>
            <ul>
              <li>Normal: {"data": "1"}</li>
              <li>Vulnerable: {"data": "1'"}</li>
              <li>Baseline: {"data": "1''"}</li>
              <li>Small change: {"data": "small"}, {"data": "small'"}, {"data": "small''"}</li>
              <li>Timing: {"data": "timing"}, {"data": "timing'"}, {"data": "timing''"}</li>
            </ul>
            <form onsubmit="return submitJSON();">
              <textarea id="jsondata" rows="10" cols="50">{ "data": "1" }</textarea><br>
              <input type="submit" value="Submit JSON">
            </form>
            <h2>Result:</h2>
            <pre id="result"></pre>
          </body>
        </html>
        """
        return html
    else:
        try:
            jsondata = request.get_data(as_text=True)
            data_obj = json.loads(jsondata)
        except Exception as e:
            return Response("Invalid JSON: " + str(e), status=400, mimetype='text/plain')
        val = str(data_obj.get("data", ""))
        if val.startswith("timing"):
            base_value = "Normal timing response for JSON data: " + val.rstrip("'")
            if val.endswith("''"):
                time.sleep(8)
                return Response(base_value, status=200, mimetype='application/json')
            elif val.endswith("'"):
                time.sleep(4)
                return Response(base_value, status=200, mimetype='application/json')
            else:
                return Response(base_value, status=200, mimetype='application/json')
        elif val.startswith("small"):
            base_value = "Normal response for JSON data: " + val.rstrip("'")
            if val.endswith("''"):
                return Response(base_value, status=200, mimetype='application/json')
            elif val.endswith("'"):
                return Response(base_value + " ", status=200, mimetype='application/json')
            else:
                return Response(base_value, status=200, mimetype='application/json')
        else:
            baseline = "Normal response for JSON data: " + val
            if val.endswith("''"):
                base_value = val[:-2]
                return Response("Normal response for JSON data: " + base_value, status=200, mimetype='application/json')
            elif val.endswith("'"):
                return Response("SQL error: unmatched quote in JSON data. Detailed error: The JSON input caused an SQL syntax error due to an unmatched quote.", status=200, mimetype='application/json')
            else:
                return Response(baseline, status=200, mimetype='application/json')

if __name__ == '__main__':
    app.run(port=8888, debug=True)
