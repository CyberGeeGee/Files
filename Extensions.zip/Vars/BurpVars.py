# -*- coding: utf-8 -*-
# --- Burp Extender API Imports ---
from burp import IBurpExtender
from burp import ITab
from burp import IHttpListener
from burp import IExtensionHelpers

# --- Java Swing UI Imports ---
from javax.swing import (JPanel, JTable, JScrollPane, JButton, JTextField, JLabel,
                         ListSelectionModel, BoxLayout, Box, JPopupMenu, JMenuItem, SwingUtilities)
from javax.swing.table import DefaultTableModel
from java.awt import BorderLayout, FlowLayout, Dimension
# --- Added for Focus Listener ---
from java.awt.event import FocusAdapter

# --- Standard Python Imports ---
import json
import re
import threading
import sys
import traceback
import urllib
import urlparse

# --- Configuration ---
EXTENSION_NAME = "Vars"
VARS_TAB_NAME = "Vars"
PERSISTENCE_KEY = "variable_replacer_vars_v1_oldapi"


class BurpExtender(IBurpExtender, ITab, IHttpListener):

    # --- NEW: Custom TableModel for direct cell editing ---
    class VariableTableModel(DefaultTableModel):
        def __init__(self, extender, headers, rows):
            # Jython 2.7 requires explicit call to super's __init__
            DefaultTableModel.__init__(self, headers, rows)
            self.extender = extender

        def isCellEditable(self, row, column):
            # Make all cells editable
            return True

        def setValueAt(self, aValue, row, column):
            # --- This method is the core of the in-table editing logic ---
            try:
                original_name = self.getValueAt(row, 0)
                original_value = self.getValueAt(row, 1)

                # Let the superclass update the table's view first
                super(BurpExtender.VariableTableModel, self).setValueAt(aValue, row, column)

                # Get the potentially new values after the edit
                new_name_from_table = self.getValueAt(row, 0)
                new_value_from_table = self.getValueAt(row, 1)

                cleaned_new_name = re.sub(r'^(\$|%24)', '', new_name_from_table.strip())

                # --- Validation ---
                if not cleaned_new_name:
                    self.extender._callbacks.printError("Variable name cannot be empty. Reverting change.")
                    # Revert the visual change in the table model
                    super(BurpExtender.VariableTableModel, self).setValueAt(original_name, row, 0)
                    super(BurpExtender.VariableTableModel, self).setValueAt(original_value, row, 1)
                    return

                # If name changed, check if it conflicts with another existing variable
                if column == 0 and cleaned_new_name != original_name:
                    if cleaned_new_name in self.extender.get_variables():
                        self.extender._callbacks.printError("Variable '{0}' already exists. Reverting change.".format(cleaned_new_name))
                        super(BurpExtender.VariableTableModel, self).setValueAt(original_name, row, 0)
                        return

                # --- Update Backend Data ---
                if column == 0: # Name was changed
                    if cleaned_new_name != original_name:
                        self.extender.delete_variable(original_name)
                        self.extender.add_variable(cleaned_new_name, new_value_from_table)
                        # If the edited row is the selected one, update the bottom text fields
                        if self.extender.table.getSelectedRow() == row:
                            self.extender.name_field.setText(cleaned_new_name)
                elif column == 1: # Value was changed
                    self.extender.add_variable(cleaned_new_name, new_value_from_table)
                    if self.extender.table.getSelectedRow() == row:
                        self.extender.value_field.setText(new_value_from_table)

            except Exception as e:
                self.extender._callbacks.printError("Error during direct table edit:")
                self.extender._callbacks.printError(traceback.format_exc())


    def registerExtenderCallbacks(self, callbacks):
        self._callbacks = callbacks
        self._helpers = callbacks.getHelpers()
        callbacks.setExtensionName(EXTENSION_NAME)
        self.variables = {}
        self.lock = threading.RLock()
        self.load_variables()
        try:
             self._initialize_ui()
        except Exception as e:
            self._callbacks.printError("!!! Critical Error during UI Initialization !!!")
            self._callbacks.printError(traceback.format_exc())
            self.tab_panel = JPanel()
            self.tab_panel.add(JLabel("Error initializing UI. Check Extension errors."))
        if hasattr(self, 'tab_panel'):
            callbacks.registerHttpListener(self)
            callbacks.addSuiteTab(self)
            sys.stdout.write("{0} initialized successfully.\n".format(EXTENSION_NAME))
            sys.stdout.write("Loaded {0} variables.\n".format(len(self.variables)))
        else:
            self._callbacks.printError("UI Panel was not created. Tab not added.")
        sys.stdout.flush()


    def _initialize_ui(self):
        try:
            self.tab_panel = JPanel(BorderLayout(10, 10))

            # --- MODIFICATION: Use the custom VariableTableModel ---
            self.table_model = self.VariableTableModel(self, ["Variable Name", "Value"], 0)
            self.table = JTable(self.table_model)

            self.table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION)
            self.table.getSelectionModel().addListSelectionListener(self._row_selected)

            # --- MODIFICATION: Remove the line that disables editing ---
            # self.table.setDefaultEditor(object, None) # This line is now removed

            popup_menu = JPopupMenu()
            delete_item = JMenuItem("Delete Selected Variable")
            delete_item.addActionListener(self._delete_action)
            popup_menu.add(delete_item)
            self.table.setComponentPopupMenu(popup_menu)
            scroll_pane = JScrollPane(self.table)
            self.tab_panel.add(scroll_pane, BorderLayout.CENTER)
            controls_panel = JPanel()
            controls_panel.setLayout(BoxLayout(controls_panel, BoxLayout.Y_AXIS))
            input_grid = JPanel(BorderLayout(5, 5))
            name_label = JLabel("Name:")
            self.name_field = JTextField(20)
            name_label.setLabelFor(self.name_field)
            input_grid.add(name_label, BorderLayout.WEST)
            input_grid.add(self.name_field, BorderLayout.CENTER)
            input_grid.setMaximumSize(Dimension(500, self.name_field.getPreferredSize().height + 5))
            value_label = JLabel("Value:")
            self.value_field = JTextField(40)
            value_label.setLabelFor(self.value_field)
            value_grid = JPanel(BorderLayout(5, 5))
            value_grid.add(value_label, BorderLayout.WEST)
            value_grid.add(self.value_field, BorderLayout.CENTER)
            value_grid.setMaximumSize(Dimension(500, self.value_field.getPreferredSize().height + 5))

            class BurpVarsFocusListener(FocusAdapter):
                def __init__(self, extender):
                    self.extender = extender
                def focusLost(self, e):
                    self.extender._handle_modify_on_focus_lost()

            focus_listener = BurpVarsFocusListener(self)
            self.name_field.addFocusListener(focus_listener)
            self.value_field.addFocusListener(focus_listener)

            buttons_panel = JPanel(FlowLayout(FlowLayout.LEFT))
            add_button = JButton("Add", actionPerformed=self._add_action)
            delete_button = JButton("Delete Selected", actionPerformed=self._delete_action)
            clear_button = JButton("Clear Fields", actionPerformed=self._clear_fields_action)
            buttons_panel.add(add_button)
            buttons_panel.add(delete_button)
            buttons_panel.add(clear_button)
            buttons_panel.setMaximumSize(Dimension(500, add_button.getPreferredSize().height + 10))

            controls_panel.add(input_grid)
            controls_panel.add(Box.createRigidArea(Dimension(0, 5)))
            controls_panel.add(value_grid)
            controls_panel.add(Box.createRigidArea(Dimension(0, 10)))
            controls_panel.add(buttons_panel)
            controls_panel.add(Box.createVerticalGlue())
            self.tab_panel.add(controls_panel, BorderLayout.SOUTH)
            self._refresh_table()
        except Exception as e:
            self._callbacks.printError("!!! Error occurred within _initialize_ui !!!")
            self._callbacks.printError(traceback.format_exc())
            raise

    def _handle_modify_on_focus_lost(self):
        selected_row = self.table.getSelectedRow()
        if selected_row == -1:
            return
        try:
            original_name = self.table_model.getValueAt(selected_row, 0)
            new_name = self.name_field.getText().strip()
            new_value = self.value_field.getText()
            if not new_name:
                self._callbacks.printError("Cannot modify variable to have an empty name.")
                self.name_field.setText(original_name)
                return
            original_value = self.table_model.getValueAt(selected_row, 1)
            if new_name == original_name and new_value == original_value:
                return
            self.delete_variable(original_name)
            self.add_variable(new_name, new_value)
            self._refresh_table()
            for i in range(self.table_model.getRowCount()):
                if self.table_model.getValueAt(i, 0) == new_name:
                    self.table.setRowSelectionInterval(i, i)
                    break
        except Exception as e:
            self._callbacks.printError("Error during automatic update on focus lost:")
            self._callbacks.printError(traceback.format_exc())

    def getTabCaption(self): return VARS_TAB_NAME
    def getUiComponent(self): return self.tab_panel

    def get_variables(self):
        with self.lock: return dict(self.variables)

    def add_variable(self, name, value):
        if not name:
            self._callbacks.printError("Variable name cannot be empty.")
            return False
        if name.startswith('$') or name.startswith('%24'):
             self._callbacks.printError("Variable name should not start with $ or %24.")
             name = re.sub(r'^(\$|%24)', '', name)
             if not name: return False
        with self.lock: self.variables[name] = value
        self.save_variables()
        self._callbacks.printOutput("Added/Updated variable: {0}".format(name))
        return True

    def delete_variable(self, name):
        with self.lock:
            if name in self.variables:
                del self.variables[name]
                self.save_variables()
                self._callbacks.printOutput("Deleted variable: {0}".format(name))
                return True
            else:
                name_stripped = re.sub(r'^(\$|%24)', '', name)
                if name_stripped != name and name_stripped in self.variables:
                     del self.variables[name_stripped]
                     self.save_variables()
                     self._callbacks.printOutput("Deleted variable (after stripping prefix): {0}".format(name_stripped))
                     return True
                else:
                    return False

    def save_variables(self):
        with self.lock:
            try:
                vars_json = json.dumps(self.variables)
                self._callbacks.saveExtensionSetting(PERSISTENCE_KEY, vars_json)
            except Exception as e:
                self._callbacks.printError("Error saving variables:")
                self._callbacks.printError(traceback.format_exc())

    def load_variables(self):
        with self.lock:
            try:
                vars_json = self._callbacks.loadExtensionSetting(PERSISTENCE_KEY)
                if vars_json: self.variables = json.loads(vars_json)
                else: self.variables = {}
                cleaned_vars = {}
                for name, value in self.variables.items():
                    cleaned_name = re.sub(r'^(\$|%24)', '', name)
                    if cleaned_name:
                        cleaned_vars[cleaned_name] = value
                if len(cleaned_vars) != len(self.variables):
                    self._callbacks.printOutput("Cleaned variable names on load.")
                    self.variables = cleaned_vars
            except Exception as e:
                self._callbacks.printError("Error loading variables:")
                self._callbacks.printError(traceback.format_exc())
                self.variables = {}

    def _refresh_table(self):
        def update():
            selected_row = self.table.getSelectedRow()
            selected_var_name = None
            if selected_row != -1:
                try:
                    selected_var_name = self.table_model.getValueAt(selected_row, 0)
                except: pass
            while self.table_model.getRowCount() > 0: self.table_model.removeRow(0)
            variables = self.get_variables()
            for name in sorted(variables.keys()): self.table_model.addRow([name, variables[name]])
            if selected_var_name:
                 for i in range(self.table_model.getRowCount()):
                    if self.table_model.getValueAt(i, 0) == selected_var_name:
                        self.table.setRowSelectionInterval(i, i)
                        break
        SwingUtilities.invokeLater(update)

    def _row_selected(self, e):
        if not e.getValueIsAdjusting():
            selected_row = self.table.getSelectedRow()
            if selected_row != -1:
                if hasattr(self, 'table_model'):
                    try:
                        name = self.table_model.getValueAt(selected_row, 0)
                        value = self.table_model.getValueAt(selected_row, 1)
                        self.name_field.setText(name)
                        self.value_field.setText(value)
                    except Exception as ex:
                         self._callbacks.printError("Error in _row_selected:")
                         self._callbacks.printError(traceback.format_exc())

    def _add_action(self, e):
        name = self.name_field.getText().strip()
        value = self.value_field.getText()
        if not name:
            self._callbacks.printError("Variable name cannot be empty.")
            return
        if name in self.get_variables():
            self._callbacks.printError("Variable '{0}' already exists. Select it from the table to modify.".format(name))
            return
        cleaned_name = re.sub(r'^(\$|%24)', '', name)
        if not cleaned_name:
            self._callbacks.printError("Variable name cannot be just '$' or '%24'.")
            return
        if self.add_variable(cleaned_name, value):
            self._refresh_table()
            self._clear_fields_action(None)

    def _delete_action(self, e):
        selected_row = self.table.getSelectedRow()
        if selected_row != -1:
             if hasattr(self, 'table_model'):
                name_in_table = self.table_model.getValueAt(selected_row, 0)
                if self.delete_variable(name_in_table):
                    self._refresh_table()
                    self._clear_fields_action(None)
                else: pass
        else:
             name_in_field = self.name_field.getText().strip()
             if name_in_field:
                  cleaned_name = re.sub(r'^(\$|%24)', '', name_in_field)
                  if not cleaned_name: return
                  if self.delete_variable(cleaned_name):
                       self._refresh_table()
                       self._clear_fields_action(None)
                  else: pass
             else:
                self._callbacks.printOutput("Select a variable in the table or enter name to delete.")

    def _clear_fields_action(self, e):
        self.name_field.setText("")
        self.value_field.setText("")
        if hasattr(self, 'table'): self.table.clearSelection()

    # --- MODIFICATION: processHttpMessage updated to fix longest match bug ---
    def processHttpMessage(self, toolFlag, messageIsRequest, messageInfo):
        current_vars = self.get_variables()
        if not current_vars:
            return

        # --- BUG FIX: Sort variable names by length (desc) to find longest match first ---
        sorted_var_names = sorted(current_vars.keys(), key=len, reverse=True)

        def encode_preserving_collab(value, mode):
            if '$collabplz' not in value:
                if mode == 'path': return urllib.quote(value, safe='/')
                elif mode == 'query' or mode == 'form_url': return urllib.quote(value, safe='~()*!.\'')
                else: return value
            else:
                parts = value.split('$collabplz')
                encoded_parts = []
                for i, part in enumerate(parts):
                    if part:
                         if mode == 'path': encoded_parts.append(urllib.quote(part, safe='/'))
                         elif mode == 'query' or mode == 'form_url': encoded_parts.append(urllib.quote(part, safe='~()*!.\''))
                         else: encoded_parts.append(part)
                    else: encoded_parts.append("")
                return '$collabplz'.join(encoded_parts)

        if messageIsRequest:
            original_message_bytes = messageInfo.getRequest()
            try: info = self._helpers.analyzeRequest(messageInfo)
            except Exception: return
            headers = list(info.getHeaders())
            body_bytes = original_message_bytes[info.getBodyOffset():]
            new_headers = list(headers)
            new_body_bytes = bytearray(body_bytes)
            modified, headers_modified, body_modified, request_line_modified = False, False, False, False

            if new_headers:
                request_line = str(new_headers[0])
                try:
                    parts = request_line.split(' ', 2)
                    if len(parts) == 3:
                        method, url_part, http_version = parts
                        original_url_part = url_part
                        parsed_url = urlparse.urlparse(url_part)
                        current_path, current_query = parsed_url.path, parsed_url.query
                        path_changed, query_changed = False, False
                        # --- BUG FIX: Iterate through sorted names ---
                        for name in sorted_var_names:
                            value = current_vars[name]
                            placeholder1, placeholder2 = "$" + name, "%24" + name
                            value_to_insert_path = None
                            if placeholder1 in current_path or placeholder2 in current_path:
                                value_to_insert_path = encode_preserving_collab(value, 'path')
                            if value_to_insert_path is not None:
                                current_path = current_path.replace(placeholder1, value_to_insert_path).replace(placeholder2, value_to_insert_path)
                                path_changed = modified = request_line_modified = True
                            value_to_insert_query = None
                            if placeholder1 in current_query or placeholder2 in current_query:
                                value_to_insert_query = encode_preserving_collab(value, 'query')
                            if value_to_insert_query is not None:
                                current_query = current_query.replace(placeholder1, value_to_insert_query).replace(placeholder2, value_to_insert_query)
                                query_changed = modified = request_line_modified = True
                        if path_changed or query_changed:
                            new_url_tuple = list(parsed_url); new_url_tuple[2] = current_path; new_url_tuple[4] = current_query
                            url_part = urlparse.urlunparse(new_url_tuple)
                        if url_part != original_url_part:
                            new_headers[0] = "{0} {1} {2}".format(method, url_part, http_version)
                except Exception as e:
                    self._callbacks.printError("Error processing request line:")
                    self._callbacks.printError(traceback.format_exc())
                    request_line_modified = False

            # --- BUG FIX: Iterate through sorted names ---
            for i in range(1, len(new_headers)):
                header = str(new_headers[i])
                new_header = header; header_modified_flag = False
                for name in sorted_var_names:
                    value = current_vars[name]
                    placeholder1, placeholder2 = "$" + name, "%24" + name
                    if placeholder1 in new_header or placeholder2 in new_header:
                        replacement_value = value
                        new_header = new_header.replace(placeholder1, replacement_value).replace(placeholder2, replacement_value)
                        headers_modified = modified = header_modified_flag = True
                if header_modified_flag: new_headers[i] = new_header

            if len(body_bytes) > 0:
                content_type = None
                for header in headers:
                    h_str = str(header)
                    if h_str.lower().startswith("content-type:"):
                        content_type = h_str.split(":", 1)[1].strip().lower(); break
                body_string = None
                try: body_string = self._helpers.bytesToString(body_bytes)
                except Exception: body_string = None
                if body_string is not None:
                    new_body_string = body_string
                    current_body_modified = False
                    encode_mode = 'direct'
                    if content_type:
                        if 'application/x-www-form-urlencoded' in content_type: encode_mode = 'form_url'
                        elif 'application/json' in content_type: encode_mode = 'json'
                    # --- BUG FIX: Iterate through sorted names ---
                    for name in sorted_var_names:
                         value = current_vars[name]
                         pattern = r'(?:\$|%24)' + re.escape(name)
                         if re.search(pattern, new_body_string):
                            temp_body = ""; last_end = 0
                            for match in re.finditer(pattern, new_body_string):
                                start, end = match.span()
                                value_to_insert = None
                                if encode_mode == 'form_url':
                                    value_to_insert = encode_preserving_collab(value, 'form_url')
                                elif encode_mode == 'json':
                                    if '$collabplz' in value: value_to_insert = value
                                    else:
                                        value_to_insert = value
                                        if new_body_string[:start].count('"') % 2 != 0:
                                             value_to_insert = value.replace('\\', '\\\\').replace('"', '\\"')
                                else:
                                     if '$collabplz' in value: value_to_insert = value
                                     else: value_to_insert = value
                                temp_body += new_body_string[last_end:start] + value_to_insert
                                last_end = end
                            new_body_string = temp_body + new_body_string[last_end:]
                            current_body_modified = True
                    if current_body_modified:
                        try:
                             new_body_bytes = self._helpers.stringToBytes(new_body_string)
                             body_modified = modified = True
                        except Exception:
                              self._callbacks.printError("Error encoding modified request body:")
                              self._callbacks.printError(traceback.format_exc())
                              body_modified = False
                              modified = request_line_modified or headers_modified
            if modified:
                try:
                    new_request_bytes = self._helpers.buildHttpMessage(new_headers, new_body_bytes)
                    messageInfo.setRequest(new_request_bytes)
                except Exception:
                    self._callbacks.printError("Error building modified HTTP request:")
                    self._callbacks.printError(traceback.format_exc())
        else: # Response
            original_message_bytes = messageInfo.getResponse()
            try: info = self._helpers.analyzeResponse(original_message_bytes)
            except Exception: return
            headers = list(info.getHeaders())
            body_bytes = original_message_bytes[info.getBodyOffset():]
            new_headers = list(headers)
            new_body_bytes = bytearray(body_bytes)
            modified, headers_modified, body_modified = False, False, False
            # --- BUG FIX: Iterate through sorted names ---
            for i in range(len(new_headers)):
                header = str(new_headers[i])
                new_header = header; header_modified_flag = False
                for name in sorted_var_names:
                    value = current_vars[name]
                    placeholder1, placeholder2 = "$" + name, "%24" + name
                    if placeholder1 in new_header or placeholder2 in new_header:
                        replacement_value = value
                        new_header = new_header.replace(placeholder1, replacement_value).replace(placeholder2, replacement_value)
                        headers_modified = modified = header_modified_flag = True
                if header_modified_flag: new_headers[i] = new_header
            if len(body_bytes) > 0:
                body_string = None
                try: body_string = self._helpers.bytesToString(body_bytes)
                except Exception: body_string = None
                if body_string is not None:
                    new_body_string = body_string; current_body_modified = False
                    # --- BUG FIX: Iterate through sorted names ---
                    for name in sorted_var_names:
                         value = current_vars[name]
                         pattern = r'(?:\$|%24)' + re.escape(name)
                         if re.search(pattern, new_body_string):
                             temp_body = ""; last_end = 0
                             for match in re.finditer(pattern, new_body_string):
                                 start, end = match.span()
                                 if '$collabplz' in value: value_to_insert = value
                                 else:
                                     value_to_insert = value
                                     if new_body_string[:start].count('"') % 2 != 0:
                                         value_to_insert = value.replace('\\', '\\\\').replace('"', '\\"')
                                 temp_body += new_body_string[last_end:start] + value_to_insert
                                 last_end = end
                             new_body_string = temp_body + new_body_string[last_end:]
                             current_body_modified = True
                    if current_body_modified:
                        try:
                            new_body_bytes = self._helpers.stringToBytes(new_body_string)
                            body_modified = modified = True
                        except Exception:
                              self._callbacks.printError("Error encoding modified response body:")
                              self._callbacks.printError(traceback.format_exc())
                              body_modified = False
                              modified = headers_modified
            if modified:
                try:
                    new_response_bytes = self._helpers.buildHttpMessage(new_headers, new_body_bytes)
                    messageInfo.setResponse(new_response_bytes)
                except Exception:
                    self._callbacks.printError("Error building modified HTTP response:")
                    self._callbacks.printError(traceback.format_exc())
