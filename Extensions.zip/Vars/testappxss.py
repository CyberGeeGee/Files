# Import necessary libraries from Flask
# Removed 'escape' from this import line as it's no longer directly available here
from flask import Flask, request, Response
import markupsafe # Flask uses this for escaping

# Create a Flask application instance
app = Flask(__name__)

# Define the main route for the application
@app.route('/')
def index():
    """
    Handles requests to the root URL '/'.
    Retrieves the 'name' query parameter and embeds it unsanitized
    into the HTML response, demonstrating reflected XSS.
    """
    # Get the 'name' query parameter from the request URL
    # Provide a default value if 'name' is not present
    name = request.args.get('name1', 'Guest')

    # --- VULNERABLE PART ---
    # Directly embed the 'name' parameter into the HTML string without sanitization.
    # This is where the reflected XSS vulnerability occurs.
    # A safe version would use escaping, e.g., f"<h1>Hello, {markupsafe.escape(name)}!</h1>"
    # Note: We are intentionally NOT using markupsafe.escape(name) here to keep it vulnerable.
    html_content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Server-Side Reflected XSS Test</title>
    <style>
        body {{
            font-family: sans-serif;
            padding: 20px;
            line-height: 1.6;
        }}
        .container {{
            max-width: 700px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: #f9f9f9;
        }}
        .output {{
            margin-top: 15px;
            padding: 10px;
            border: 1px solid #ddd;
            background-color: #fff;
            border-radius: 4px;
            word-wrap: break-word; /* Ensure long inputs wrap */
        }}
        code {{
            background-color: #eee;
            padding: 2px 5px;
            border-radius: 3px;
            font-family: monospace;
        }}
        pre {{
            background-color: #eee;
            padding: 10px;
            border-radius: 4px;
            overflow-x: auto; /* Allow horizontal scroll for long code */
            font-family: monospace;
        }}
        .warning {{
             color: #D8000C; /* Red color for warning */
             background-color: #FFD2D2; /* Light red background */
             border: 1px solid #D8000C;
             padding: 10px;
             border-radius: 4px;
             margin-top: 15px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Server-Side Reflected XSS Test</h1>
        <p>
            This page demonstrates a server-side reflected XSS vulnerability.
            The server takes the value from the <code>name</code> query parameter
            and includes it directly in the HTML response sent to the browser without sanitization.
        </p>

        <div class="output">
            <strong>Welcome Message:</strong><br>
            Hello, {name}!
        </div>

        <hr style="margin: 20px 0;">

        <h2>How to Test:</h2>
        <p>
            Modify the URL in your browser by adding a <code>?name=...</code> parameter.
        </p>
        <p>
            <strong>Example 1 (Simple Text):</strong> Try appending <code>?name=YourName</code> to the URL.
            <br><em>Expected output: Hello, YourName!</em>
        </p>
        <p>
            <strong>Example 2 (XSS Payload):</strong> Try appending the following to the URL:
        </p>
        <pre>?name=&lt;script&gt;alert('Server-Side XSS!');&lt;/script&gt;</pre>
        <p>
            If an alert box pops up, the XSS vulnerability is confirmed. The script was included in the server's response and executed by the browser.
        </p>
        <div class="warning">
            <strong>Note:</strong> Modern browsers might have built-in XSS filters that could block simple reflected XSS attempts. You might need to disable these filters in your browser settings for testing purposes (not recommended for general browsing). Some browsers might show a warning or block the page entirely.
        </div>
    </div>
</body>
</html>
    """

    # Return the generated HTML as the response
    # The content type is explicitly set to text/html
    return Response(html_content, mimetype='text/html')

# Entry point for running the Flask development server
if __name__ == '__main__':
    # Run the app in debug mode (useful for development, shows errors)
    # Listen on all available network interfaces (0.0.0.0)
    # Use port 5000 (or choose another if 5000 is busy)
    print("Starting Flask server...")
    print("Visit http://127.0.0.1:5000/ or http://<your-local-ip>:5000/")
    print("Test XSS by adding ?name=<script>alert('Server-Side XSS!')</script> to the URL")
    # Use threaded=False if you encounter issues with some specific browser interactions or debugging,
    # though the default (threaded=True) is generally fine.
    app.run(debug=True, host='0.0.0.0', port=8888)

